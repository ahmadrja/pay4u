<?php
session_start();

// Security Check
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

require_once '../config/database.php';
$database = new Database();
$db = $database->getConnection();

$admin_name = $_SESSION['user_name'] ?? 'Super Admin';
$message = "";

// --- कमीशन अपडेट करने का लॉजिक ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_comm'])) {
    $id = intval($_POST['comm_id']);
    $admin_margin = floatval($_POST['admin_margin']);
    $user_cashback = floatval($_POST['user_cashback']);
    $status = $_POST['status'];

    try {
        $updateStmt = $db->prepare("UPDATE commissions SET admin_margin = ?, user_cashback = ?, status = ? WHERE id = ?");
        $updateStmt->execute([$admin_margin, $user_cashback, $status, $id]);
        $message = "Commission updated successfully!";
    } catch (Exception $e) {
        $message = "Error: " . $e->getMessage();
    }
}

// कमीशन डेटा फेच करें
$commissions = $db->query("SELECT * FROM commissions ORDER BY operator_code ASC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Commission Config - SuperPay Admin</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --sidebar-bg: #111827; --primary: #4F46E5; --bg-color: #F3F4F6; --text-dark: #1F2937; --white: #FFFFFF; }
        body { margin: 0; font-family: 'Segoe UI', sans-serif; background: var(--bg-color); display: flex; height: 100vh; overflow: hidden; }
        
        /* Sidebar (Same as previous pages) */
        .sidebar { width: 260px; background: var(--sidebar-bg); color: var(--white); display: flex; flex-direction: column; }
        .sidebar-header { padding: 20px; font-size: 22px; font-weight: bold; border-bottom: 1px solid #374151; display: flex; align-items: center; gap: 10px; }
        .sidebar-menu { list-style: none; padding: 20px 0; margin: 0; flex: 1; }
        .sidebar-menu li a { display: flex; align-items: center; gap: 15px; padding: 15px 25px; color: #9CA3AF; text-decoration: none; transition: 0.3s; font-size: 15px; }
        .sidebar-menu li a:hover, .sidebar-menu li a.active { background: #1F2937; color: var(--white); border-left: 4px solid var(--primary); }

        .main-content { flex: 1; overflow-y: auto; display: flex; flex-direction: column; }
        .topbar { background: var(--white); padding: 20px 30px; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 1px 3px rgba(0,0,0,0.05); }
        
        .content-container { padding: 30px; }
        .config-card { background: var(--white); border-radius: 12px; padding: 25px; border: 1px solid #E5E7EB; }
        
        .alert { padding: 15px; border-radius: 8px; margin-bottom: 20px; font-weight: bold; }
        .alert-success { background: #D1FAE5; color: #065F46; }

        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { padding: 15px; text-align: left; border-bottom: 1px solid #F3F4F6; }
        th { background: #F9FAFB; color: #6B7280; font-size: 12px; text-transform: uppercase; }

        .input-group { display: flex; align-items: center; gap: 5px; }
        .input-field { width: 80px; padding: 8px; border: 1px solid #D1D5DB; border-radius: 6px; text-align: center; }
        .status-select { padding: 8px; border-radius: 6px; border: 1px solid #D1D5DB; }
        
        .btn-update { background: var(--primary); color: white; border: none; padding: 8px 15px; border-radius: 6px; cursor: pointer; transition: 0.3s; }
        .btn-update:hover { background: #4338CA; }
        
        .badge-info { font-size: 11px; color: #6B7280; display: block; margin-top: 4px; }
    </style>
</head>
<body>

    <div class="sidebar">
        <div class="sidebar-header"><i class="fas fa-bolt" style="color: #F59E0B;"></i> SuperAdmin</div>
        <ul class="sidebar-menu">
            <li><a href="index.php"><i class="fas fa-chart-line"></i> Dashboard</a></li>
            <li><a href="manage_users.php"><i class="fas fa-users"></i> Users & KYC</a></li>
            <li><a href="transactions.php"><i class="fas fa-exchange-alt"></i> Transactions</a></li>
            <li><a href="commissions.php" class="active"><i class="fas fa-percent"></i> Commissions</a></li>
            <li><a href="settings.php"><i class="fas fa-cog"></i> API Settings</a></li>
        </ul>
    </div>

    <div class="main-content">
        <div class="topbar">
            <h2>Commission & Margin Settings</h2>
            <div class="admin-profile"><span><?php echo htmlspecialchars($admin_name); ?></span></div>
        </div>

        <div class="content-container">
            <?php if($message): ?>
                <div class="alert alert-success"><?php echo $message; ?></div>
            <?php endif; ?>

            <div class="config-card">
                <table>
                    <thead>
                        <tr>
                            <th>Operator</th>
                            <th>Type</th>
                            <th>Admin Margin (%)</th>
                            <th>User Cashback (%)</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($commissions as $comm): ?>
                        <tr>
                            <form method="POST">
                                <input type="hidden" name="comm_id" value="<?php echo $comm['id']; ?>">
                                <td>
                                    <strong><?php echo $comm['operator_code']; ?></strong>
                                    <span class="badge-info">Service: Recharge</span>
                                </td>
                                <td><span style="text-transform: capitalize;"><?php echo $comm['type']; ?></span></td>
                                <td>
                                    <div class="input-group">
                                        <input type="number" step="0.01" name="admin_margin" class="input-field" value="<?php echo $comm['admin_margin']; ?>"> %
                                    </div>
                                </td>
                                <td>
                                    <div class="input-group">
                                        <input type="number" step="0.01" name="user_cashback" class="input-field" value="<?php echo $comm['user_cashback']; ?>"> %
                                    </div>
                                </td>
                                <td>
                                    <select name="status" class="status-select">
                                        <option value="active" <?php echo $comm['status'] == 'active' ? 'selected' : ''; ?>>Active</option>
                                        <option value="inactive" <?php echo $comm['status'] == 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                                    </select>
                                </td>
                                <td>
                                    <button type="submit" name="update_comm" class="btn-update">
                                        <i class="fas fa-save"></i> Save
                                    </button>
                                </td>
                            </form>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</body>
</html>
<?php
// PHP logic to get the current file name (e.g., index.php, users.php)
$current_page = basename($_SERVER['PHP_SELF']);
?>

<aside class="sidebar">
    <div class="sidebar-brand">
        <i class="fas fa-bolt"></i> SuperAdmin
    </div>
    
    <ul class="sidebar-menu">
        <li>
            <a href="index.php" class="<?php echo ($current_page == 'index.php') ? 'active' : ''; ?>">
                <i class="fas fa-tachometer-alt"></i> Dashboard
            </a>
        </li>
        
        <li>
            <a href="users.php" class="<?php echo ($current_page == 'users.php') ? 'active' : ''; ?>">
                <i class="fas fa-users"></i> Users
            </a>
        </li>
        
        <li>
            <a href="wallets.php" class="<?php echo ($current_page == 'wallets.php') ? 'active' : ''; ?>">
                <i class="fas fa-wallet"></i> Wallets
            </a>
        </li>

        <li>
            <a href="commission.php" class="<?php echo ($current_page == 'commission.php') ? 'active' : ''; ?>">
                <i class="fas fa-percent"></i> Commission Rules
            </a>
        </li>
        
        <li>
            <a href="settings.php" class="<?php echo ($current_page == 'settings.php') ? 'active' : ''; ?>">
                <i class="fas fa-cog"></i> Settings
            </a>
        </li>
    </ul>
</aside>
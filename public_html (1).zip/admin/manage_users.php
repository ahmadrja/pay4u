<?php
session_start();

// Security Check: Sirf Admin access kar sakta hai
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

require_once '../config/database.php';
$database = new Database();
$db = $database->getConnection();

// =========================================================================
// ⚙️ BACKEND AJAX LOGIC: Block or Unblock User
// =========================================================================
$json_data = json_decode(file_get_contents("php://input"), true);

if ($json_data && isset($json_data['action']) && $json_data['action'] === 'toggle_status') {
    header('Content-Type: application/json');
    $target_user_id = intval($json_data['user_id']);
    $new_status = $json_data['status']; // 'active' ya 'inactive'

    try {
        $stmt = $db->prepare("UPDATE users SET status = ?, updated_at = NOW() WHERE id = ? AND role = 'user'");
        $stmt->execute([$new_status, $target_user_id]);
        
        $msg = $new_status === 'active' ? 'User Unblocked & Activated!' : 'User Blocked Successfully!';
        echo json_encode(['success' => true, 'message' => $msg]);
        exit;
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Database Error: ' . $e->getMessage()]);
        exit;
    }
}

// =========================================================================
// 🌐 FETCH ALL USERS & THEIR WALLET BALANCES
// =========================================================================
try {
    // JOIN lagakar user details aur unka wallet balance ek sath nikalna
    $query = "SELECT u.id, u.name, u.phone, u.status, u.created_at, w.balance 
              FROM users u 
              LEFT JOIN wallets w ON u.id = w.user_id 
              WHERE u.role = 'user' 
              ORDER BY u.created_at DESC";
    $users = $db->query($query)->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $users = [];
    error_log("Fetch Users Error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users - SuperAdmin</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --primary: #4F46E5; --bg: #F3F4F6; --card: #FFFFFF; --text-dark: #1F2937; }
        body { font-family: 'Segoe UI', sans-serif; background: var(--bg); margin: 0; padding: 20px; }
        .admin-container { max-width: 1100px; margin: auto; background: white; padding: 30px; border-radius: 12px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); }
        
        .header-top { display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; }
        h2 { color: #1F2937; margin: 0; display: flex; align-items: center; gap: 10px; }
        .btn-back { background: #1F2937; color: white; padding: 8px 15px; border-radius: 6px; text-decoration: none; font-size: 14px; font-weight: bold; transition: 0.3s; }
        .btn-back:hover { background: #000; }
        
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { padding: 15px; text-align: left; border-bottom: 1px solid #E5E7EB; font-size: 14px;}
        th { background: #F9FAFB; color: #6B7280; font-weight: 600; text-transform: uppercase; font-size: 12px; }
        
        .user-name { font-weight: bold; color: var(--text-dark); font-size: 15px; }
        .user-phone { color: #4F46E5; font-weight: 600; font-size: 13px; margin-top: 4px; display: inline-block; background: #EEF2FF; padding: 2px 8px; border-radius: 4px;}
        .wallet-bal { font-weight: bold; color: #10B981; font-size: 16px; }

        /* Toggle Switch */
        .switch { position: relative; display: inline-block; width: 44px; height: 24px; }
        .switch input { opacity: 0; width: 0; height: 0; }
        .slider { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: #EF4444; transition: .4s; border-radius: 24px; }
        .slider:before { position: absolute; content: ""; height: 18px; width: 18px; left: 3px; bottom: 3px; background-color: white; transition: .4s; border-radius: 50%; box-shadow: 0 2px 4px rgba(0,0,0,0.2);}
        input:checked + .slider { background-color: #10B981; }
        input:checked + .slider:before { transform: translateX(20px); }

        #toast { visibility: hidden; min-width: 250px; text-align: center; border-radius: 8px; padding: 15px; position: fixed; z-index: 1000; left: 50%; bottom: 30px; transform: translateX(-50%); font-size: 14px; color: white; font-weight: bold; transition: opacity 0.3s; opacity: 0; }
        #toast.show { visibility: visible; bottom: 50px; opacity: 1; }
        .success-toast { background-color: #10B981; }
        .error-toast { background-color: #EF4444; }
    </style>
</head>
<body>

    <div class="admin-container">
        <div class="header-top">
            <div>
                <h2><i class="fas fa-users"></i> Registered Users</h2>
                <p style="color: #6B7280; font-size: 14px; margin-top: 5px;">Manage all your customers, view their balances, and control access.</p>
            </div>
            <a href="index.php" class="btn-back"><i class="fas fa-arrow-left"></i> Dashboard</a>
        </div>

        <div style="overflow-x: auto;">
            <table>
                <thead>
                    <tr>
                        <th>User Info</th>
                        <th>Joined Date</th>
                        <th>Wallet Balance</th>
                        <th>Account Status (ON/OFF)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($users) > 0): ?>
                        <?php foreach($users as $user): ?>
                        <tr>
                            <td>
                                <div class="user-name"><?php echo htmlspecialchars($user['name']); ?></div>
                                <div class="user-phone"><i class="fas fa-mobile-alt"></i> <?php echo htmlspecialchars($user['phone']); ?></div>
                            </td>
                            <td style="color: #6B7280; font-size: 13px;">
                                <?php echo date('d M Y', strtotime($user['created_at'])); ?>
                            </td>
                            <td>
                                <span class="wallet-bal">₹ <?php echo number_format($user['balance'] ?? 0, 2); ?></span>
                            </td>
                            <td>
                                <label class="switch" title="Toggle to Block/Unblock">
                                    <input type="checkbox" <?php echo ($user['status'] === 'active') ? 'checked' : ''; ?> 
                                           onchange="toggleUserStatus(<?php echo $user['id']; ?>, this.checked)">
                                    <span class="slider"></span>
                                </label>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="4" style="text-align:center; padding: 40px; color: #6B7280;">No registered users found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div id="toast"></div>

    <script>
        function toggleUserStatus(userId, isChecked) {
            let newStatus = isChecked ? 'active' : 'inactive';
            let confirmMsg = isChecked ? "Are you sure you want to Unblock this user?" : "Are you sure you want to BLOCK this user? They will not be able to login.";
            
            if(!confirm(confirmMsg)) {
                // Agar admin ne cancel kiya toh switch wapas apni purani state me aa jayega
                event.target.checked = !isChecked;
                return;
            }

            fetch(window.location.href, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'toggle_status', user_id: userId, status: newStatus })
            })
            .then(res => res.json())
            .then(data => {
                if(data.success) {
                    showToast(data.message, newStatus === 'active' ? 'success-toast' : 'error-toast');
                } else {
                    showToast(data.message, 'error-toast');
                    event.target.checked = !isChecked; // Revert switch if failed
                }
            })
            .catch(err => {
                showToast("Server Connection Failed.", "error-toast");
                event.target.checked = !isChecked;
            });
        }

        function showToast(message, type) {
            const toast = document.getElementById("toast");
            toast.innerText = message;
            toast.className = `show ${type}`; 
            setTimeout(() => { toast.className = toast.className.replace(`show ${type}`, ""); }, 3000);
        }
    </script>
</body>
</html>
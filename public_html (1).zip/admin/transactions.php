<?php
session_start();

// Strict Security Check: Sirf Admin access kar sakta hai
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

require_once '../config/database.php';
$database = new Database();
$db = $database->getConnection();

// Fetch All Transactions with User Details (Latest First)
// Limit 100 lagaya hai taaki page fast load ho. (Real app mein pagination lagta hai)
try {
    $query = "SELECT t.id, t.txn_id, t.service_type, t.amount, t.status, t.created_at, u.name, u.phone 
              FROM transactions t 
              JOIN users u ON t.user_id = u.id 
              ORDER BY t.created_at DESC LIMIT 100";
    $stmt = $db->query($query);
    $all_transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $all_transactions = [];
    error_log("Admin Master Ledger Error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Master Ledger - SuperAdmin</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --primary: #4F46E5; --bg: #F3F4F6; --card: #FFFFFF; --text-dark: #1F2937; }
        body { font-family: 'Segoe UI', sans-serif; background: var(--bg); margin: 0; padding: 20px; }
        .admin-container { max-width: 1200px; margin: auto; background: white; padding: 30px; border-radius: 12px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); }
        
        .header-top { display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; }
        h2 { color: #1F2937; margin: 0; display: flex; align-items: center; gap: 10px; }
        .btn-back { background: #1F2937; color: white; padding: 8px 15px; border-radius: 6px; text-decoration: none; font-size: 14px; font-weight: bold; transition: 0.3s; }
        .btn-back:hover { background: #000; }
        
        /* Table Styling */
        .table-responsive { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; white-space: nowrap; }
        th, td { padding: 15px; text-align: left; border-bottom: 1px solid #E5E7EB; font-size: 14px;}
        th { background: #F9FAFB; color: #6B7280; font-weight: 600; text-transform: uppercase; font-size: 12px; }
        
        tr:hover { background-color: #F9FAFB; }
        
        .user-info { font-weight: bold; color: #1F2937; }
        .user-phone { font-size: 12px; color: #6B7280; font-weight: normal; }
        
        .amt-text { font-size: 15px; font-weight: bold; color: var(--text-dark); }
        .txn-id { font-family: 'Courier New', monospace; font-weight: bold; color: #4F46E5; background: #EEF2FF; padding: 3px 6px; border-radius: 4px; font-size: 13px; }
        
        /* Dynamic Status Badges */
        .badge { padding: 5px 10px; border-radius: 12px; font-size: 11px; font-weight: bold; text-transform: uppercase; }
        .badge-success { background: #D1FAE5; color: #065F46; }
        .badge-pending { background: #FEF3C7; color: #92400E; }
        .badge-processing { background: #DBEAFE; color: #1E3A8A; }
        .badge-failed { background: #FEE2E2; color: #991B1B; }

        /* Service Type Badges */
        .service-type { font-size: 12px; font-weight: 600; color: #4B5563; display: flex; align-items: center; gap: 6px; }
        .service-type i { font-size: 14px; }
        .type-recharge { color: #4F46E5; }
        .type-load { color: #10B981; }
    </style>
</head>
<body>

    <div class="admin-container">
        <div class="header-top">
            <div>
                <h2><i class="fas fa-list-alt"></i> Master Transaction Ledger</h2>
                <p style="color: #6B7280; font-size: 14px; margin-top: 5px;">Track all platform activities (Recharges, Add Money, Refunds) in real-time.</p>
            </div>
            <a href="index.php" class="btn-back"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
        </div>

        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Date & Time</th>
                        <th>Transaction ID</th>
                        <th>User Details</th>
                        <th>Service Type</th>
                        <th>Amount</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($all_transactions) > 0): ?>
                        <?php foreach($all_transactions as $txn): 
                            // Status Badge Logic
                            $badge_class = 'badge-pending';
                            if($txn['status'] === 'success') $badge_class = 'badge-success';
                            if($txn['status'] === 'failed') $badge_class = 'badge-failed';
                            if($txn['status'] === 'processing') $badge_class = 'badge-processing';

                            // Service Type Logic & Icons
                            $service_name = str_replace('_', ' ', $txn['service_type']);
                            $service_icon = '<i class="fas fa-mobile-alt type-recharge"></i>';
                            if ($txn['service_type'] == 'wallet_load') {
                                $service_icon = '<i class="fas fa-wallet type-load"></i>';
                            }
                        ?>
                        <tr>
                            <td>
                                <div style="color: #4B5563; font-weight: 500;"><?php echo date('d M Y', strtotime($txn['created_at'])); ?></div>
                                <div style="font-size: 12px; color: #9CA3AF;"><?php echo date('h:i A', strtotime($txn['created_at'])); ?></div>
                            </td>
                            <td><span class="txn-id"><?php echo htmlspecialchars($txn['txn_id']); ?></span></td>
                            <td>
                                <div class="user-info"><?php echo htmlspecialchars($txn['name']); ?></div>
                                <div class="user-phone"><i class="fas fa-phone-alt"></i> <?php echo htmlspecialchars($txn['phone']); ?></div>
                            </td>
                            <td>
                                <span class="service-type" style="text-transform: capitalize;">
                                    <?php echo $service_icon . " " . $service_name; ?>
                                </span>
                            </td>
                            <td class="amt-text">₹ <?php echo number_format($txn['amount'], 2); ?></td>
                            <td><span class="badge <?php echo $badge_class; ?>"><?php echo htmlspecialchars($txn['status']); ?></span></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="6" style="text-align:center; padding: 40px; color: #6B7280;">No transactions found on the platform yet.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</body>
</html>
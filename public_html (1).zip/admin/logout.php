<?php
// 1. Session start karein (existing session ko access karne ke liye)
session_start();

// 2. Saare session variables ko array empty karke clear karein
$_SESSION = array();

// 3. Browser se session cookie ko force delete karein (Advanced Security)
// Yeh hacker ko purani cookie use karke wapas aane se rokega
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// 4. Server se session hamesha ke liye destroy karein
session_destroy();

// 5. Login page par safely redirect karein
// DHYAAN DEIN: Agar aapka login page kisi specific folder mein hai, toh path theek se set karein.
header("Location: login.php"); 
exit();
?>
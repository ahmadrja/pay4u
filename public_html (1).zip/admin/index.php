<?php
session_start();

// 1. Strict Security Check: Only Admin can access
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

require_once '../config/database.php';
$database = new Database();
$db = $database->getConnection();

$admin_name = $_SESSION['user_name'] ?? 'Super Admin';

// --- Live KPI Data Fetching ---
$kpi = [
    'total_revenue' => 0.00,
    'active_users' => 0,
    'total_wallet_balance' => 0.00,
    'pending_funds' => 0,
    'failed_txns' => 0
];

try {
    // Total Active Users
    $kpi['active_users'] = $db->query("SELECT COUNT(id) FROM users WHERE role = 'user'")->fetchColumn() ?: 0;
    
    // Pending Fund Requests (Critical Alert - User waiting for wallet balance)
    $kpi['pending_funds'] = $db->query("SELECT COUNT(id) FROM transactions WHERE service_type = 'wallet_load' AND status = 'pending'")->fetchColumn() ?: 0;
    
    // Today's Stats (Revenue from successful Recharges & loads)
    $row = $db->query("SELECT COUNT(id) as count, SUM(amount) as total FROM transactions WHERE DATE(created_at) = CURDATE() AND status = 'success'")->fetch(PDO::FETCH_ASSOC);
    $kpi['total_revenue'] = $row['total'] ?? 0.00;

    // Total Wallet Liability (System mein logon ka kitna paisa pada hai)
    $kpi['total_wallet_balance'] = $db->query("SELECT SUM(balance) FROM wallets")->fetchColumn() ?: 0.00;
    
    // Top 8 Recent Transactions with User Names
    $recent_txns = $db->query("SELECT t.txn_id, u.name, t.amount, t.service_type, t.status, t.created_at FROM transactions t JOIN users u ON t.user_id = u.id ORDER BY t.created_at DESC LIMIT 8")->fetchAll(PDO::FETCH_ASSOC);

} catch (Exception $e) {
    error_log("Dashboard Logic Error: " . $e->getMessage());
    $recent_txns = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Master Control | SuperPay Admin</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --sidebar-bg: #111827;
            --main-bg: #F3F4F6;
            --card-bg: #FFFFFF;
            --primary: #4F46E5;
            --secondary: #10B981;
            --danger: #EF4444;
            --text-dark: #1F2937;
            --text-light: #6B7280;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Inter', 'Segoe UI', sans-serif; }
        
        body { display: flex; height: 100vh; background-color: var(--main-bg); overflow: hidden; }
        
        /* Sidebar Navigation */
        .sidebar { width: 260px; background: var(--sidebar-bg); color: white; display: flex; flex-direction: column; transition: 0.3s; }
        .sidebar-brand { padding: 25px; font-size: 22px; font-weight: 800; border-bottom: 1px solid #374151; display: flex; align-items: center; gap: 12px; }
        .sidebar-brand i { color: #F59E0B; }
        .sidebar-menu { list-style: none; padding: 20px 0; flex: 1; }
        .sidebar-menu li a { display: flex; align-items: center; gap: 15px; padding: 15px 25px; color: #9CA3AF; text-decoration: none; transition: 0.2s; font-size: 15px; }
        .sidebar-menu li a:hover, .sidebar-menu li a.active { background: #1F2937; color: white; border-left: 4px solid var(--primary); }

        /* Main Viewport */
        .main-content { flex: 1; overflow-y: auto; padding: 25px; }
        .top-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; background: var(--white); }
        .top-header h2 { font-size: 24px; color: var(--text-dark); }
        .admin-box { display: flex; align-items: center; gap: 15px; }
        
        .logout-btn { background: var(--danger); color: white; text-decoration: none; padding: 10px 18px; border-radius: 8px; font-weight: 600; font-size: 14px; transition: 0.3s; box-shadow: 0 4px 6px rgba(239, 68, 68, 0.2); }
        .logout-btn:hover { background: #DC2626; transform: translateY(-1px); }

        /* KPI Cards Styling */
        .kpi-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 20px; margin-bottom: 35px; }
        .kpi-card { background: var(--card-bg); padding: 20px; border-radius: 12px; border: 1px solid #E5E7EB; display: flex; align-items: center; gap: 20px; transition: 0.3s; }
        .kpi-card:hover { transform: translateY(-5px); box-shadow: 0 10px 15px rgba(0,0,0,0.05); }
        .kpi-icon { width: 55px; height: 55px; border-radius: 12px; display: flex; justify-content: center; align-items: center; font-size: 22px; }
        
        .icon-revenue { background: #ECFDF5; color: var(--secondary); }
        .icon-users { background: #EEF2FF; color: var(--primary); }
        .icon-wallet { background: #FFF7ED; color: #F59E0B; }
        .icon-alert { background: #FEF2F2; color: var(--danger); }

        .kpi-info h3 { font-size: 12px; color: var(--text-light); text-transform: uppercase; letter-spacing: 0.5px; }
        .kpi-info h1 { font-size: 22px; color: var(--text-dark); margin-top: 4px; }

        /* Recent Transactions Table */
        .data-card { background: var(--card-bg); border-radius: 12px; border: 1px solid #E5E7EB; padding: 25px; box-shadow: 0 2px 4px rgba(0,0,0,0.02); }
        .data-card-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
        .data-card-header h3 { font-size: 18px; color: var(--text-dark); }
        .view-all { color: var(--primary); text-decoration: none; font-size: 14px; font-weight: 600; }

        table { width: 100%; border-collapse: collapse; }
        th { text-align: left; padding: 12px 15px; background: #F9FAFB; color: var(--text-light); font-size: 11px; text-transform: uppercase; border-bottom: 1px solid #E5E7EB; }
        td { padding: 16px 15px; border-bottom: 1px solid #F3F4F6; font-size: 14px; color: #4B5563; }
        
        .badge { padding: 4px 10px; border-radius: 6px; font-size: 11px; font-weight: 700; text-transform: uppercase; }
        .bg-success { background: #D1FAE5; color: #065F46; }
        .bg-pending { background: #FEF3C7; color: #92400E; }
        .bg-processing { background: #DBEAFE; color: #1E3A8A; }
        .bg-failed { background: #FEE2E2; color: #991B1B; }

        @media (max-width: 768px) { .sidebar { display: none; } }
    </style>
</head>
<body>

    <aside class="sidebar">
        <div class="sidebar-brand"><i class="fas fa-shield-alt"></i> SuperPay Admin</div>
        <ul class="sidebar-menu">
            <li><a href="index.php" class="active"><i class="fas fa-home"></i> Dashboard</a></li>
            <li><a href="manage_users.php"><i class="fas fa-users-cog"></i> User Management</a></li>
            <li>
                <a href="fund_requests.php" style="justify-content: space-between;">
                    <span><i class="fas fa-hand-holding-usd"></i> Fund Requests</span>
                    <?php if($kpi['pending_funds'] > 0): ?>
                        <span style="background: var(--danger); color: white; padding: 2px 8px; border-radius: 10px; font-size: 11px;"><?php echo $kpi['pending_funds']; ?></span>
                    <?php endif; ?>
                </a>
            </li>
            <li><a href="transactions.php"><i class="fas fa-history"></i> All Transactions</a></li>
            <li><a href="api_settings.php"><i class="fas fa-server"></i> API Control Panel</a></li>
        </ul>
    </aside>

    <main class="main-content">
        <header class="top-header">
            <h2>System Overview</h2>
            <div class="admin-box">
                <span style="font-weight: 600; color: var(--text-dark);"><?php echo htmlspecialchars($admin_name); ?></span>
                <a href="../logout.php" class="logout-btn"><i class="fas fa-power-off"></i> Logout</a>
            </div>
        </header>

        
        <div class="kpi-grid">
            <div class="kpi-card">
                <div class="kpi-icon icon-revenue"><i class="fas fa-chart-line"></i></div>
                <div class="kpi-info">
                    <h3>Today's Turnover</h3>
                    <h1>₹ <?php echo number_format($kpi['total_revenue'], 2); ?></h1>
                </div>
            </div>
            <div class="kpi-card">
                <div class="kpi-icon icon-users"><i class="fas fa-user-friends"></i></div>
                <div class="kpi-info">
                    <h3>Active Customers</h3>
                    <h1><?php echo number_format($kpi['active_users']); ?></h1>
                </div>
            </div>
            <div class="kpi-card">
                <div class="kpi-icon icon-wallet"><i class="fas fa-wallet"></i></div>
                <div class="kpi-info">
                    <h3>Total User Balances</h3>
                    <h1>₹ <?php echo number_format($kpi['total_wallet_balance'], 2); ?></h1>
                </div>
            </div>
            <a href="fund_requests.php" style="text-decoration: none;">
                <div class="kpi-card" style="<?php echo $kpi['pending_funds'] > 0 ? 'border: 2px solid var(--danger); box-shadow: 0 4px 15px rgba(239, 68, 68, 0.2);' : ''; ?>">
                    <div class="kpi-icon icon-alert" style="<?php echo $kpi['pending_funds'] > 0 ? 'background:#FEE2E2; color:#EF4444;' : ''; ?>">
                        <i class="fas fa-bell"></i>
                    </div>
                    <div class="kpi-info">
                        <h3>Pending Fund Requests</h3>
                        <h1 style="<?php echo $kpi['pending_funds'] > 0 ? 'color: var(--danger);' : 'color: var(--text-dark);'; ?>">
                            <?php echo number_format($kpi['pending_funds']); ?>
                        </h1>
                    </div>
                </div>
            </a>
        </div>

        <div class="data-card">
            <div class="data-card-header">
                <h3>Live Platform Activity</h3>
                <a href="transactions.php" class="view-all">See All Activity →</a>
            </div>
            <div style="overflow-x: auto;">
                <table>
                    <thead>
                        <tr>
                            <th>Transaction ID</th>
                            <th>User Name</th>
                            <th>Service</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Time</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($recent_txns) > 0): ?>
                            <?php foreach ($recent_txns as $txn): 
                                $statusBadge = 'bg-pending';
                                if($txn['status'] === 'success') $statusBadge = 'bg-success';
                                if($txn['status'] === 'failed') $statusBadge = 'bg-failed';
                                if($txn['status'] === 'processing') $statusBadge = 'bg-processing';
                            ?>
                            <tr>
                                <td style="font-family: 'Courier New', monospace; font-weight: bold;"><?php echo htmlspecialchars($txn['txn_id']); ?></td>
                                <td><strong><?php echo htmlspecialchars($txn['name']); ?></strong></td>
                                <td style="text-transform: capitalize;"><?php echo str_replace('_', ' ', $txn['service_type']); ?></td>
                                <td style="font-weight: 800; color: var(--text-dark);">₹ <?php echo number_format($txn['amount'], 2); ?></td>
                                <td><span class="badge <?php echo $statusBadge; ?>"><?php echo htmlspecialchars($txn['status']); ?></span></td>
                                <td><?php echo date('h:i A', strtotime($txn['created_at'])); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td colspan="6" style="text-align: center; padding: 40px;">No recent activity detected.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

</body>
</html>
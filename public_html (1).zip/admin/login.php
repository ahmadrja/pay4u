<?php
session_start();

// अगर एडमिन पहले से लॉगिन है, तो सीधा डैशबोर्ड (index.php) पर भेजें
if (isset($_SESSION['user_id']) && isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - SuperPay Platform</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --primary: #4F46E5; --bg-color: #F3F4F6; --text-dark: #1F2937; --white: #FFFFFF; }
        body { margin: 0; font-family: 'Inter', 'Segoe UI', sans-serif; background: var(--bg-color); display: flex; justify-content: center; align-items: center; height: 100vh; }
        .login-container { background: var(--white); padding: 40px; border-radius: 16px; box-shadow: 0 10px 25px rgba(0,0,0,0.08); width: 100%; max-width: 400px; text-align: center; border: 1px solid #E5E7EB; }
        .login-header { margin-bottom: 30px; }
        .login-header i { font-size: 45px; color: var(--primary); margin-bottom: 15px; }
        .login-header h2 { margin: 0; color: var(--text-dark); font-size: 26px; font-weight: 800; }
        .login-header p { color: #6B7280; font-size: 14px; margin-top: 8px; }
        
        .form-group { margin-bottom: 20px; text-align: left; }
        .form-group label { display: block; font-size: 13px; color: var(--text-dark); font-weight: 600; margin-bottom: 8px; text-transform: uppercase; letter-spacing: 0.5px; }
        .form-group input { width: 100%; padding: 14px 15px; border: 1px solid #D1D5DB; border-radius: 10px; font-size: 14px; box-sizing: border-box; transition: 0.3s; background: #F9FAFB; }
        .form-group input:focus { outline: none; border-color: var(--primary); background: #FFF; box-shadow: 0 0 0 4px rgba(79, 70, 229, 0.1); }
        
        .login-btn { width: 100%; background: var(--primary); color: var(--white); padding: 14px; border: none; border-radius: 10px; font-size: 16px; font-weight: bold; cursor: pointer; transition: 0.3s; display: flex; justify-content: center; align-items: center; gap: 10px; }
        .login-btn:hover { background: #4338CA; transform: translateY(-1px); box-shadow: 0 4px 12px rgba(79, 70, 229, 0.2); }
        
        .alert { padding: 12px; border-radius: 8px; font-size: 14px; margin-bottom: 20px; display: flex; align-items: center; gap: 10px; text-align: left; }
        .alert-error { background: #FEE2E2; color: #991B1B; border: 1px solid #FECACA; }
    </style>
</head>
<body>

    <div class="login-container">
        <div class="login-header">
            <i class="fas fa-user-shield"></i>
            <h2>Admin Login</h2>
            <p>Access the Master Control Panel</p>
        </div>

        <?php if(isset($_GET['error'])): ?>
        <div class="alert alert-error">
            <i class="fas fa-exclamation-circle"></i> 
            <?php 
                if($_GET['error'] == '1') echo "Invalid credentials or not an admin.";
                else if($_GET['error'] == 'empty') echo "Please fill all fields.";
                else echo "Access Denied.";
            ?>
        </div>
        <?php endif; ?>

        <form action="../api/admin_auth.php" method="POST">
            <div class="form-group">
                <label>Admin Phone / Email</label>
                <input type="text" name="username" required placeholder="Enter mobile or email" autocomplete="username">
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" required placeholder="Enter your password" autocomplete="current-password">
            </div>
            <button type="submit" class="login-btn">
                Authorize Access <i class="fas fa-lock"></i>
            </button>
        </form>
        
        <div style="margin-top: 25px; font-size: 12px; color: #9CA3AF;">
            <i class="fas fa-info-circle"></i> Your IP <?php echo $_SERVER['REMOTE_ADDR']; ?> is being logged for security.
        </div>
    </div>

</body>
</html>
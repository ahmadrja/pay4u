<?php
session_start();

// Security Check: Sirf Admin access kar sakta hai
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

require_once '../config/database.php';
$database = new Database();
$db = $database->getConnection();

// =========================================================================
// ⚙️ BACKEND AJAX LOGIC: Approve or Reject UTR Request
// =========================================================================
$json_data = json_decode(file_get_contents("php://input"), true);

if ($json_data && isset($json_data['action'])) {
    header('Content-Type: application/json');
    $txn_id = intval($json_data['id']); // Yeh transaction table ka Primary ID hai
    $action = $json_data['action'];

    try {
        // 1. Transaction ki details nikalein (Security Check ki pending hai ya nahi)
        $stmt = $db->prepare("SELECT user_id, amount, status FROM transactions WHERE id = ? LIMIT 1");
        $stmt->execute([$txn_id]);
        $txn = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$txn || $txn['status'] !== 'pending') {
            echo json_encode(['success' => false, 'message' => 'Request already processed or not found!']);
            exit;
        }

        if ($action === 'approve') {
            // 🔥 START ATOMIC TRANSACTION (Double Credit rokne ke liye)
            $db->beginTransaction();

            // Step A: Transaction status ko 'success' karein
            $update_txn = $db->prepare("UPDATE transactions SET status = 'success', updated_at = NOW() WHERE id = ?");
            $update_txn->execute([$txn_id]);

            // Step B: User ke wallet mein amount add karein
            $update_wallet = $db->prepare("UPDATE wallets SET balance = balance + ? WHERE user_id = ?");
            $update_wallet->execute([$txn['amount'], $txn['user_id']]);

            // Save sab kuch ek sath (Commit)
            $db->commit();
            echo json_encode(['success' => true, 'message' => 'Payment Approved! Wallet Balance Updated.']);
            exit;
            
        } elseif ($action === 'reject') {
            // Reject karne par sirf status update hoga, wallet nahi badhega
            $update_txn = $db->prepare("UPDATE transactions SET status = 'failed', updated_at = NOW() WHERE id = ?");
            $update_txn->execute([$txn_id]);
            
            echo json_encode(['success' => true, 'message' => 'Payment Request Rejected.']);
            exit;
        }
        
    } catch (Exception $e) {
        if ($db->inTransaction()) { $db->rollBack(); } // Agar error aaya toh cancel kar do
        echo json_encode(['success' => false, 'message' => 'Database Error: ' . $e->getMessage()]);
        exit;
    }
}

// =========================================================================
// 🌐 FETCH PENDING REQUESTS FROM DATABASE
// =========================================================================
try {
    // JOIN lagakar user details aur pending transactions ek sath nikalna
    $query = "SELECT t.id, t.txn_id as utr, t.amount, t.created_at, u.name, u.phone 
              FROM transactions t 
              JOIN users u ON t.user_id = u.id 
              WHERE t.service_type = 'wallet_load' AND t.status = 'pending' 
              ORDER BY t.created_at DESC";
    $requests = $db->query($query)->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $requests = [];
    error_log("Fetch Request Error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fund Requests - SuperAdmin</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Segoe UI', sans-serif; background: #F3F4F6; margin: 0; padding: 20px; }
        .admin-container { max-width: 1100px; margin: auto; background: white; padding: 30px; border-radius: 12px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); }
        .header-top { display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; }
        h2 { color: #1F2937; margin: 0; display: flex; align-items: center; gap: 10px; }
        .btn-back { background: #1F2937; color: white; padding: 8px 15px; border-radius: 6px; text-decoration: none; font-size: 14px; font-weight: bold; }
        
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 15px; text-align: left; border-bottom: 1px solid #E5E7EB; font-size: 14px;}
        th { background: #F9FAFB; color: #6B7280; font-weight: 600; text-transform: uppercase; font-size: 12px; }
        
        .user-info { font-weight: bold; color: #1F2937; }
        .user-phone { font-size: 12px; color: #6B7280; font-weight: normal; }
        .amount-text { font-size: 16px; font-weight: bold; color: #10B981; }
        .utr-text { font-family: monospace; background: #F3F4F6; padding: 5px 8px; border-radius: 4px; letter-spacing: 1px; font-size: 13px; color: #4B5563; }

        .btn-action { padding: 8px 12px; border: none; border-radius: 6px; cursor: pointer; font-weight: bold; font-size: 12px; transition: 0.2s; display: inline-flex; align-items: center; gap: 5px; }
        .btn-approve { background: #10B981; color: white; margin-right: 5px; }
        .btn-approve:hover { background: #059669; }
        .btn-reject { background: #EF4444; color: white; }
        .btn-reject:hover { background: #DC2626; }
        
        #toast { visibility: hidden; min-width: 250px; text-align: center; border-radius: 8px; padding: 15px; position: fixed; z-index: 1000; left: 50%; bottom: 30px; transform: translateX(-50%); font-size: 14px; color: white; font-weight: bold; transition: opacity 0.3s; opacity: 0; }
        #toast.show { visibility: visible; bottom: 50px; opacity: 1; }
        .success-toast { background-color: #10B981; }
        .error-toast { background-color: #EF4444; }
    </style>
</head>
<body>

    <div class="admin-container">
        <div class="header-top">
            <div>
                <h2><i class="fas fa-hand-holding-usd"></i> Pending Fund Requests</h2>
                <p style="color: #6B7280; font-size: 14px; margin-top: 5px;">Verify UTR in your bank app and approve to update user wallets.</p>
            </div>
            <a href="index.php" class="btn-back">Dashboard <i class="fas fa-arrow-right"></i></a>
        </div>

        <table>
            <thead>
                <tr>
                    <th>Date & Time</th>
                    <th>User Details</th>
                    <th>Amount Requested</th>
                    <th>UTR / Reference No.</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if(count($requests) > 0): ?>
                    <?php foreach($requests as $req): ?>
                    <tr id="row_<?php echo $req['id']; ?>">
                        <td><i class="far fa-clock" style="color:#9CA3AF;"></i> <?php echo date('d M Y, h:i A', strtotime($req['created_at'])); ?></td>
                        <td>
                            <div class="user-info"><?php echo htmlspecialchars($req['name']); ?></div>
                            <div class="user-phone"><i class="fas fa-mobile-alt"></i> <?php echo htmlspecialchars($req['phone']); ?></div>
                        </td>
                        <td class="amount-text">₹ <?php echo number_format($req['amount'], 2); ?></td>
                        <td><span class="utr-text"><?php echo htmlspecialchars($req['utr']); ?></span></td>
                        <td>
                            <button class="btn-action btn-approve" onclick="processRequest(<?php echo $req['id']; ?>, 'approve')">
                                <i class="fas fa-check"></i> Approve
                            </button>
                            <button class="btn-action btn-reject" onclick="processRequest(<?php echo $req['id']; ?>, 'reject')">
                                <i class="fas fa-times"></i> Reject
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="5" style="text-align:center; padding: 40px; color: #6B7280;">No pending fund requests right now. <i class="far fa-smile"></i></td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div id="toast"></div>

    <script>
        function processRequest(id, actionType) {
            // Ek chhota sa confirmation alert
            let confirmMsg = actionType === 'approve' 
                ? "Are you sure? This will instantly add money to user's wallet." 
                : "Are you sure you want to REJECT this payment?";
                
            if(!confirm(confirmMsg)) return;

            // AJAX Request to same file
            fetch(window.location.href, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: actionType, id: id })
            })
            .then(res => res.json())
            .then(data => {
                if(data.success) {
                    showToast(data.message, 'success-toast');
                    // Table se wo row gayab kar do bina page refresh kiye
                    document.getElementById('row_' + id).style.display = 'none';
                } else {
                    showToast(data.message, 'error-toast');
                }
            })
            .catch(err => {
                showToast("Server Connection Failed.", "error-toast");
            });
        }

        function showToast(message, type) {
            const toast = document.getElementById("toast");
            toast.innerText = message;
            toast.className = `show ${type}`; 
            setTimeout(() => { toast.className = toast.className.replace(`show ${type}`, ""); }, 3000);
        }
    </script>
</body>
</html>
<?php
session_start();

// Strict Security Check: Only Admin can access
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    // Agar normal user hai ya logged in nahi hai, toh wapas login page par bhej dein
    header("Location: ../login.php");
    exit;
}

require_once '../config/database.php';
$database = new Database();
$db = $database->getConnection();

$admin_name = $_SESSION['user_name'] ?? 'Super Admin';

// --- KPI Data Fetching (Optimized Queries) ---
$kpi = [
    'total_users' => 0,
    'pending_kyc' => 0,
    'today_revenue' => 0.00,
    'total_wallet_balance' => 0.00,
    'today_txns' => 0
];

try {
    // 1. Total active users
    $stmt = $db->query("SELECT COUNT(id) FROM users WHERE role = 'user'");
    $kpi['total_users'] = $stmt->fetchColumn() ?: 0;

    // 2. Pending KYC Approvals
    $stmt = $db->query("SELECT COUNT(id) FROM users WHERE kyc_status = 'pending'");
    $kpi['pending_kyc'] = $stmt->fetchColumn() ?: 0;

    // 3. Today's Successful Transactions Count & Total Amount
    $stmt = $db->query("SELECT COUNT(id) as count, SUM(amount) as total FROM transactions WHERE DATE(created_at) = CURDATE() AND status = 'success'");
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $kpi['today_txns'] = $row['count'] ?? 0;
    $kpi['today_revenue'] = $row['total'] ?? 0.00;

    // 4. System Liability (Total money in user wallets)
    $stmt = $db->query("SELECT SUM(balance) FROM wallets");
    $kpi['total_wallet_balance'] = $stmt->fetchColumn() ?? 0.00;

    // 5. Fetch Recent 5 Transactions for the table
    $stmtRecent = $db->query("
        SELECT t.txn_id, u.name, t.amount, t.service_type, t.status, t.created_at 
        FROM transactions t 
        JOIN users u ON t.user_id = u.id 
        ORDER BY t.created_at DESC LIMIT 5
    ");
    $recent_txns = $stmtRecent->fetchAll(PDO::FETCH_ASSOC);

} catch (Exception $e) {
    // Log error securely
    error_log("Admin Dashboard Error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - SuperApp</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --sidebar-bg: #111827; --primary: #4F46E5; --bg-color: #F3F4F6; --text-dark: #1F2937; --white: #FFFFFF; }
        body { margin: 0; font-family: 'Segoe UI', sans-serif; background: var(--bg-color); display: flex; height: 100vh; overflow: hidden; }
        
        /* Sidebar Layout */
        .sidebar { width: 260px; background: var(--sidebar-bg); color: var(--white); display: flex; flex-direction: column; }
        .sidebar-header { padding: 20px; font-size: 22px; font-weight: bold; border-bottom: 1px solid #374151; display: flex; align-items: center; gap: 10px; }
        .sidebar-menu { list-style: none; padding: 20px 0; margin: 0; flex: 1; }
        .sidebar-menu li a { display: flex; align-items: center; gap: 15px; padding: 15px 25px; color: #9CA3AF; text-decoration: none; transition: 0.3s; font-size: 15px; }
        .sidebar-menu li a:hover, .sidebar-menu li a.active { background: #1F2937; color: var(--white); border-left: 4px solid var(--primary); }
        .logout-btn { padding: 20px; border-top: 1px solid #374151; }
        .logout-btn a { color: #EF4444; text-decoration: none; display: flex; align-items: center; gap: 10px; font-weight: bold; }

        /* Main Content */
        .main-content { flex: 1; overflow-y: auto; display: flex; flex-direction: column; }
        .topbar { background: var(--white); padding: 20px 30px; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 1px 3px rgba(0,0,0,0.05); }
        .topbar h2 { margin: 0; color: var(--text-dark); font-size: 20px; }
        .admin-profile { display: flex; align-items: center; gap: 10px; font-weight: bold; color: var(--text-dark); }
        .admin-profile img { width: 35px; height: 35px; border-radius: 50%; }

        .dashboard-container { padding: 30px; }
        
        /* KPI Cards Grid */
        .kpi-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px; }
        .kpi-card { background: var(--white); padding: 25px; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.02); border: 1px solid #E5E7EB; display: flex; justify-content: space-between; align-items: center; transition: 0.3s; }
        .kpi-card:hover { transform: translateY(-3px); box-shadow: 0 5px 15px rgba(0,0,0,0.05); }
        .kpi-details h3 { margin: 0 0 10px 0; font-size: 13px; color: #6B7280; text-transform: uppercase; font-weight: 600; }
        .kpi-details h1 { margin: 0; font-size: 24px; color: var(--text-dark); }
        .kpi-icon { width: 50px; height: 50px; border-radius: 12px; display: flex; justify-content: center; align-items: center; font-size: 22px; }
        
        .icon-blue { background: #EEF2FF; color: var(--primary); }
        .icon-green { background: #D1FAE5; color: #10B981; }
        .icon-orange { background: #FEF3C7; color: #F59E0B; }
        .icon-purple { background: #F3E8FF; color: #9333EA; }
        .icon-red { background: #FEE2E2; color: #EF4444; }

        /* Table Section */
        .table-section { background: var(--white); border-radius: 12px; padding: 25px; box-shadow: 0 2px 10px rgba(0,0,0,0.02); border: 1px solid #E5E7EB; }
        .table-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
        .table-header h3 { margin: 0; color: var(--text-dark); }
        .view-all { color: var(--primary); text-decoration: none; font-size: 14px; font-weight: bold; }
        
        table { width: 100%; border-collapse: collapse; }
        th, td { text-align: left; padding: 15px; border-bottom: 1px solid #F3F4F6; font-size: 14px; }
        th { color: #6B7280; font-weight: 600; text-transform: uppercase; font-size: 12px; }
        .badge { padding: 4px 10px; border-radius: 20px; font-size: 12px; font-weight: bold; }
        .badge-success { background: #D1FAE5; color: #065F46; }
        .badge-failed { background: #FEE2E2; color: #991B1B; }
        .badge-pending { background: #FEF3C7; color: #92400E; }
    </style>
</head>
<body>

    <div class="sidebar">
        <div class="sidebar-header">
            <i class="fas fa-bolt" style="color: #F59E0B;"></i> SuperAdmin
        </div>
        <ul class="sidebar-menu">
            <li><a href="admin_dashboard.php" class="active"><i class="fas fa-chart-line"></i> Dashboard</a></li>
            <li><a href="manage_users.php"><i class="fas fa-users"></i> Users & KYC</a></li>
            <li><a href="transactions.php"><i class="fas fa-exchange-alt"></i> Transactions</a></li>
            <li><a href="commissions.php"><i class="fas fa-percent"></i> Commissions</a></li>
            <li><a href="settings.php"><i class="fas fa-cog"></i> API Settings</a></li>
        </ul>
        <div class="logout-btn">
            <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout Securely</a>
        </div>
    </div>

    <div class="main-content">
        <div class="topbar">
            <h2>Overview</h2>
            <div class="admin-profile">
                <span><?php echo htmlspecialchars($admin_name); ?></span>
                <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($admin_name); ?>&background=111827&color=fff" alt="Admin">
            </div>
        </div>

        <div class="dashboard-container">
            
            <div class="kpi-grid">
                <div class="kpi-card">
                    <div class="kpi-details">
                        <h3>Today's Turnover</h3>
                        <h1>₹ <?php echo number_format($kpi['today_revenue'], 2); ?></h1>
                    </div>
                    <div class="kpi-icon icon-blue"><i class="fas fa-rupee-sign"></i></div>
                </div>
                
                <div class="kpi-card">
                    <div class="kpi-details">
                        <h3>Today's Txns</h3>
                        <h1><?php echo number_format($kpi['today_txns']); ?></h1>
                    </div>
                    <div class="kpi-icon icon-purple"><i class="fas fa-receipt"></i></div>
                </div>

                <div class="kpi-card">
                    <div class="kpi-details">
                        <h3>Wallet Liability</h3>
                        <h1>₹ <?php echo number_format($kpi['total_wallet_balance'], 2); ?></h1>
                    </div>
                    <div class="kpi-icon icon-red"><i class="fas fa-wallet"></i></div>
                </div>

                <div class="kpi-card">
                    <div class="kpi-details">
                        <h3>Active Users</h3>
                        <h1><?php echo number_format($kpi['total_users']); ?></h1>
                    </div>
                    <div class="kpi-icon icon-green"><i class="fas fa-users"></i></div>
                </div>

                <div class="kpi-card">
                    <div class="kpi-details">
                        <h3>Pending KYC</h3>
                        <h1 style="<?php echo $kpi['pending_kyc'] > 0 ? 'color: #EF4444;' : ''; ?>">
                            <?php echo number_format($kpi['pending_kyc']); ?>
                        </h1>
                    </div>
                    <div class="kpi-icon icon-orange"><i class="fas fa-id-card"></i></div>
                </div>
            </div>

            <div class="table-section">
                <div class="table-header">
                    <h3>Recent Platform Activity</h3>
                    <a href="transactions.php" class="view-all">View All <i class="fas fa-arrow-right"></i></a>
                </div>
                <table>
                    <thead>
                        <tr>
                            <th>TXN ID</th>
                            <th>User Name</th>
                            <th>Service</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Date & Time</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($recent_txns) > 0): ?>
                            <?php foreach ($recent_txns as $txn): 
                                $badgeClass = 'badge-pending';
                                if($txn['status'] === 'success') $badgeClass = 'badge-success';
                                if($txn['status'] === 'failed') $badgeClass = 'badge-failed';
                            ?>
                            <tr>
                                <td style="font-family: monospace; color: #4B5563;"><?php echo $txn['txn_id']; ?></td>
                                <td style="font-weight: bold;"><?php echo htmlspecialchars($txn['name']); ?></td>
                                <td style="text-transform: capitalize;"><?php echo str_replace('_', ' ', $txn['service_type']); ?></td>
                                <td style="font-weight: bold;">₹ <?php echo number_format($txn['amount'], 2); ?></td>
                                <td><span class="badge <?php echo $badgeClass; ?>"><?php echo strtoupper($txn['status']); ?></span></td>
                                <td style="color: #6B7280;"><?php echo date('d M Y, h:i A', strtotime($txn['created_at'])); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" style="text-align: center; color: #6B7280; padding: 30px;">No transactions found today.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

        </div>
    </div>

</body>
</html>
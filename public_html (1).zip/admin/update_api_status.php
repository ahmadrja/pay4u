<?php
session_start();

// 1. Security Check: केवल Admin ही इसे एक्सेस कर सके
// if(!isset($_SESSION['admin_token'])) {
//     echo json_encode(['success' => false, 'message' => 'Unauthorized Access!']);
//     exit;
// }

// 2. Database Connection (PDO का उपयोग - SQL Injection से बचने के लिए)
// $host = 'localhost';
// $dbname = 'superpay_db';
// $user = 'root';
// $pass = '';
// try {
//     $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
//     $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
// } catch (PDOException $e) {
//     echo json_encode(['success' => false, 'message' => 'Database Error!']);
//     exit;
// }

// 3. Frontend (JS Fetch) से आ रहे JSON डेटा को रीड करना
$data = json_decode(file_get_contents("php://input"), true);

if (isset($data['id']) && isset($data['new_status'])) {
    
    $api_id = intval($data['id']);
    $new_status = $data['new_status']; // 'active' या 'inactive'

    try {
        // 4. Database में Status Update करना
        // $stmt = $pdo->prepare("UPDATE api_providers SET status = :status WHERE id = :id");
        // $stmt->execute([':status' => $new_status, ':id' => $api_id]);

        // Success Response वापस Frontend को भेजना
        echo json_encode([
            'success' => true, 
            'message' => 'API status updated successfully to ' . strtoupper($new_status)
        ]);

    } catch (Exception $e) {
        // Error Response
        echo json_encode([
            'success' => false, 
            'message' => 'Failed to update status. Please try again.'
        ]);
    }

} else {
    echo json_encode(['success' => false, 'message' => 'Invalid Data Received!']);
}
?>
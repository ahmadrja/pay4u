<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') { header("Location: ../login.php"); exit; }

require_once '../config/database.php';
$database = new Database();
$db = $database->getConnection();

// --- API Logic to Toggle Service ---
if (isset($_POST['toggle_service'])) {
    header('Content-Type: application/json');
    $id = $_POST['id'];
    $status = $_POST['status'];
    $stmt = $db->prepare("UPDATE service_configs SET is_active = ? WHERE id = ?");
    $stmt->execute([$status, $id]);
    echo json_encode(["status" => "success"]);
    exit;
}

$stmt = $db->query("SELECT * FROM service_configs");
$services = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Service Control - Admin</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --primary: #4F46E5; --bg: #F3F4F6; }
        body { font-family: 'Segoe UI', sans-serif; background: var(--bg); margin: 0; display: flex; }
        .sidebar { width: 260px; background: #111827; height: 100vh; color: white; padding: 20px; box-sizing: border-box; }
        .main { flex: 1; padding: 30px; }
        .card { background: white; padding: 20px; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); }
        .service-row { display: flex; justify-content: space-between; align-items: center; padding: 15px; border-bottom: 1px solid #EEE; }
        .switch { position: relative; display: inline-block; width: 50px; height: 24px; }
        .switch input { opacity: 0; width: 0; height: 0; }
        .slider { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: #ccc; transition: .4s; border-radius: 24px; }
        .slider:before { position: absolute; content: ""; height: 18px; width: 18px; left: 4px; bottom: 3px; background-color: white; transition: .4s; border-radius: 50%; }
        input:checked + .slider { background-color: #10B981; }
        input:checked + .slider:before { transform: translateX(26px); }
    </style>
</head>
<body>
    <div class="sidebar">
        <h3>SuperAdmin</h3>
        <p><a href="admin_dashboard.php" style="color:white; text-decoration:none;">Dashboard</a></p>
        <p><a href="service_settings.php" style="color:var(--primary); text-decoration:none;">Service Control</a></p>
    </div>
    <div class="main">
        <h2>Global Service Control</h2>
        <div class="card">
            <?php foreach($services as $s): ?>
            <div class="service-row">
                <div>
                    <strong style="text-transform: capitalize;"><?php echo str_replace('_', ' ', $s['service_name']); ?></strong>
                    <p style="margin:0; font-size:12px; color:gray;">Provider: <?php echo $s['api_provider']; ?></p>
                </div>
                <label class="switch">
                    <input type="checkbox" <?php echo $s['is_active'] ? 'checked' : ''; ?> onchange="toggleService(<?php echo $s['id']; ?>, this.checked ? 1 : 0)">
                    <span class="slider"></span>
                </label>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <script>
        async function toggleService(id, status) {
            const formData = new FormData();
            formData.append('toggle_service', 1);
            formData.append('id', id);
            formData.append('status', status);
            await fetch('service_settings.php', { method: 'POST', body: formData });
            alert("Service status updated for all users!");
        }
    </script>
</body>
</html>
<?php
session_start();

// 1. Strict Security Check
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

require_once '../config/database.php';
$database = new Database();
$db = $database->getConnection();

// =========================================================================
// ⚙️ BACKEND AJAX LOGIC: Handle Toggle & Save Settings (Single File Engine)
// =========================================================================
$json_data = json_decode(file_get_contents("php://input"), true);

if ($json_data && isset($json_data['action'])) {
    header('Content-Type: application/json');
    try {
        if ($json_data['action'] === 'toggle_status') {
            // API ON/OFF Logic
            $stmt = $db->prepare("UPDATE api_providers SET status = ?, updated_at = NOW() WHERE id = ?");
            $stmt->execute([$json_data['new_status'], $json_data['id']]);
            echo json_encode(['success' => true, 'message' => 'API Status Updated Successfully!']);
            exit;
        } 
        
        if ($json_data['action'] === 'save_config') {
            // Save API Settings (Keys, URL, Margin)
            $stmt = $db->prepare("UPDATE api_providers SET api_url = ?, api_token = ?, admin_margin_percent = ?, updated_at = NOW() WHERE id = ?");
            $stmt->execute([$json_data['api_url'], $json_data['api_key'], $json_data['margin'], $json_data['id']]);
            echo json_encode(['success' => true, 'message' => 'Configuration Saved Successfully!']);
            exit;
        }
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Database Error: ' . $e->getMessage()]);
        exit;
    }
}

// =========================================================================
// 🌐 FETCH REAL DATA FROM DATABASE
// =========================================================================
try {
    // डेटाबेस से लाइव API लिस्ट निकालें
    $stmt = $db->query("SELECT id, service_type as service, provider_name as provider, status, admin_margin_percent as margin, api_url, api_token as api_key FROM api_providers ORDER BY priority ASC, id ASC");
    $api_list = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $api_list = [];
    error_log("Failed to fetch API List: " . $e->getMessage());
}

// PHP Array को JavaScript के लिए JSON में कन्वर्ट करना
$api_json = json_encode($api_list);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>API Management - SuperAdmin</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        /* बेसिक एडमिन CSS */
        body { font-family: 'Segoe UI', sans-serif; background: #F3F4F6; margin: 0; padding: 20px; }
        .admin-container { max-width: 1100px; margin: auto; background: white; padding: 30px; border-radius: 12px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); }
        .header-top { display: flex; justify-content: space-between; align-items: center; }
        h2 { color: #1F2937; margin: 0; display: flex; align-items: center; gap: 10px; }
        .btn-back { background: #1F2937; color: white; padding: 8px 15px; border-radius: 6px; text-decoration: none; font-size: 14px; font-weight: bold; }
        
        table { width: 100%; border-collapse: collapse; margin-top: 25px; }
        th, td { padding: 15px; text-align: left; border-bottom: 1px solid #E5E7EB; font-size: 14px;}
        th { background: #F9FAFB; color: #6B7280; font-weight: 600; text-transform: uppercase; font-size: 12px; }
        
        /* टॉगल स्विच (ON/OFF) */
        .switch { position: relative; display: inline-block; width: 44px; height: 24px; }
        .switch input { opacity: 0; width: 0; height: 0; }
        .slider { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: #EF4444; transition: .4s; border-radius: 24px; }
        .slider:before { position: absolute; content: ""; height: 18px; width: 18px; left: 3px; bottom: 3px; background-color: white; transition: .4s; border-radius: 50%; box-shadow: 0 2px 4px rgba(0,0,0,0.2);}
        input:checked + .slider { background-color: #10B981; }
        input:checked + .slider:before { transform: translateX(20px); }

        .btn-edit { background: #EEF2FF; color: #4F46E5; border: none; padding: 8px 15px; border-radius: 6px; cursor: pointer; font-weight: 600; transition: 0.2s;}
        .btn-edit:hover { background: #4F46E5; color: white; }

        /* Modal (Popup) CSS */
        .modal-overlay { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; justify-content: center; align-items: center; }
        .modal-box { background: white; width: 100%; max-width: 450px; padding: 25px; border-radius: 12px; box-shadow: 0 10px 25px rgba(0,0,0,0.1); }
        .modal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; border-bottom: 1px solid #E5E7EB; padding-bottom: 15px;}
        .modal-header h3 { margin: 0; color: #1F2937; }
        .close-btn { cursor: pointer; color: #9CA3AF; font-size: 20px; transition: 0.2s;}
        .close-btn:hover { color: #EF4444; }
        
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; font-size: 13px; font-weight: 600; color: #4B5563; margin-bottom: 5px; }
        .form-group input { width: 100%; padding: 10px; border: 1px solid #D1D5DB; border-radius: 6px; outline: none; box-sizing: border-box; }
        .form-group input:focus { border-color: #4F46E5; box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.1); }
        
        .btn-save { width: 100%; background: #4F46E5; color: white; border: none; padding: 12px; border-radius: 6px; font-weight: 600; cursor: pointer; margin-top: 10px; transition: 0.2s; display: flex; justify-content: center; gap: 8px; align-items: center;}
        .btn-save:hover { background: #4338CA; }

        /* Toast Notification CSS */
        #toast { visibility: hidden; min-width: 250px; background-color: #333; color: #fff; text-align: center; border-radius: 8px; padding: 16px; position: fixed; z-index: 1001; left: 50%; bottom: 30px; transform: translateX(-50%); font-size: 14px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); transition: opacity 0.3s, bottom 0.3s; opacity: 0;}
        #toast.show { visibility: visible; bottom: 50px; opacity: 1; }
        #toast.success { background-color: #10B981; }
        #toast.error { background-color: #EF4444; }
    </style>
</head>
<body>

    <div class="admin-container">
        <div class="header-top">
            <div>
                <h2><i class="fas fa-server"></i> Master API Control Panel</h2>
                <p style="color: #6B7280; font-size: 14px; margin-top: 5px;">सभी सर्विस प्रोवाइडर्स और उनके API स्टेटस को यहाँ से लाइव मैनेज करें।</p>
            </div>
            <a href="index.php" class="btn-back">Dashboard <i class="fas fa-arrow-right"></i></a>
        </div>

        <table>
            <thead>
                <tr>
                    <th>Service Type</th>
                    <th>Provider Name</th>
                    <th>Admin Margin</th>
                    <th>Live Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if(count($api_list) > 0): ?>
                    <?php foreach($api_list as $api): ?>
                    <tr>
                        <td><strong><?php echo htmlspecialchars($api['service']); ?></strong></td>
                        <td><?php echo htmlspecialchars($api['provider']); ?></td>
                        <td><span style="color: #10B981; font-weight: bold;"><?php echo $api['margin']; ?>%</span></td>
                        <td>
                            <label class="switch">
                                <input type="checkbox" <?php echo ($api['status'] == 'active') ? 'checked' : ''; ?> 
                                       onchange="toggleApiStatus(<?php echo $api['id']; ?>, this.checked)">
                                <span class="slider"></span>
                            </label>
                        </td>
                        <td>
                            <button class="btn-edit" onclick="openApiSettings(<?php echo $api['id']; ?>)">
                                <i class="fas fa-cog"></i> Configure
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="5" style="text-align:center; padding: 30px; color: #6B7280;">No API Providers Found in Database.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="modal-overlay" id="apiModal">
        <div class="modal-box">
            <div class="modal-header">
                <h3 id="modalTitle">Configure API</h3>
                <i class="fas fa-times close-btn" onclick="closeModal()"></i>
            </div>
            
            <input type="hidden" id="editApiId">
            
            <div class="form-group">
                <label>API Endpoint URL</label>
                <input type="url" id="apiUrl" placeholder="https://api.provider.com/v1/">
            </div>
            <div class="form-group">
                <label>Secret API Key / Token</label>
                <input type="password" id="apiKey" placeholder="Enter API Key">
            </div>
            <div class="form-group">
                <label>Admin Margin (%)</label>
                <input type="number" id="apiMargin" step="0.01" placeholder="e.g. 2.5">
            </div>
            
            <button class="btn-save" id="saveBtn" onclick="saveApiData()">
                <i class="fas fa-save"></i> Save Configuration
            </button>
        </div>
    </div>

    <div id="toast">Notification Message</div>

    <script>
        // PHP डेटा को JS Object में लाना
        let apiDataList = <?php echo $api_json; ?>;

        // 1. Toggle API Status (Live AJAX to same file)
        function toggleApiStatus(apiId, isChecked) {
            let status = isChecked ? 'active' : 'inactive';
            
            fetch(window.location.href, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'toggle_status', id: apiId, new_status: status })
            })
            .then(res => res.json())
            .then(data => {
                if(data.success) {
                    showToast(data.message, 'success');
                } else {
                    showToast(data.message, 'error');
                    setTimeout(() => location.reload(), 1500); 
                }
            })
            .catch(err => showToast("Server Error Details failed to update.", "error"));
        }

        // 2. Open Configuration Modal
        function openApiSettings(apiId) {
            const api = apiDataList.find(a => a.id === apiId);
            if(api) {
                document.getElementById('modalTitle').innerText = `Configure: ${api.provider}`;
                document.getElementById('editApiId').value = api.id;
                document.getElementById('apiUrl').value = api.api_url || '';
                document.getElementById('apiKey').value = api.api_key || '';
                document.getElementById('apiMargin').value = api.margin || '';
                
                document.getElementById('apiModal').style.display = 'flex';
            }
        }

        // 3. Close Modal
        function closeModal() {
            document.getElementById('apiModal').style.display = 'none';
        }

        // 4. Save API Data from Modal (Live AJAX to same file)
        function saveApiData() {
            const btn = document.getElementById('saveBtn');
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';
            btn.disabled = true;

            let id = document.getElementById('editApiId').value;
            let url = document.getElementById('apiUrl').value;
            let key = document.getElementById('apiKey').value;
            let margin = document.getElementById('apiMargin').value;

            fetch(window.location.href, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ 
                    action: 'save_config', 
                    id: id, 
                    api_url: url, 
                    api_key: key, 
                    margin: margin 
                })
            })
            .then(res => res.json())
            .then(data => {
                btn.innerHTML = '<i class="fas fa-save"></i> Save Configuration';
                btn.disabled = false;
                
                if(data.success) {
                    closeModal();
                    showToast(data.message, 'success');
                    setTimeout(() => location.reload(), 1500); // UI रिफ्रेश करने के लिए
                } else {
                    showToast(data.message, 'error');
                }
            })
            .catch(err => {
                btn.innerHTML = '<i class="fas fa-save"></i> Save Configuration';
                btn.disabled = false;
                showToast("Server Connection Failed.", "error");
            });
        }

        // 5. Custom Toast Notification System
        function showToast(message, type) {
            const toast = document.getElementById("toast");
            toast.innerText = message;
            toast.className = `show ${type}`; 
            
            setTimeout(function(){ 
                toast.className = toast.className.replace(`show ${type}`, ""); 
            }, 3000);
        }
    </script>
</body>
</html>
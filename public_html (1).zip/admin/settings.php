<?php
session_start();
// Security Check (Production में इसे एक्टिव रखें)
// if(!isset($_SESSION['admin_token'])) { header("Location: login.php"); exit; }

// डमी डेटा (रियल प्रोजेक्ट में यह MySQL Database की 'system_settings' टेबल से आएगा)
$settings = [
    'app_name' => 'SuperPay',
    'maintenance_mode' => false,
    'payment_gateways' => [
        ['id' => 'pg1', 'name' => 'Razorpay', 'status' => 'active', 'key' => 'rzp_live_12345'],
        ['id' => 'pg2', 'name' => 'PhonePe', 'status' => 'inactive', 'key' => 'PHONEPE_PROD_99']
    ],
    'services' => [
        ['id' => 'srv1', 'name' => 'Mobile Recharge', 'status' => 'active', 'provider' => 'Mrobotics'],
        ['id' => 'srv2', 'name' => 'Flight Booking', 'status' => 'inactive', 'provider' => 'TravelPort']
    ]
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Master Settings - A to Z Control</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --primary: #4F46E5; --bg: #F3F4F6; --card: #FFFFFF; --text: #1F2937; }
        body { font-family: 'Segoe UI', sans-serif; background: var(--bg); padding: 20px; margin: 0; }
        .admin-container { max-width: 1000px; margin: 0 auto; background: var(--card); border-radius: 12px; padding: 30px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); }
        h2 { color: var(--text); border-bottom: 2px solid #E5E7EB; padding-bottom: 10px; margin-top: 0; }
        
        /* Tabs Design */
        .tabs { display: flex; gap: 15px; margin-bottom: 25px; border-bottom: 1px solid #E5E7EB; padding-bottom: 10px; }
        .tab-btn { background: none; border: none; font-size: 16px; font-weight: 600; color: #6B7280; cursor: pointer; padding: 10px 15px; transition: 0.3s; border-radius: 8px;}
        .tab-btn.active { background: #EEF2FF; color: var(--primary); }
        .tab-btn:hover { color: var(--primary); }
        
        /* Content Sections */
        .tab-content { display: none; }
        .tab-content.active { display: block; }
        
        /* Grid Cards */
        .grid-cards { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; }
        .control-card { border: 1px solid #E5E7EB; border-radius: 10px; padding: 20px; background: #FAFAFA; }
        .control-card h3 { margin-top: 0; color: var(--text); display: flex; justify-content: space-between; align-items: center;}
        
        /* Form Inputs */
        .input-group { margin-bottom: 15px; }
        .input-group label { display: block; font-size: 13px; font-weight: 600; color: #4B5563; margin-bottom: 5px; }
        .input-group input { width: 100%; padding: 10px; border: 1px solid #D1D5DB; border-radius: 6px; box-sizing: border-box; }
        
        /* Toggle Switch */
        .switch { position: relative; display: inline-block; width: 44px; height: 24px; }
        .switch input { opacity: 0; width: 0; height: 0; }
        .slider { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: #D1D5DB; transition: .4s; border-radius: 24px; }
        .slider:before { position: absolute; content: ""; height: 18px; width: 18px; left: 3px; bottom: 3px; background-color: white; transition: .4s; border-radius: 50%; }
        input:checked + .slider { background-color: #10B981; }
        input:checked + .slider:before { transform: translateX(20px); }

        .btn-save { background: var(--primary); color: white; padding: 10px 20px; border: none; border-radius: 6px; font-weight: 600; cursor: pointer; width: 100%; margin-top: 10px;}
    </style>
</head>
<body>

    <div class="admin-container">
        <h2><i class="fas fa-cogs"></i> SuperApp Master Configuration</h2>
        
        <div class="tabs">
            <button class="tab-btn active" onclick="openTab('gateways', this)"><i class="fas fa-credit-card"></i> Payment Gateways</button>
            <button class="tab-btn" onclick="openTab('apis', this)"><i class="fas fa-server"></i> API Providers</button>
            <button class="tab-btn" onclick="openTab('general', this)"><i class="fas fa-sliders-h"></i> General Settings</button>
        </div>

        <div id="gateways" class="tab-content active">
            <div class="grid-cards">
                <?php foreach($settings['payment_gateways'] as $pg): ?>
                <div class="control-card">
                    <h3>
                        <?php echo $pg['name']; ?>
                        <label class="switch">
                            <input type="checkbox" <?php echo ($pg['status'] == 'active') ? 'checked' : ''; ?>>
                            <span class="slider"></span>
                        </label>
                    </h3>
                    <div class="input-group">
                        <label>Merchant / API Key</label>
                        <input type="password" value="<?php echo $pg['key']; ?>">
                    </div>
                    <div class="input-group">
                        <label>Secret Key</label>
                        <input type="password" placeholder="Enter Secret Key">
                    </div>
                    <button class="btn-save">Update <?php echo $pg['name']; ?></button>
                </div>
                <?php endforeach; ?>
            </div>
            <p style="font-size: 12px; color: #6B7280; margin-top: 20px;">* Note: If multiple gateways are active, the system will use the primary one set in the database.</p>
        </div>

        <div id="apis" class="tab-content">
            <div class="grid-cards">
                <?php foreach($settings['services'] as $srv): ?>
                <div class="control-card">
                    <h3>
                        <?php echo $srv['name']; ?>
                        <label class="switch">
                            <input type="checkbox" <?php echo ($srv['status'] == 'active') ? 'checked' : ''; ?>>
                            <span class="slider"></span>
                        </label>
                    </h3>
                    <div class="input-group">
                        <label>Current Provider</label>
                        <input type="text" value="<?php echo $srv['provider']; ?>" readonly style="background: #E5E7EB;">
                    </div>
                    <button class="btn-save" style="background: #10B981;">Manage Routing</button>
                </div>
                <?php endforeach; ?>
            </div>
        </div>

        <div id="general" class="tab-content">
            <div class="control-card" style="max-width: 500px;">
                <h3>Platform Status</h3>
                <div class="input-group">
                    <label>Maintenance Mode (Block all user logins)</label>
                    <label class="switch">
                        <input type="checkbox" <?php echo ($settings['maintenance_mode']) ? 'checked' : ''; ?>>
                        <span class="slider"></span>
                    </label>
                </div>
                <div class="input-group">
                    <label>App Name</label>
                    <input type="text" value="<?php echo $settings['app_name']; ?>">
                </div>
                <button class="btn-save">Save General Settings</button>
            </div>
        </div>

    </div>

    <script>
        // Tab Switching Logic
        function openTab(tabId, btnElement) {
            // Hide all contents
            document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
            // Remove active class from all buttons
            document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
            
            // Show selected tab
            document.getElementById(tabId).classList.add('active');
            btnElement.classList.add('active');
        }
    </script>
</body>
</html>
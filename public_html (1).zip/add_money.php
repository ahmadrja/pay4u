<?php
session_start();

// Security Check (Production me uncomment karein)
// if(!isset($_SESSION['user_id'])) { header("Location: login.php"); exit; }

$wallet_balance = $_SESSION['wallet_balance'] ?? 5430.00;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Money - SuperPay</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --primary: #4F46E5; --bg-color: #F3F4F6; --card-bg: #FFFFFF; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: var(--bg-color); margin: 0; padding: 0; display: flex; justify-content: center; }
        .app-container { width: 100%; max-width: 480px; background: var(--card-bg); min-height: 100vh; position: relative; box-shadow: 0 0 20px rgba(0,0,0,0.05); }
        
        /* Header */
        .header { background: var(--primary); color: white; padding: 20px; display: flex; align-items: center; gap: 15px; font-size: 18px; font-weight: 600; }
        .header i { cursor: pointer; }

        /* Balance Card */
        .balance-section { padding: 30px 20px; text-align: center; background: #F9FAFB; border-bottom: 1px solid #E5E7EB;}
        .balance-section p { margin: 0; color: #6B7280; font-size: 14px; font-weight: 500;}
        .balance-section h2 { margin: 10px 0 0 0; font-size: 32px; color: #1F2937; }

        /* Input Section */
        .input-section { padding: 30px 20px; }
        .input-group { position: relative; margin-bottom: 20px;}
        .input-group i { position: absolute; left: 20px; top: 50%; transform: translateY(-50%); font-size: 24px; color: #9CA3AF; }
        .input-group input { width: 100%; padding: 20px 20px 20px 55px; border: 2px solid #E5E7EB; border-radius: 16px; font-size: 28px; font-weight: 700; color: #1F2937; outline: none; transition: 0.3s; box-sizing: border-box; }
        .input-group input:focus { border-color: var(--primary); box-shadow: 0 0 0 4px rgba(79, 70, 229, 0.1); }
        
        /* Quick Amounts */
        .quick-amounts { display: flex; gap: 10px; margin-bottom: 30px; flex-wrap: wrap;}
        .chip { flex: 1; padding: 12px; text-align: center; border: 1px solid #D1D5DB; border-radius: 10px; font-weight: 600; color: #4B5563; cursor: pointer; transition: 0.2s; min-width: 80px;}
        .chip:hover { background: #EEF2FF; color: var(--primary); border-color: var(--primary); }

        /* Payment Button */
        .btn-proceed { width: 100%; background: var(--primary); color: white; border: none; padding: 18px; border-radius: 12px; font-size: 16px; font-weight: 600; cursor: pointer; transition: 0.2s; box-shadow: 0 4px 6px rgba(79, 70, 229, 0.2);}
        .btn-proceed:hover { background: #4338CA; transform: translateY(-2px); }
        
        .pg-info { text-align: center; font-size: 12px; color: #9CA3AF; margin-top: 15px; display: flex; align-items: center; justify-content: center; gap: 5px;}
    </style>
</head>
<body>

    <div class="app-container">
        <div class="header">
            <i class="fas fa-arrow-left" onclick="window.location.href='index.php'"></i>
            Add Money to Wallet
        </div>

        <div class="balance-section">
            <p>Current Wallet Balance</p>
            <h2>₹ <?php echo number_format($wallet_balance, 2); ?></h2>
        </div>

        <div class="input-section">
            <form action="process_payment.php" method="POST">
                
                <div class="input-group">
                    <i class="fas fa-rupee-sign"></i>
                    <input type="number" name="amount" id="amountInput" placeholder="0" min="10" max="100000" required autocomplete="off">
                </div>

                <div class="quick-amounts">
                    <div class="chip" onclick="setAmount(500)">+ ₹500</div>
                    <div class="chip" onclick="setAmount(1000)">+ ₹1000</div>
                    <div class="chip" onclick="setAmount(2000)">+ ₹2000</div>
                    <div class="chip" onclick="setAmount(5000)">+ ₹5000</div>
                </div>

                <button type="submit" class="btn-proceed" id="payBtn">
                    Proceed to Add Money
                </button>
            </form>
            
            <div class="pg-info">
                <i class="fas fa-shield-alt"></i> 100% Secure Payments powered by UPI / Cards
            </div>
        </div>
    </div>

    <script>
        // Quick amount selection logic
        function setAmount(val) {
            const input = document.getElementById('amountInput');
            input.value = val;
            input.focus();
        }

        // Button Loading Animation
        document.querySelector('form').addEventListener('submit', function() {
            const btn = document.getElementById('payBtn');
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Initializing Secure Gateway...';
            btn.style.opacity = '0.8';
        });
    </script>
</body>
</html>
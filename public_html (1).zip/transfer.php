<?php
session_start();
// 1. मास्टर डेटाबेस कनेक्शन
require_once 'config/database.php';

// Security Check
if(!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$sender_id = $_SESSION['user_id'];
$message = "";
$status_class = "";

// =========================================================================
// ⚙️ BACKEND LOGIC: P2P TRANSFER ENGINE
// =========================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_money'])) {
    
    $receiver_mobile = htmlspecialchars($_POST['receiver_mobile']);
    $amount = floatval($_POST['amount']);
    $remarks = htmlspecialchars($_POST['remarks'] ?? 'Wallet Transfer');

    if ($amount < 1) {
        $message = "Minimum transfer amount is ₹1";
        $status_class = "error";
    } else {
        try {
            $pdo->beginTransaction();

            // STEP A: Sender का बैलेंस चेक करें और लॉक करें
            $stmt = $pdo->prepare("SELECT wallet_balance, full_name FROM users WHERE id = ? FOR UPDATE");
            $stmt->execute([$sender_id]);
            $sender = $stmt->fetch();

            if ($sender['wallet_balance'] < $amount) {
                throw new Exception("Insufficient Balance!");
            }

            // STEP B: Receiver को उसके मोबाइल नंबर से ढूंढें
            $stmt = $pdo->prepare("SELECT id, full_name, wallet_balance FROM users WHERE mobile = ? AND status = 'active' FOR UPDATE");
            $stmt->execute([$receiver_mobile]);
            $receiver = $stmt->fetch();

            if (!$receiver) {
                throw new Exception("Receiver not found or inactive!");
            }

            if ($receiver['id'] == $sender_id) {
                throw new Exception("You cannot send money to yourself!");
            }

            // STEP C: पैसे ट्रांसफर करें (Atomic Updates)
            $txn_id = "P2P" . date("YmdHis") . rand(100, 999);

            // 1. Sender का बैलेंस घटाएं
            $new_sender_bal = $sender['wallet_balance'] - $amount;
            $stmt = $pdo->prepare("UPDATE users SET wallet_balance = ? WHERE id = ?");
            $stmt->execute([$new_sender_bal, $sender_id]);
            $_SESSION['wallet_balance'] = $new_sender_bal;

            // 2. Receiver का बैलेंस बढ़ाएं
            $new_receiver_bal = $receiver['wallet_balance'] + $amount;
            $stmt = $pdo->prepare("UPDATE users SET wallet_balance = ? WHERE id = ?");
            $stmt->execute([$new_receiver_bal, $receiver['id']]);

            // 3. Transactions टेबल में रिकॉर्ड (Sender Side)
            $stmt = $pdo->prepare("INSERT INTO transactions (txn_id, user_id, service_type, provider_used, amount, status) VALUES (?, ?, 'Wallet Transfer', 'Internal', ?, 'SUCCESS')");
            $stmt->execute([$txn_id, $sender_id, $amount]);

            // 4. Wallet Ledger में एंट्री (Sender: DEBIT)
            $desc_sender = "Sent to " . $receiver['full_name'] . " (" . $receiver_mobile . ")";
            $stmt = $pdo->prepare("INSERT INTO wallet_ledger (user_id, txn_id, type, amount, closing_balance, description) VALUES (?, ?, 'DEBIT', ?, ?, ?)");
            $stmt->execute([$sender_id, $txn_id, $amount, $new_sender_bal, $desc_sender]);

            // 5. Wallet Ledger में एंट्री (Receiver: CREDIT)
            $desc_receiver = "Received from " . $sender['full_name'];
            $stmt = $pdo->prepare("INSERT INTO wallet_ledger (user_id, txn_id, type, amount, closing_balance, description) VALUES (?, ?, 'CREDIT', ?, ?, ?)");
            $stmt->execute([$receiver['id'], $txn_id, $amount, $new_receiver_bal, $desc_receiver]);

            $pdo->commit();
            $message = "Successfully transferred ₹$amount to " . $receiver['full_name'];
            $status_class = "success";

        } catch (Exception $e) {
            $pdo->rollBack();
            $message = $e->getMessage();
            $status_class = "error";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Send Money - SuperPay</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --primary: #4F46E5; --bg: #F3F4F6; }
        body { font-family: 'Segoe UI', sans-serif; background: var(--bg); margin: 0; display: flex; justify-content: center; }
        .app-container { width: 100%; max-width: 480px; background: #fff; min-height: 100vh; box-shadow: 0 0 20px rgba(0,0,0,0.05); }
        .header { background: var(--primary); color: white; padding: 20px; display: flex; align-items: center; gap: 15px; font-weight: 600; }
        .content { padding: 20px; }
        .balance-card { background: linear-gradient(135deg, #4F46E5, #6366F1); color: white; padding: 25px; border-radius: 16px; margin-bottom: 25px; text-align: center; }
        .input-group { margin-bottom: 20px; }
        .input-group label { display: block; font-size: 13px; font-weight: 600; color: #4B5563; margin-bottom: 8px; }
        .input-group input { width: 100%; padding: 14px; border: 1px solid #D1D5DB; border-radius: 10px; box-sizing: border-box; font-size: 16px; }
        .btn-send { width: 100%; background: var(--primary); color: white; border: none; padding: 16px; border-radius: 10px; font-size: 16px; font-weight: bold; cursor: pointer; transition: 0.3s; }
        .btn-send:hover { background: #4338CA; }
        .alert { padding: 15px; border-radius: 10px; margin-bottom: 20px; font-size: 14px; }
        .alert.success { background: #D1FAE5; color: #065F46; border: 1px solid #A7F3D0; }
        .alert.error { background: #FEE2E2; color: #991B1B; border: 1px solid #FECACA; }
    </style>
</head>
<body>

<div class="app-container">
    <div class="header">
        <i class="fas fa-arrow-left" onclick="window.location.href='index.php'"></i>
        Send Money to Wallet
    </div>

    <div class="content">
        <div class="balance-card">
            <p style="margin:0; opacity:0.8; font-size:14px;">Your Balance</p>
            <h1 style="margin:10px 0 0 0;">₹<?php echo number_format($_SESSION['wallet_balance'], 2); ?></h1>
        </div>

        <?php if($message): ?>
            <div class="alert <?php echo $status_class; ?>">
                <i class="fas <?php echo $status_class == 'success' ? 'fa-check-circle' : 'fa-exclamation-triangle'; ?>"></i>
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="">
            <div class="input-group">
                <label>Receiver Mobile Number</label>
                <input type="tel" name="receiver_mobile" placeholder="Enter 10 digit mobile" required pattern="[0-9]{10}">
            </div>

            <div class="input-group">
                <label>Amount (₹)</label>
                <input type="number" name="amount" placeholder="Min ₹1" required min="1">
            </div>

            <div class="input-group">
                <label>Remarks (Optional)</label>
                <input type="text" name="remarks" placeholder="Gift, Food, etc.">
            </div>

            <button type="submit" name="send_money" class="btn-send">Send Money Now</button>
        </form>
    </div>
</div>

</body>
</html>
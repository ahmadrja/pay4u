<?php
session_start();

// Security Check: User logged in hona chahiye
// if(!isset($_SESSION['user_id'])) {
//     header("Location: login.php");
//     exit;
// }

$user_id = $_SESSION['user_id'] ?? 101; 
$wallet_balance = $_SESSION['wallet_balance'] ?? 5430.00;
$message = "";
$status_class = "";

// ---------------------------------------------------------
// 🚀 BACKEND LOGIC: RECHARGE PROCESSING
// ---------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['pay_now'])) {
    
    // 1. Sanitize & Validate Inputs
    $mobile = htmlspecialchars($_POST['mobile_number']);
    $operator = htmlspecialchars($_POST['operator']);
    $amount = floatval($_POST['amount']);
    
    // Basic Validation
    if (empty($mobile) || empty($operator) || $amount <= 0) {
        $message = "Please fill all details correctly.";
        $status_class = "error";
    } 
    // 2. Check Wallet Balance
    elseif ($wallet_balance < $amount) {
        $message = "Insufficient Wallet Balance! Please add money.";
        $status_class = "error";
    } 
    else {
        // ========================================================
        // 🔒 ENTERPRISE FINTECH LOGIC STARTS HERE
        // Real app mein aap yahan PDO DB connection use karenge:
        // $pdo->beginTransaction();
        // ========================================================

        try {
            // STEP A: Wallet se paisa deduct karein (Temporary pending state)
            $new_balance = $wallet_balance - $amount;
            $_SESSION['wallet_balance'] = $new_balance; // Updating session for demo
            
            // Generate a unique Transaction ID
            $txn_id = "TXN" . date("YmdHis") . rand(1000, 9999);

            // STEP B: Database mein transaction insert karein with Status = 'PENDING'
            // Query: INSERT INTO transactions (user_id, txn_id, type, amount, status) VALUES (?, ?, 'Recharge', ?, 'PENDING')

            // STEP C: 3rd Party API Call (Mrobotics / Cyberplat / Lapu)
            /* $api_url = "https://api.rechargeprovider.com/v1/recharge";
               $api_data = [
                   'api_token' => 'YOUR_SECRET_API_KEY',
                   'mobile'    => $mobile,
                   'operator'  => $operator,
                   'amount'    => $amount,
                   'ref_id'    => $txn_id
               ];
               
               $ch = curl_init($api_url);
               curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
               curl_setopt($ch, CURLOPT_POST, true);
               curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($api_data));
               $response = curl_exec($ch);
               curl_close($ch);
               
               $api_result = json_decode($response, true);
            */

            // SIMULATING API RESPONSE (Demo purpose ke liye success man rahe hain)
            $api_result = ['status' => 'SUCCESS', 'op_ref' => 'OPR987654321']; 

            // STEP D: Handle API Response
            if ($api_result['status'] == 'SUCCESS') {
                // Success Scenario
                // Query: UPDATE transactions SET status = 'SUCCESS', operator_ref = ? WHERE txn_id = ?
                // $pdo->commit(); // Save all database changes permanently
                
                $message = "Recharge Successful! TXN ID: " . $txn_id;
                $status_class = "success";
                
                // Optional: Admin Commission add karne ka logic yahan aayega
            } 
            else {
                // Failed Scenario (API ne reject kar diya)
                throw new Exception("Recharge failed by operator. Automatically refunding to wallet.");
            }

        } catch (Exception $e) {
            // ========================================================
            // 🚨 ROLLBACK LOGIC (Refund to User)
            // ========================================================
            // $pdo->rollBack(); // Undo all database deductions
            
            // Refund the balance back to session (for demo)
            $_SESSION['wallet_balance'] = $wallet_balance; 
            
            // Query: UPDATE transactions SET status = 'FAILED' WHERE txn_id = ?
            
            $message = $e->getMessage();
            $status_class = "error";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mobile Recharge - SuperPay</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --primary: #4F46E5; --bg-color: #F3F4F6; --card-bg: #FFFFFF; }
        body { font-family: 'Segoe UI', sans-serif; background: var(--bg-color); margin: 0; padding: 0; display: flex; justify-content: center; }
        .app-container { width: 100%; max-width: 480px; background: var(--card-bg); min-height: 100vh; position: relative; }
        
        .header { background: var(--primary); color: white; padding: 20px; display: flex; align-items: center; gap: 15px; font-size: 18px; font-weight: 600;}
        .header i { cursor: pointer; }
        
        .form-container { padding: 30px 20px; }
        .balance-chip { display: inline-block; background: #EEF2FF; color: var(--primary); padding: 8px 15px; border-radius: 20px; font-size: 14px; font-weight: 600; margin-bottom: 25px; border: 1px solid #C7D2FE;}
        
        .input-group { margin-bottom: 20px; }
        .input-group label { display: block; font-size: 13px; color: #4B5563; margin-bottom: 8px; font-weight: 600; }
        .input-group input, .input-group select { width: 100%; padding: 14px; border: 1px solid #D1D5DB; border-radius: 10px; font-size: 15px; outline: none; transition: 0.3s; box-sizing: border-box; }
        .input-group input:focus, .input-group select:focus { border-color: var(--primary); box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.1); }
        
        .btn-pay { width: 100%; background: var(--primary); color: white; border: none; padding: 15px; border-radius: 10px; font-size: 16px; font-weight: 600; cursor: pointer; transition: 0.2s; margin-top: 10px;}
        .btn-pay:hover { background: #4338CA; }
        
        .alert { padding: 15px; border-radius: 8px; margin-bottom: 20px; font-size: 14px; font-weight: 500; display: flex; align-items: center; gap: 10px;}
        .alert.success { background: #D1FAE5; color: #065F46; border: 1px solid #A7F3D0; }
        .alert.error { background: #FEE2E2; color: #991B1B; border: 1px solid #FECACA; }
    </style>
</head>
<body>

    <div class="app-container">
        <div class="header">
            <i class="fas fa-arrow-left" onclick="window.location.href='index.php'"></i>
            Mobile Recharge
        </div>

        <div class="form-container">
            <div class="balance-chip">
                <i class="fas fa-wallet"></i> Wallet Balance: ₹<?php echo number_format($_SESSION['wallet_balance'], 2); ?>
            </div>

            <?php if(!empty($message)): ?>
                <div class="alert <?php echo $status_class; ?>">
                    <i class="fas <?php echo $status_class == 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'; ?>"></i>
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="">
                <div class="input-group">
                    <label>Mobile Number</label>
                    <input type="tel" name="mobile_number" placeholder="Enter 10-digit number" pattern="[0-9]{10}" required autocomplete="off">
                </div>

                <div class="input-group">
                    <label>Operator</label>
                    <select name="operator" required>
                        <option value="">Select Operator</option>
                        <option value="JIO">Reliance Jio</option>
                        <option value="AIRTEL">Bharti Airtel</option>
                        <option value="VI">Vodafone Idea (Vi)</option>
                        <option value="BSNL">BSNL</option>
                    </select>
                </div>

                <div class="input-group">
                    <label>Amount (₹)</label>
                    <input type="number" name="amount" placeholder="Enter amount" min="10" required>
                </div>

                <button type="submit" name="pay_now" class="btn-pay" id="payBtn" onclick="this.innerHTML='<i class=\'fas fa-spinner fa-spin\'></i> Processing...';">
                    Proceed to Pay
                </button>
            </form>
        </div>
    </div>

</body>
</html>
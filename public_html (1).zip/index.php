<?php
// Session start karein taaki user data access ho sake
session_start();

// Security Check (Uncomment in production)
// if(!isset($_SESSION['user_id'])) {
//     header("Location: login.php");
//     exit;
// }

// Simulated Database Values (Real app mein ye DB se fetch honge)
$user_name = $_SESSION['user_name'] ?? 'Rahul Kumar';
$kyc_status = $_SESSION['kyc_status'] ?? 'verified'; 
$wallet_balance = $_SESSION['wallet_balance'] ?? 5430.00;
$reward_points = $_SESSION['reward_points'] ?? 250; // New: Loyalty Points

// Dynamic Banners for Monetization & Cross-selling
$promo_banners = [
    ["title" => "Get 10% Cashback on Flights!", "bg" => "linear-gradient(135deg, #FF9A9E 0%, #FECFEF 100%)", "icon" => "fa-plane-departure"],
    ["title" => "Apply for HDFC Credit Card & Earn ₹500", "bg" => "linear-gradient(135deg, #84FAB0 0%, #8FD3F4 100%)", "icon" => "fa-credit-card"]
];

// Recent Transactions for Trust Building
$recent_txns = [
    ["name" => "Jio Recharge", "date" => "Today, 10:45 AM", "amount" => "-₹299", "status" => "Success", "color" => "#EF4444"],
    ["name" => "Money Added", "date" => "Yesterday, 02:30 PM", "amount" => "+₹1000", "status" => "Success", "color" => "#10B981"]
];

// Dynamic Greeting
$time = date("H");
if ($time < 12) { $greeting = "Good Morning"; } 
elseif ($time < 17) { $greeting = "Good Afternoon"; } 
else { $greeting = "Good Evening"; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SuperPay - All-in-One Service</title>
    <link href="assets/css/style.css?v=1.0" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <style>
        :root {
            --primary: #4F46E5;
            --secondary: #10B981;
            --bg-color: #F3F4F6;
            --card-bg: #FFFFFF;
        }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: var(--bg-color); margin: 0; padding: 0; }
        .app-container { max-width: 480px; margin: 0 auto; background: var(--card-bg); min-height: 100vh; box-shadow: 0 0 20px rgba(0,0,0,0.05); padding-bottom: 20px;}
        
        /* Header */
        .top-header { display: flex; justify-content: space-between; align-items: center; padding: 20px; background: var(--card-bg); border-bottom: 1px solid #E5E7EB; }
        .user-info { display: flex; align-items: center; gap: 15px; }
        .avatar { width: 45px; height: 45px; border-radius: 50%; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .user-info h4 { margin: 0; font-size: 16px; color: #1F2937; }
        .kyc-badge { font-size: 12px; font-weight: 600; padding: 3px 8px; border-radius: 12px; display: inline-block; margin-top: 5px; background: #F3F4F6;}
        .notification-icon { font-size: 20px; color: #6B7280; cursor: pointer; position: relative; }
        .notification-icon::after { content: ''; position: absolute; top: 0; right: 0; width: 8px; height: 8px; background: #EF4444; border-radius: 50%; border: 2px solid #FFF;}

        /* Wallet Card */
        .wallet-card { margin: 20px; padding: 25px; background: linear-gradient(135deg, var(--primary) 0%, #3730A3 100%); color: white; border-radius: 16px; box-shadow: 0 10px 15px -3px rgba(79, 70, 229, 0.4); position: relative; overflow: hidden;}
        .wallet-card p { margin: 0; font-size: 14px; opacity: 0.9; }
        .wallet-card h2 { margin: 10px 0; font-size: 32px; font-weight: 700; display: flex; align-items: center; gap: 10px;}
        .refresh-btn { font-size: 16px; cursor: pointer; opacity: 0.8; transition: 0.3s; }
        .refresh-btn:hover { opacity: 1; transform: rotate(180deg); }
        .reward-points { background: rgba(255,255,255,0.2); padding: 5px 12px; border-radius: 20px; font-size: 12px; font-weight: 600; display: inline-flex; align-items: center; gap: 5px; margin-bottom: 15px;}
        .wallet-actions { display: flex; gap: 10px; margin-top: 20px; }
        .wallet-actions button { flex: 1; padding: 12px; border: none; border-radius: 10px; font-weight: 600; cursor: pointer; display: flex; justify-content: center; align-items: center; gap: 8px; transition: 0.2s;}
        .btn-add { background: white; color: var(--primary); }
        .btn-history { background: rgba(255,255,255,0.2); color: white; }
        
        /* Promo Slider (Monetization) */
        .promo-slider { display: flex; overflow-x: auto; gap: 15px; padding: 0 20px; margin-bottom: 25px; scrollbar-width: none; }
        .promo-slider::-webkit-scrollbar { display: none; }
        .promo-card { min-width: 260px; padding: 15px; border-radius: 12px; display: flex; align-items: center; gap: 15px; color: #1F2937; font-weight: 600; font-size: 14px; cursor: pointer; box-shadow: 0 4px 6px rgba(0,0,0,0.05);}
        .promo-card i { font-size: 24px; color: #fff; background: rgba(0,0,0,0.2); padding: 10px; border-radius: 50%; }

        /* Services Grid */
        .services-section { padding: 0 20px; }
        .services-section h3 { font-size: 16px; color: #1F2937; margin-bottom: 15px; }
        .grid-container { display: grid; grid-template-columns: repeat(4, 1fr); gap: 15px; margin-bottom: 25px; }
        .service-item { display: flex; flex-direction: column; align-items: center; gap: 8px; cursor: pointer; transition: transform 0.2s;}
        .service-item:hover { transform: translateY(-3px); }
        .service-icon { width: 50px; height: 50px; background: #EEF2FF; color: var(--primary); display: flex; justify-content: center; align-items: center; border-radius: 12px; font-size: 20px; }
        .service-item span { font-size: 12px; color: #4B5563; font-weight: 500; text-align: center; }

        /* Recent Transactions */
        .recent-txns { padding: 0 20px; margin-top: 10px;}
        .txn-item { display: flex; justify-content: space-between; align-items: center; padding: 15px 0; border-bottom: 1px solid #F3F4F6; }
        .txn-info h4 { margin: 0; font-size: 14px; color: #1F2937; }
        .txn-info p { margin: 5px 0 0 0; font-size: 12px; color: #9CA3AF; }
        .txn-amount { text-align: right; font-weight: 600; font-size: 14px; }
    </style>
</head>
<body>
    <div class="app-container">
        <header class="top-header">
            <div class="user-info">
                <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($user_name); ?>&background=4F46E5&color=fff" alt="Profile" class="avatar">
                <div>
                    <h4><?php echo $greeting . ", " . htmlspecialchars(explode(" ", $user_name)[0]); ?></h4>
                    <?php if($kyc_status === 'verified'): ?>
                        <span class="kyc-badge" style="color: var(--secondary);"><i class="fas fa-check-circle"></i> KYC Verified</span>
                    <?php else: ?>
                        <span class="kyc-badge" style="color: #F59E0B;"><i class="fas fa-exclamation-triangle"></i> KYC Pending</span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="notification-icon" onclick="window.location.href='notifications.php'">
                <i class="fas fa-bell"></i>
            </div>
        </header>

        <section class="wallet-card">
            <div class="reward-points">
                <i class="fas fa-coins" style="color: #FBBF24;"></i> <?php echo $reward_points; ?> SuperCoins
            </div>
            <p>Available Balance</p>
            <h2>
                ₹ <span id="walletBalance"><?php echo number_format($wallet_balance, 2); ?></span>
                <i class="fas fa-sync-alt refresh-btn" onclick="refreshBalance()" title="Refresh Balance"></i>
            </h2>
            <div class="wallet-actions">
                <button class="btn-add" onclick="addMoney()"><i class="fas fa-plus"></i> Add Money</button>
                <button class="btn-history" onclick="window.location.href='history.php'"><i class="fas fa-history"></i> History</button>
            </div>
        </section>

        <div class="promo-slider">
            <?php foreach($promo_banners as $promo): ?>
                <div class="promo-card" style="background: <?php echo $promo['bg']; ?>;">
                    <i class="fas <?php echo $promo['icon']; ?>"></i>
                    <span><?php echo $promo['title']; ?></span>
                </div>
            <?php endforeach; ?>
        </div>

        <section class="services-section">
            <h3>Recharge & Pay Bills</h3>
            <div class="grid-container">
                <div class="service-item" onclick="window.location.href='recharge.php?type=mobile'">
                    <div class="service-icon"><i class="fas fa-mobile-alt"></i></div>
                    <span>Mobile</span>
                </div>
                <div class="service-item" onclick="window.location.href='recharge.php?type=dth'">
                    <div class="service-icon"><i class="fas fa-satellite-dish"></i></div>
                    <span>DTH</span>
                </div>
                <div class="service-item" onclick="window.location.href='pay_bill.php?type=electricity'">
                    <div class="service-icon"><i class="fas fa-lightbulb"></i></div>
                    <span>Electricity</span>
                </div>
                <div class="service-item" onclick="window.location.href='recharge.php?type=fastag'">
                    <div class="service-icon"><i class="fas fa-car"></i></div>
                    <span>FASTag</span>
                </div>
            </div>

            <h3>Travel & Transfers</h3>
            <div class="grid-container">
                <div class="service-item" onclick="window.location.href='flight_booking.php'">
                    <div class="service-icon"><i class="fas fa-plane"></i></div>
                    <span>Flights</span>
                </div>
                <div class="service-item" onclick="window.location.href='hotel_booking.php'">
                    <div class="service-icon"><i class="fas fa-hotel"></i></div>
                    <span>Hotels</span>
                </div>
                <div class="service-item" onclick="window.location.href='bank_transfer.php'">
                    <div class="service-icon"><i class="fas fa-exchange-alt"></i></div>
                    <span>Bank Transfer</span>
                </div>
                <div class="service-item" onclick="window.location.href='more_services.php'">
                    <div class="service-icon"><i class="fas fa-ellipsis-h"></i></div>
                    <span>More</span>
                </div>
            </div>
        </section>

        <section class="recent-txns">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                <h3 style="margin:0; font-size: 16px; color: #1F2937;">Recent Activity</h3>
                <a href="history.php" style="font-size: 12px; color: var(--primary); text-decoration: none; font-weight: 600;">View All</a>
            </div>
            
            <?php foreach($recent_txns as $txn): ?>
                <div class="txn-item">
                    <div style="display: flex; gap: 15px; align-items: center;">
                        <div style="width: 40px; height: 40px; background: #F3F4F6; border-radius: 50%; display: flex; justify-content: center; align-items: center; color: #6B7280;">
                            <i class="fas fa-receipt"></i>
                        </div>
                        <div class="txn-info">
                            <h4><?php echo $txn['name']; ?></h4>
                            <p><?php echo $txn['date']; ?></p>
                        </div>
                    </div>
                    <div class="txn-amount" style="color: <?php echo $txn['color']; ?>;">
                        <?php echo $txn['amount']; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </section>
    </div>

    <script>
        // Dummy function for Add Money
        function addMoney() {
            window.location.href = 'add_money.php';
        }

        // AJAX Simulation for Real-Time Balance Refresh
        function refreshBalance() {
            const balanceElement = document.getElementById('walletBalance');
            const icon = document.querySelector('.refresh-btn');
            
            // Add spinning animation
            icon.classList.add('fa-spin');
            
            // Simulate API Call (Aap yahan fetch/AJAX lagayenge real API ke liye)
            setTimeout(() => {
                // Remove animation
                icon.classList.remove('fa-spin');
                // Optional: alert('Balance is up to date!');
            }, 1000);
        }
    </script>
</body>
</html>
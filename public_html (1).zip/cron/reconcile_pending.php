<?php
// Security check: Only allow CLI execution or secure token verification
if (php_sapi_name() !== 'cli' && (!isset($_GET['cron_key']) || $_GET['cron_key'] !== 'SECURE_RANDOM_CRON_KEY_123!')) {
    http_response_code(403);
    exit("Access Denied");
}

require_once dirname(__DIR__) . '/config/database.php'; // Absolute path for cron

$database = new Database();
$db = $database->getConnection();

echo "Starting Reconciliation Process...\n";

try {
    // Puraane 'pending' transactions fetch karein (Jo pichle 15 min se 24 ghante ke beech ke hain)
    // 15 min ka gap isliye taaki jo transactions abhi process ho rahe hain, unhe disturb na karein.
    $stmt = $db->prepare("
        SELECT id, txn_id, user_id, amount, service_type 
        FROM transactions 
        WHERE status = 'pending' 
        AND created_at BETWEEN DATE_SUB(NOW(), INTERVAL 24 HOUR) AND DATE_SUB(NOW(), INTERVAL 15 MINUTE)
    ");
    $stmt->execute();
    $pending_txns = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (count($pending_txns) === 0) {
        echo "No pending transactions found.\n";
        exit;
    }

    foreach ($pending_txns as $txn) {
        echo "Checking TXN: " . $txn['txn_id'] . "...\n";

        // Yahan aapko Third-Party API ka "Status Check" endpoint call karna hoga
        // e.g., https://api.rechargeprovider.com/v1/status?txn_id=...
        
        $api_status = 'failed'; // Assume API returned 'failed' for this example
        
        if ($api_status === 'success') {
            // Update status to success
            $upd = $db->prepare("UPDATE transactions SET status = 'success' WHERE txn_id = ?");
            $upd->execute([$txn['txn_id']]);
            echo "-> Marked as Success.\n";

        } elseif ($api_status === 'failed') {
            // Transaction fail ho gaya tha, par paise cut gaye the. Auto-Refund process karein!
            $db->beginTransaction();
            
            // Refund to wallet
            $refund = $db->prepare("UPDATE wallets SET balance = balance + ? WHERE user_id = ?");
            $refund->execute([$txn['amount'], $txn['user_id']]);

            // Update status
            $updFail = $db->prepare("UPDATE transactions SET status = 'failed' WHERE txn_id = ?");
            $updFail->execute([$txn['txn_id']]);

            // Log refund entry (Optional but recommended for clear ledger)
            $refund_txn_id = "REF" . time() . rand(100,999);
            $log = $db->prepare("INSERT INTO transactions (user_id, txn_id, type, amount, service_type, status, description) VALUES (?, ?, 'credit', ?, 'refund', 'success', ?)");
            $log->execute([$txn['user_id'], $refund_txn_id, $txn['amount'], 'Refund for Failed TXN: ' . $txn['txn_id']]);

            $db->commit();
            echo "-> Marked as Failed. Refund Processed.\n";
        }
    }

    echo "Reconciliation Complete.\n";

} catch (Exception $e) {
    if ($db->inTransaction()) $db->rollBack();
    echo "Error: " . $e->getMessage() . "\n";
}
?>
<?php
session_start();
// डेटाबेस कनेक्शन को शामिल करें (ध्यान दें: config फ़ोल्डर आपके मेन फ़ोल्डर में होना चाहिए)
require_once 'config/database.php';

// Security Check
if(!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// =========================================================================
// ⚙️ BACKEND API LOGIC (यह हिस्सा सिर्फ तब चलेगा जब 'Pay' बटन पर क्लिक होगा)
// =========================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    $data = json_decode(file_get_contents("php://input"), true);
    
    $amount = floatval($data['amount'] ?? 0);
    $consumer_no = htmlspecialchars($data['consumer_no'] ?? '');
    $board = htmlspecialchars($data['board'] ?? '');
    $category = htmlspecialchars($data['category'] ?? 'Utility');

    if ($amount <= 0 || empty($consumer_no) || empty($board)) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid payment details.']);
        exit;
    }

    try {
        // 1. Wallet Balance Check (FOR UPDATE prevents double spending)
        $stmt = $pdo->prepare("SELECT wallet_balance FROM users WHERE id = ? FOR UPDATE");
        $stmt->execute([$user_id]);
        $user = $stmt->fetch();

        if (!$user || $user['wallet_balance'] < $amount) {
            echo json_encode(['status' => 'error', 'message' => 'Insufficient Wallet Balance! Add money.']);
            exit;
        }

        // 2. MASTER ADMIN CONTROL: Fetch Active BBPS API dynamically
        $stmt = $pdo->prepare("SELECT * FROM api_providers WHERE service_type = 'BBPS' AND status = 'active' ORDER BY priority ASC LIMIT 1");
        $stmt->execute();
        $active_api = $stmt->fetch();

        if (!$active_api) {
            echo json_encode(['status' => 'error', 'message' => 'Bill Payment service is temporarily down.']);
            exit;
        }

        $txn_id = "BBPS" . date("YmdHis") . rand(1000, 9999);
        $profit_earned = ($amount * $active_api['admin_margin_percent']) / 100;
        $api_ref_id = "BBPS_OPR_" . rand(111111, 999999);

        // 3. DATABASE UPDATES (Transaction & Ledger)
        $pdo->beginTransaction();

        $new_balance = $user['wallet_balance'] - $amount;
        $stmt = $pdo->prepare("UPDATE users SET wallet_balance = ? WHERE id = ?");
        $stmt->execute([$new_balance, $user_id]);
        $_SESSION['wallet_balance'] = $new_balance; // Update session

        $stmt = $pdo->prepare("INSERT INTO transactions (txn_id, user_id, service_type, provider_used, amount, profit_earned, operator_ref, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'SUCCESS')");
        $stmt->execute([$txn_id, $user_id, $category . ' Bill', $active_api['provider_name'], $amount, $profit_earned, $api_ref_id]);

        $desc = "Paid " . $category . " Bill for " . $consumer_no . " (" . $board . ")";
        $stmt = $pdo->prepare("INSERT INTO wallet_ledger (user_id, txn_id, type, amount, closing_balance, description) VALUES (?, ?, 'DEBIT', ?, ?, ?)");
        $stmt->execute([$user_id, $txn_id, $amount, $new_balance, $desc]);

        $pdo->commit();

        echo json_encode(['status' => 'success', 'message' => 'Bill Paid Successfully!', 'txn_id' => $txn_id]);
        exit;

    } catch (Exception $e) {
        if ($pdo->inTransaction()) { $pdo->rollBack(); }
        error_log("BBPS Error: " . $e->getMessage());
        echo json_encode(['status' => 'error', 'message' => 'Transaction failed. Please try again later.']);
        exit;
    }
}

// =========================================================================
// 🌐 FRONTEND UI LOGIC (यह हिस्सा तब चलेगा जब यूज़र पेज खोलेगा)
// =========================================================================
$wallet_balance = $_SESSION['wallet_balance'] ?? 0.00;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pay Utility Bills - SuperPay</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --primary: #4F46E5; --bg-color: #F3F4F6; --card-bg: #FFFFFF; }
        body { font-family: 'Segoe UI', sans-serif; background: var(--bg-color); margin: 0; display: flex; justify-content: center; }
        .app-container { width: 100%; max-width: 480px; background: var(--card-bg); min-height: 100vh; position: relative; box-shadow: 0 0 20px rgba(0,0,0,0.05); }
        
        .header { background: var(--primary); color: white; padding: 20px; display: flex; align-items: center; gap: 15px; font-size: 18px; font-weight: 600; }
        .header i { cursor: pointer; }
        
        .form-container { padding: 20px; }
        .input-group { margin-bottom: 20px; }
        .input-group label { display: block; font-size: 13px; color: #4B5563; margin-bottom: 8px; font-weight: 600; }
        .input-group select, .input-group input { width: 100%; padding: 14px; border: 1px solid #D1D5DB; border-radius: 10px; font-size: 15px; outline: none; box-sizing: border-box; }
        .input-group select:focus, .input-group input:focus { border-color: var(--primary); box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.1); }
        
        .btn-action { width: 100%; background: var(--primary); color: white; border: none; padding: 15px; border-radius: 10px; font-size: 16px; font-weight: 600; cursor: pointer; transition: 0.2s; }
        .btn-action:hover { background: #4338CA; }
        
        /* Bill Fetch Details Card */
        #billDetailsCard { display: none; background: #F9FAFB; border: 1px solid #E5E7EB; border-radius: 12px; padding: 20px; margin-top: 20px; }
        .bill-row { display: flex; justify-content: space-between; margin-bottom: 10px; font-size: 14px; }
        .bill-amount { font-size: 24px; font-weight: bold; color: #1F2937; margin-bottom: 15px; text-align: center; }
        
        /* Toast Notification */
        #toast { visibility: hidden; min-width: 250px; background-color: #333; color: #fff; text-align: center; border-radius: 8px; padding: 16px; position: fixed; z-index: 1001; left: 50%; bottom: 30px; transform: translateX(-50%); opacity: 0; transition: 0.3s; }
        #toast.show { visibility: visible; bottom: 50px; opacity: 1; }
    </style>
</head>
<body>

    <div class="app-container">
        <div class="header">
            <i class="fas fa-arrow-left" onclick="window.location.href='index.php'"></i>
            Pay Utility Bills
        </div>

        <div class="form-container">
            <div style="background: #EEF2FF; color: var(--primary); padding: 10px 15px; border-radius: 8px; font-weight: 600; font-size: 14px; margin-bottom: 20px;">
                <i class="fas fa-wallet"></i> Wallet Balance: ₹<?php echo number_format($wallet_balance, 2); ?>
            </div>

            <div class="input-group">
                <label>Biller Category</label>
                <select id="billerCategory">
                    <option value="Electricity">Electricity</option>
                    <option value="Water">Water</option>
                    <option value="Gas">Piped Gas</option>
                    <option value="Broadband">Broadband</option>
                </select>
            </div>

            <div class="input-group">
                <label>Select Biller Board</label>
                <select id="billerBoard">
                    <option value="UPPCL">Uttar Pradesh Power Corp (UPPCL)</option>
                    <option value="BSES_RAJDHANI">BSES Rajdhani Power Limited</option>
                    <option value="MAHAVITARAN">Maharashtra State Electricity (MSEDCL)</option>
                    <option value="NBPDCL">North Bihar Power Distribution</option>
                </select>
            </div>

            <div class="input-group">
                <label>Consumer Number / CA Number</label>
                <input type="text" id="consumerNumber" placeholder="Enter Consumer ID" required autocomplete="off">
            </div>

            <button class="btn-action" id="fetchBtn" onclick="fetchBill()">Fetch Bill</button>

            <div id="billDetailsCard">
                <div class="bill-amount" id="displayAmount">₹ 0.00</div>
                <div class="bill-row">
                    <span style="color: #6B7280;">Customer Name:</span>
                    <strong id="displayName" style="color: #1F2937;">-</strong>
                </div>
                <div class="bill-row">
                    <span style="color: #6B7280;">Due Date:</span>
                    <strong id="displayDueDate" style="color: #EF4444;">-</strong>
                </div>
                
                <input type="hidden" id="finalAmount">
                <button class="btn-action" id="payBtn" style="margin-top: 15px; background: #10B981;" onclick="processPayment()">
                    <i class="fas fa-check-circle"></i> Pay Securely
                </button>
            </div>
        </div>
    </div>

    <div id="toast">Notification</div>

    <script>
        // 1. Fetch Bill Logic
        function fetchBill() {
            const consumerNo = document.getElementById('consumerNumber').value;
            if(!consumerNo) { showToast('Please enter consumer number'); return; }

            const btn = document.getElementById('fetchBtn');
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Fetching from Biller...';
            btn.disabled = true;

            // Demo Fetch Logic
            setTimeout(() => {
                document.getElementById('displayAmount').innerText = '₹ 1,250.00';
                document.getElementById('finalAmount').value = '1250.00';
                document.getElementById('displayName').innerText = 'Ramesh Kumar';
                document.getElementById('displayDueDate').innerText = '25 Mar 2026';
                
                document.getElementById('billDetailsCard').style.display = 'block';
                btn.style.display = 'none'; 
            }, 1500);
        }

        // 2. Process Payment Logic (Sends request to this same file)
        function processPayment() {
            const payBtn = document.getElementById('payBtn');
            const amount = document.getElementById('finalAmount').value;
            const category = document.getElementById('billerCategory').value;
            const board = document.getElementById('billerBoard').value;
            const consumerNo = document.getElementById('consumerNumber').value;

            payBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
            payBtn.disabled = true;

            const payload = { category: category, board: board, consumer_no: consumerNo, amount: amount };

            // Requesting same file (window.location.href)
            fetch(window.location.href, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            })
            .then(res => res.json())
            .then(data => {
                if(data.status === 'success') {
                    showToast(data.message);
                    setTimeout(() => window.location.href = 'history.php', 2000); 
                } else {
                    showToast(data.message);
                    payBtn.innerHTML = '<i class="fas fa-check-circle"></i> Pay Securely';
                    payBtn.disabled = false;
                }
            })
            .catch(err => {
                showToast("Server Error! Please try again.");
                payBtn.innerHTML = '<i class="fas fa-check-circle"></i> Pay Securely';
                payBtn.disabled = false;
            });
        }

        function showToast(msg) {
            const toast = document.getElementById("toast");
            toast.innerText = msg;
            toast.className = "show";
            setTimeout(() => { toast.className = toast.className.replace("show", ""); }, 3000);
        }
    </script>
</body>
</html>
<?php
require_once '../config/database.php';

class CommissionManager {
    private $db;

    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
    }

    // Commission calculate aur distribute karne ka function
    public function distributeCommission($user_id, $service_type, $amount, $txn_id) {
        try {
            $this->db->beginTransaction();

            // 1. Service aur User Role ke hisaab se commission rate fetch karein (Assume settings table exists)
            // Example ke liye hum hardcode kar rahe hain, production mein DB se aayega
            $commission_rate = 0.02; // 2% Commission for Mobile Recharge

            $commission_amount = $amount * $commission_rate;

            if ($commission_amount > 0) {
                // 2. User ke wallet mein commission add karein
                $stmt = $this->db->prepare("UPDATE wallets SET balance = balance + ? WHERE user_id = ?");
                $stmt->execute([$commission_amount, $user_id]);

                // 3. Commission ka transaction log banayein
                $comm_txn_id = "COMM" . time() . rand(100,999);
                $logStmt = $this->db->prepare("INSERT INTO transactions (user_id, txn_id, type, amount, service_type, status, description) VALUES (?, ?, 'credit', ?, 'refund', 'success', ?)");
                $logStmt->execute([$user_id, $comm_txn_id, $commission_amount, "Commission for TXN: " . $txn_id]);
            }

            $this->db->commit();
            return true;
        } catch (Exception $e) {
            $this->db->rollBack();
            // Error log karna zaroori hai
            error_log("Commission Error: " . $e->getMessage());
            return false;
        }
    }
}
?>
<?php
session_start();

// Security Check (Production me uncomment karein)
// if(!isset($_SESSION['user_id'])) { header("Location: login.php"); exit; }

$user_id = $_SESSION['user_id'] ?? 101; 

// =========================================================================
// 🔄 BACKEND: FETCH LEDGER DATA
// =========================================================================
/* // Real Database Connection (PDO)
$host = 'localhost'; $dbname = 'superpay_db'; $user = 'root'; $pass = '';
$pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$stmt = $pdo->prepare("SELECT * FROM wallet_ledger WHERE user_id = ? ORDER BY created_at DESC LIMIT 50");
$stmt->execute([$user_id]);
$transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);
*/

// SIMULATED DATA (Real app me upar wale DB logic se aayega)
$transactions = [
    ["txn_id" => "TXN1001", "type" => "DEBIT", "amount" => "299.00", "closing_balance" => "5430.00", "description" => "Jio Recharge - 9876543210", "status" => "SUCCESS", "date" => "Today, 10:45 AM"],
    ["txn_id" => "TXN1002", "type" => "CREDIT", "amount" => "5000.00", "closing_balance" => "5729.00", "description" => "Money Added to Wallet via UPI", "status" => "SUCCESS", "date" => "Yesterday, 02:30 PM"],
    ["txn_id" => "TXN1003", "type" => "DEBIT", "amount" => "1250.00", "closing_balance" => "729.00", "description" => "Electricity Bill - UPPCL", "status" => "SUCCESS", "date" => "14 Mar 2026, 09:15 AM"],
    ["txn_id" => "TXN1004", "type" => "CREDIT", "amount" => "12.50", "closing_balance" => "1979.00", "description" => "Cashback Earned - Flight Booking", "status" => "SUCCESS", "date" => "12 Mar 2026, 06:20 PM"],
    ["txn_id" => "TXN1005", "type" => "DEBIT", "amount" => "500.00", "closing_balance" => "1966.50", "description" => "Failed DTH Recharge", "status" => "FAILED", "date" => "10 Mar 2026, 11:10 AM"]
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transaction History - SuperPay</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --primary: #4F46E5; --bg-color: #F3F4F6; --card-bg: #FFFFFF; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: var(--bg-color); margin: 0; padding: 0; display: flex; justify-content: center; }
        .app-container { width: 100%; max-width: 480px; background: var(--card-bg); min-height: 100vh; position: relative; box-shadow: 0 0 20px rgba(0,0,0,0.05); }
        
        /* Header */
        .header { background: var(--primary); color: white; padding: 20px; display: flex; align-items: center; justify-content: space-between; font-size: 18px; font-weight: 600; position: sticky; top: 0; z-index: 10;}
        .header i { cursor: pointer; }
        .download-btn { font-size: 14px; background: rgba(255,255,255,0.2); padding: 5px 12px; border-radius: 6px; text-decoration: none; color: white;}

        /* Filters */
        .filters { display: flex; gap: 10px; padding: 15px 20px; background: #F9FAFB; border-bottom: 1px solid #E5E7EB; overflow-x: auto;}
        .filter-btn { padding: 8px 16px; border: 1px solid #D1D5DB; border-radius: 20px; font-size: 13px; font-weight: 600; color: #4B5563; background: white; cursor: pointer; white-space: nowrap; transition: 0.2s;}
        .filter-btn.active { background: var(--primary); color: white; border-color: var(--primary); }

        /* Transaction List */
        .txn-list { padding: 0; margin: 0; list-style: none; }
        .txn-item { display: flex; justify-content: space-between; align-items: center; padding: 18px 20px; border-bottom: 1px solid #F3F4F6; transition: background 0.2s; cursor: pointer;}
        .txn-item:hover { background: #F9FAFB; }
        
        .txn-left { display: flex; gap: 15px; align-items: center; }
        .icon-box { width: 45px; height: 45px; border-radius: 50%; display: flex; justify-content: center; align-items: center; font-size: 18px; flex-shrink: 0;}
        .icon-credit { background: #D1FAE5; color: #10B981; }
        .icon-debit { background: #FEE2E2; color: #EF4444; }
        .icon-failed { background: #F3F4F6; color: #6B7280; }
        
        .txn-details h4 { margin: 0 0 5px 0; font-size: 15px; color: #1F2937; }
        .txn-details p { margin: 0; font-size: 12px; color: #6B7280; }
        .txn-details span.txn-id { display: block; font-size: 11px; color: #9CA3AF; margin-top: 3px; font-family: monospace;}
        
        .txn-right { text-align: right; }
        .amount { font-weight: 700; font-size: 16px; }
        .amount.credit { color: #10B981; }
        .amount.debit { color: #1F2937; }
        .amount.failed { color: #9CA3AF; text-decoration: line-through; }
        .closing-bal { display: block; font-size: 12px; color: #6B7280; margin-top: 5px; }
        
        .status-badge { font-size: 10px; font-weight: bold; padding: 2px 6px; border-radius: 4px; margin-top: 5px; display: inline-block;}
        .status-badge.failed { background: #FEE2E2; color: #EF4444; }
    </style>
</head>
<body>

    <div class="app-container">
        <div class="header">
            <div style="display: flex; align-items: center; gap: 15px;">
                <i class="fas fa-arrow-left" onclick="window.location.href='index.php'"></i>
                Passbook
            </div>
            <a href="#" class="download-btn"><i class="fas fa-download"></i> Statement</a>
        </div>

        <div class="filters">
            <button class="filter-btn active" onclick="filterTxn('ALL', this)">All</button>
            <button class="filter-btn" onclick="filterTxn('CREDIT', this)">Received</button>
            <button class="filter-btn" onclick="filterTxn('DEBIT', this)">Paid</button>
            <button class="filter-btn" onclick="filterTxn('FAILED', this)">Failed</button>
        </div>

        <ul class="txn-list" id="transactionList">
            <?php foreach($transactions as $txn): 
                
                // Icon Logic
                if($txn['status'] == 'FAILED') {
                    $icon_class = 'icon-failed';
                    $icon = 'fa-times';
                    $amt_class = 'failed';
                    $sign = '';
                } elseif($txn['type'] == 'CREDIT') {
                    $icon_class = 'icon-credit';
                    $icon = 'fa-arrow-down';
                    $amt_class = 'credit';
                    $sign = '+';
                } else {
                    $icon_class = 'icon-debit';
                    $icon = 'fa-arrow-up';
                    $amt_class = 'debit';
                    $sign = '-';
                }
            ?>
            <li class="txn-item" data-type="<?php echo $txn['type']; ?>" data-status="<?php echo $txn['status']; ?>" onclick="showReceipt('<?php echo $txn['txn_id']; ?>')">
                <div class="txn-left">
                    <div class="icon-box <?php echo $icon_class; ?>">
                        <i class="fas <?php echo $icon; ?>"></i>
                    </div>
                    <div class="txn-details">
                        <h4><?php echo htmlspecialchars($txn['description']); ?></h4>
                        <p><?php echo $txn['date']; ?></p>
                        <span class="txn-id">ID: <?php echo $txn['txn_id']; ?></span>
                        <?php if($txn['status'] == 'FAILED'): ?>
                            <div class="status-badge failed">FAILED</div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="txn-right">
                    <div class="amount <?php echo $amt_class; ?>">
                        <?php echo $sign; ?>₹<?php echo $txn['amount']; ?>
                    </div>
                    <?php if($txn['status'] == 'SUCCESS'): ?>
                        <span class="closing-bal">Bal: ₹<?php echo $txn['closing_balance']; ?></span>
                    <?php endif; ?>
                </div>
            </li>
            <?php endforeach; ?>
        </ul>
    </div>

    <script>
        // JS Logic for Filtering Transactions without reloading the page
        function filterTxn(type, btnElement) {
            // Update active button styling
            document.querySelectorAll('.filter-btn').forEach(btn => btn.classList.remove('active'));
            btnElement.classList.add('active');

            // Filter logic
            const items = document.querySelectorAll('.txn-item');
            items.forEach(item => {
                const itemType = item.getAttribute('data-type');
                const itemStatus = item.getAttribute('data-status');
                
                if (type === 'ALL') {
                    item.style.display = 'flex';
                } else if (type === 'FAILED') {
                    item.style.display = (itemStatus === 'FAILED') ? 'flex' : 'none';
                } else {
                    item.style.display = (itemType === type && itemStatus !== 'FAILED') ? 'flex' : 'none';
                }
            });
        }

        // Open specific receipt
        function showReceipt(txnId) {
            // Future logic: Redirect to a detailed receipt page
            // window.location.href = 'receipt.php?id=' + txnId;
            console.log("Viewing receipt for: " + txnId);
        }
    </script>
</body>
</html>
<?php
session_start();

// Security Check
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header("Location: login.php");
    exit;
}

require_once '../config/database.php';
$database = new Database();
$db = $database->getConnection();

$user_id = $_SESSION['user_id'];

// =========================================================================
// ⚙️ BACKEND AJAX: Process Recharge & Call API
// =========================================================================
$json_data = json_decode(file_get_contents("php://input"), true);

if ($json_data && isset($json_data['action']) && $json_data['action'] === 'process_recharge') {
    header('Content-Type: application/json');
    $mobile = trim($json_data['mobile']);
    $operator = $json_data['operator'];
    $amount = floatval($json_data['amount']);
    
    // 1. Basic Validation
    if (strlen($mobile) < 10 || $amount < 10) {
        echo json_encode(['success' => false, 'message' => 'Invalid Mobile Number or Amount (Min ₹10)']);
        exit;
    }

    try {
        $db->beginTransaction();

        // 2. User ka Balance Check Karein (LOCK FOR UPDATE lagaya hai taaki double tap fraud na ho)
        $stmt = $db->prepare("SELECT balance FROM wallets WHERE user_id = ? FOR UPDATE");
        $stmt->execute([$user_id]);
        $wallet = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$wallet || $wallet['balance'] < $amount) {
            $db->rollBack();
            echo json_encode(['success' => false, 'message' => 'Insufficient Wallet Balance! Please Add Money.']);
            exit;
        }

        // 3. Balance Deduct Karein (Pehle paise kaato)
        $new_balance = $wallet['balance'] - $amount;
        $update_wallet = $db->prepare("UPDATE wallets SET balance = ? WHERE user_id = ?");
        $update_wallet->execute([$new_balance, $user_id]);

        // 4. Transaction Generate Karein (Status 'processing')
        $txn_id = "TXN" . time() . rand(100, 999);
        $insert_txn = $db->prepare("INSERT INTO transactions (user_id, txn_id, service_type, amount, status) VALUES (?, ?, 'mobile_recharge', ?, 'processing')");
        $insert_txn->execute([$user_id, $txn_id, $amount]);
        
        // Transaction ID database wali
        $db_txn_id = $db->lastInsertId();

        $db->commit(); // Balance cut gaya aur history save ho gayi

        // =====================================================================
        // 🚀 5. API CALL ZONE (Mrobotics / Cyberplat)
        // Yahan asli API ka cURL request aayega. Abhi hum ise SIMULATE kar rahe hain.
        // =====================================================================
        
        // Simulating API Response (Asli API connect karne ke liye yahan cURL likhenge)
        $api_status = 'success'; // Ise badal kar 'failed' check kar sakte hain
        $operator_ref = "OPR" . rand(100000, 999999);

        if ($api_status === 'success') {
            // API Success - Status Update karein
            $db->prepare("UPDATE transactions SET status = 'success', updated_at = NOW() WHERE id = ?")->execute([$db_txn_id]);
            echo json_encode(['success' => true, 'message' => 'Recharge Successful!', 'balance' => $new_balance]);
            
        } else {
            // API Failed - REFUND LOGIC (Paise wapas user ke wallet mein daalein)
            $db->beginTransaction();
            $db->prepare("UPDATE transactions SET status = 'failed', updated_at = NOW() WHERE id = ?")->execute([$db_txn_id]);
            $db->prepare("UPDATE wallets SET balance = balance + ? WHERE user_id = ?")->execute([$amount, $user_id]);
            $db->commit();
            
            echo json_encode(['success' => false, 'message' => 'Recharge Failed by Operator. Amount Refunded.', 'balance' => $new_balance + $amount]);
        }
        exit;

    } catch (Exception $e) {
        if ($db->inTransaction()) { $db->rollBack(); }
        echo json_encode(['success' => false, 'message' => 'System Error: ' . $e->getMessage()]);
        exit;
    }
}

// Fetch current balance for UI
$wallet_stmt = $db->prepare("SELECT balance FROM wallets WHERE user_id = ?");
$wallet_stmt->execute([$user_id]);
$current_balance = $wallet_stmt->fetchColumn() ?: 0.00;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mobile Recharge - SuperPay</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --primary: #4F46E5; --bg: #F3F4F6; --card: #FFFFFF; --text-dark: #1F2937; }
        body { font-family: 'Segoe UI', sans-serif; background: var(--bg); margin: 0; padding: 20px; display: flex; justify-content: center; }
        .container { max-width: 450px; width: 100%; }
        
        .header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 25px; }
        .header-left { display: flex; align-items: center; gap: 15px; }
        .back-btn { color: var(--text-dark); font-size: 20px; text-decoration: none; }
        .header h2 { margin: 0; color: var(--text-dark); font-size: 20px; }
        .wallet-badge { background: #E0E7FF; color: var(--primary); padding: 5px 12px; border-radius: 20px; font-weight: bold; font-size: 13px; }

        .card { background: var(--card); padding: 25px; border-radius: 16px; box-shadow: 0 10px 25px rgba(0,0,0,0.05); }
        
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; font-size: 13px; font-weight: 600; color: #4B5563; margin-bottom: 8px; text-transform: uppercase; }
        .form-group input, .form-group select { width: 100%; padding: 14px; border: 2px solid #E5E7EB; border-radius: 10px; outline: none; font-size: 16px; color: var(--text-dark); box-sizing: border-box; transition: 0.3s; font-weight: bold; }
        .form-group input:focus, .form-group select:focus { border-color: var(--primary); }

        .btn-main { width: 100%; background: var(--primary); color: white; border: none; padding: 16px; border-radius: 10px; font-weight: bold; font-size: 16px; cursor: pointer; transition: 0.3s; display: flex; justify-content: center; gap: 10px; align-items: center; margin-top: 10px; }
        .btn-main:hover { background: #4338CA; transform: translateY(-2px); box-shadow: 0 8px 15px rgba(79,70,229,0.2); }
        .btn-main:disabled { background: #9CA3AF; cursor: not-allowed; transform: none; box-shadow: none; }

        #toast { visibility: hidden; min-width: 250px; text-align: center; border-radius: 8px; padding: 15px; position: fixed; z-index: 1000; left: 50%; bottom: 30px; transform: translateX(-50%); font-size: 14px; color: white; font-weight: bold; transition: opacity 0.3s; opacity: 0; }
        #toast.show { visibility: visible; bottom: 50px; opacity: 1; }
        .success-toast { background-color: #10B981; }
        .error-toast { background-color: #EF4444; }
    </style>
</head>
<body>

<div class="container">
    <div class="header">
        <div class="header-left">
            <a href="dashboard.php" class="back-btn"><i class="fas fa-arrow-left"></i></a>
            <h2>Mobile Recharge</h2>
        </div>
        <div class="wallet-badge" id="wallet_display">₹ <?php echo number_format($current_balance, 2); ?></div>
    </div>

    <div class="card">
        <form id="rechargeForm" onsubmit="processRecharge(event)">
            <div class="form-group">
                <label>Prepaid Mobile Number</label>
                <input type="text" id="mobile_no" maxlength="10" placeholder="Enter 10-digit number" required pattern="[0-9]{10}">
            </div>
            
            <div class="form-group">
                <label>Select Operator</label>
                <select id="operator" required>
                    <option value="" disabled selected>Select Network</option>
                    <option value="Airtel">Airtel</option>
                    <option value="Jio">Reliance Jio</option>
                    <option value="VI">Vodafone Idea (VI)</option>
                    <option value="BSNL">BSNL</option>
                </select>
            </div>

            <div class="form-group">
                <label>Amount (₹)</label>
                <input type="number" id="amount" placeholder="₹ 0" min="10" required>
            </div>

            <button type="submit" class="btn-main" id="payBtn">
                Proceed to Pay <i class="fas fa-chevron-right"></i>
            </button>
        </form>
    </div>
</div>

<div id="toast"></div>

<script>
    function processRecharge(e) {
        e.preventDefault();
        
        const btn = document.getElementById('payBtn');
        const mobile = document.getElementById('mobile_no').value;
        const operator = document.getElementById('operator').value;
        const amount = document.getElementById('amount').value;

        // Button Loading State
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
        btn.disabled = true;

        fetch(window.location.href, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'process_recharge', mobile: mobile, operator: operator, amount: amount })
        })
        .then(res => res.json())
        .then(data => {
            if(data.success) {
                showToast(data.message, 'success-toast');
                document.getElementById('rechargeForm').reset();
            } else {
                showToast(data.message, 'error-toast');
            }
            
            // Update Wallet Balance on UI instantly
            if(data.balance !== undefined) {
                document.getElementById('wallet_display').innerText = '₹ ' + parseFloat(data.balance).toFixed(2);
            }

            // Reset Button
            btn.innerHTML = 'Proceed to Pay <i class="fas fa-chevron-right"></i>';
            btn.disabled = false;
        })
        .catch(err => {
            showToast("Server Connection Failed.", "error-toast");
            btn.innerHTML = 'Proceed to Pay <i class="fas fa-chevron-right"></i>';
            btn.disabled = false;
        });
    }

    function showToast(message, type) {
        const toast = document.getElementById("toast");
        toast.innerText = message;
        toast.className = `show ${type}`; 
        setTimeout(() => { toast.className = toast.className.replace(`show ${type}`, ""); }, 3500);
    }
</script>

</body>
</html>
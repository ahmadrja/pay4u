<?php
session_start();

// Security Check
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header("Location: login.php");
    exit;
}

require_once '../config/database.php';
$database = new Database();
$db = $database->getConnection();

$user_id = $_SESSION['user_id'];
$message = "";

// ⚙️ BACKEND: UTR Submit Hone Par Data Save Karna
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_utr'])) {
    $amount = floatval($_POST['amount']);
    $utr_number = trim($_POST['utr_number']);
    
    // UTR 12 digit ka hota hai (Basic validation)
    if(strlen($utr_number) < 8) {
        $message = "<div class='alert error'>❌ Invalid UTR/Reference Number. Please check again.</div>";
    } else {
        try {
            // Check agar same UTR pehle se use toh nahi hua
            $check = $db->prepare("SELECT id FROM transactions WHERE txn_id = ?");
            $check->execute([$utr_number]);
            
            if($check->rowCount() > 0) {
                $message = "<div class='alert error'>⚠️ This UTR is already submitted. Please contact support.</div>";
            } else {
                // Transaction ko 'pending' status mein save karein (Admin verify karega)
                $stmt = $db->prepare("INSERT INTO transactions (user_id, txn_id, service_type, amount, status) VALUES (?, ?, 'wallet_load', ?, 'pending')");
                $stmt->execute([$user_id, $utr_number, $amount]);
                
                $message = "<div class='alert success'>✅ Payment Request Submitted! Your wallet will be updated within 5-10 minutes after verification.</div>";
            }
        } catch (Exception $e) {
            $message = "<div class='alert error'>❌ System Error: " . $e->getMessage() . "</div>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Money - SuperPay</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --primary: #4F46E5; --bg: #F3F4F6; --card: #FFFFFF; --text-dark: #1F2937; }
        body { font-family: 'Segoe UI', sans-serif; background: var(--bg); margin: 0; padding: 20px; display: flex; justify-content: center; }
        .container { max-width: 500px; width: 100%; }
        
        .header { display: flex; align-items: center; gap: 15px; margin-bottom: 25px; }
        .back-btn { color: var(--text-dark); font-size: 20px; text-decoration: none; }
        .header h2 { margin: 0; color: var(--text-dark); font-size: 22px; }

        .card { background: var(--card); padding: 25px; border-radius: 16px; box-shadow: 0 10px 25px rgba(0,0,0,0.05); margin-bottom: 20px; }
        
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; font-size: 14px; font-weight: 600; color: #4B5563; margin-bottom: 8px; }
        .form-group input { width: 100%; padding: 15px; border: 2px solid #E5E7EB; border-radius: 10px; outline: none; font-size: 18px; font-weight: bold; color: var(--text-dark); box-sizing: border-box; transition: 0.3s; }
        .form-group input:focus { border-color: var(--primary); }

        .btn-main { width: 100%; background: var(--primary); color: white; border: none; padding: 15px; border-radius: 10px; font-weight: bold; font-size: 16px; cursor: pointer; transition: 0.3s; display: flex; justify-content: center; gap: 10px; align-items: center; }
        .btn-main:hover { background: #4338CA; transform: translateY(-2px); }

        /* QR Code Section - Initially Hidden */
        #qr-section { display: none; text-align: center; margin-top: 20px; border-top: 2px dashed #E5E7EB; padding-top: 20px; }
        #qr-image { width: 220px; height: 220px; border: 10px solid white; border-radius: 16px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); }
        .upi-id-text { margin-top: 15px; font-size: 14px; color: #6B7280; font-weight: bold; }
        
        .alert { padding: 15px; border-radius: 10px; margin-bottom: 20px; font-weight: 600; font-size: 14px; text-align: center; line-height: 1.5; }
        .success { background: #D1FAE5; color: #065F46; border: 1px solid #A7F3D0; }
        .error { background: #FEE2E2; color: #991B1B; border: 1px solid #FECACA; }

        .info-box { background: #FFFBEB; padding: 15px; border-radius: 10px; border-left: 4px solid #F59E0B; font-size: 13px; color: #92400E; margin-bottom: 20px; }
    </style>
</head>
<body>

<div class="container">
    <div class="header">
        <a href="dashboard.php" class="back-btn"><i class="fas fa-arrow-left"></i></a>
        <h2>Add Money to Wallet</h2>
    </div>

    <?php if($message) echo $message; ?>

    <div class="info-box">
        <i class="fas fa-info-circle"></i> 0% Gateway Charges. Add money directly via PhonePe, GPay, or Paytm using UPI QR code.
    </div>

    <div class="card">
        <div class="form-group">
            <label>Enter Amount (₹)</label>
            <input type="number" id="load_amount" placeholder="₹ 0.00" min="10" required>
        </div>
        <button class="btn-main" onclick="generateQR()" id="gen_btn">
            <i class="fas fa-qrcode"></i> Generate Payment QR
        </button>

        <div id="qr-section">
            <h3 style="color: #10B981; margin-top: 0;">Scan & Pay <span id="display_amt"></span></h3>
            <img id="qr-image" src="" alt="UPI QR Code">
            <p class="upi-id-text">SuperPay Official UPI<br><span style="color: var(--primary);">yourbusiness@upi</span></p>

            <form method="POST" style="margin-top: 25px; text-align: left;">
                <input type="hidden" name="amount" id="hidden_amount">
                <div class="form-group">
                    <label>Enter 12-Digit UTR / Ref No.</label>
                    <input type="text" name="utr_number" placeholder="e.g. 312345678901" required>
                </div>
                <button type="submit" name="submit_utr" class="btn-main" style="background: #10B981;">
                    <i class="fas fa-check-circle"></i> Verify Payment
                </button>
            </form>
        </div>
    </div>
</div>

<script>
    // 🚨 YAHAN APNA ASLI BUSINESS UPI ID DALEIN 🚨
    const merchant_upi_id = "q990264177@ybl"; 
    const merchant_name = "SuperPay";

    function generateQR() {
        const amount = document.getElementById('load_amount').value;
        
        if(amount < 10) {
            alert("Minimum load amount is ₹10");
            return;
        }

        // Generate UPI Intent Link
        const upi_link = `upi://pay?pa=${merchant_upi_id}&pn=${merchant_name}&am=${amount}&cu=INR`;
        
        // Use free QR code generator API
        const qr_url = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(upi_link)}`;
        
        // Show QR Section
        document.getElementById('qr-image').src = qr_url;
        document.getElementById('display_amt').innerText = "₹ " + amount;
        document.getElementById('hidden_amount').value = amount;
        
        document.getElementById('qr-section').style.display = 'block';
        document.getElementById('gen_btn').style.display = 'none';
        document.getElementById('load_amount').readOnly = true;
    }
</script>

</body>
</html>
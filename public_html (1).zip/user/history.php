<?php
session_start();

// Security Check
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header("Location: login.php");
    exit;
}

require_once '../config/database.php';
$database = new Database();
$db = $database->getConnection();

$user_id = $_SESSION['user_id'];

// 1. Fetch Current Wallet Balance
$wallet_stmt = $db->prepare("SELECT balance FROM wallets WHERE user_id = ?");
$wallet_stmt->execute([$user_id]);
$current_balance = $wallet_stmt->fetchColumn() ?: 0.00;

// 2. Fetch User Transactions (Latest First)
try {
    $stmt = $db->prepare("SELECT txn_id, service_type, amount, status, created_at FROM transactions WHERE user_id = ? ORDER BY created_at DESC");
    $stmt->execute([$user_id]);
    $transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $transactions = [];
    error_log("History Fetch Error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transaction History - SuperPay</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --primary: #4F46E5; --bg: #F3F4F6; --card: #FFFFFF; --text-dark: #1F2937; }
        body { font-family: 'Segoe UI', sans-serif; background: var(--bg); margin: 0; padding: 20px; display: flex; justify-content: center; }
        .container { max-width: 500px; width: 100%; }
        
        /* Header & Balance Card */
        .header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 20px; }
        .header-left { display: flex; align-items: center; gap: 15px; }
        .back-btn { color: var(--text-dark); font-size: 20px; text-decoration: none; }
        .header h2 { margin: 0; color: var(--text-dark); font-size: 20px; }

        .balance-card { background: var(--primary); color: white; padding: 25px; border-radius: 16px; box-shadow: 0 10px 20px rgba(79, 70, 229, 0.2); margin-bottom: 25px; text-align: center; }
        .balance-card p { margin: 0; font-size: 14px; opacity: 0.9; text-transform: uppercase; letter-spacing: 1px; }
        .balance-card h1 { margin: 10px 0 0 0; font-size: 32px; font-weight: bold; }

        /* Transaction List */
        .history-title { font-size: 15px; color: #6B7280; font-weight: 600; margin-bottom: 15px; text-transform: uppercase; }
        .txn-card { background: var(--card); padding: 16px; border-radius: 12px; margin-bottom: 12px; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 2px 4px rgba(0,0,0,0.02); transition: 0.3s; }
        .txn-card:hover { transform: translateY(-2px); box-shadow: 0 4px 8px rgba(0,0,0,0.05); }
        
        .txn-left { display: flex; align-items: center; gap: 15px; }
        .icon-box { width: 45px; height: 45px; border-radius: 50%; display: flex; justify-content: center; align-items: center; font-size: 18px; }
        
        /* Dynamic Icons based on Service */
        .icon-load { background: #D1FAE5; color: #059669; } /* Green for Add Money */
        .icon-recharge { background: #EEF2FF; color: #4F46E5; } /* Blue for Recharge */
        .icon-failed { background: #FEE2E2; color: #DC2626; } /* Red for Failed Refund */

        .txn-details h4 { margin: 0; font-size: 15px; color: var(--text-dark); text-transform: capitalize; }
        .txn-details p { margin: 4px 0 0 0; font-size: 12px; color: #6B7280; }
        .txn-id { font-family: monospace; font-size: 11px; color: #9CA3AF; margin-top: 3px; display: block; }

        .txn-right { text-align: right; }
        .amt-credit { color: #059669; font-weight: bold; font-size: 16px; }
        .amt-debit { color: #1F2937; font-weight: bold; font-size: 16px; }
        
        /* Status Badges */
        .status { font-size: 11px; font-weight: bold; padding: 3px 8px; border-radius: 10px; text-transform: uppercase; display: inline-block; margin-top: 5px; }
        .status.success { background: #D1FAE5; color: #065F46; }
        .status.pending, .status.processing { background: #FEF3C7; color: #92400E; }
        .status.failed { background: #FEE2E2; color: #991B1B; }

        .empty-state { text-align: center; padding: 40px 20px; color: #6B7280; }
        .empty-state i { font-size: 40px; margin-bottom: 15px; color: #D1D5DB; }
    </style>
</head>
<body>

<div class="container">
    <div class="header">
        <div class="header-left">
            <a href="dashboard.php" class="back-btn"><i class="fas fa-arrow-left"></i></a>
            <h2>Passbook</h2>
        </div>
    </div>

    <div class="balance-card">
        <p>Available Balance</p>
        <h1>₹ <?php echo number_format($current_balance, 2); ?></h1>
    </div>

    <div class="history-title">Recent Transactions</div>

    <div class="txn-list">
        <?php if(count($transactions) > 0): ?>
            <?php foreach($transactions as $txn): 
                
                // Set Design Based on Service Type & Status
                $is_credit = false;
                $icon_class = 'icon-recharge';
                $icon_html = '<i class="fas fa-mobile-alt"></i>';
                $service_name = str_replace('_', ' ', $txn['service_type']);

                if ($txn['service_type'] == 'wallet_load') {
                    $is_credit = true;
                    $icon_class = 'icon-load';
                    $icon_html = '<i class="fas fa-wallet"></i>';
                }

                // Agar recharge fail ho jaye, toh refund aata hai (Credit)
                if ($txn['service_type'] == 'mobile_recharge' && $txn['status'] == 'failed') {
                    $is_credit = true;
                    $icon_class = 'icon-failed';
                    $icon_html = '<i class="fas fa-undo"></i>';
                    $service_name = "Refund: " . $service_name;
                }

                $amt_class = $is_credit ? 'amt-credit' : 'amt-debit';
                $amt_sign = $is_credit ? '+' : '-';
            ?>
            
            <div class="txn-card">
                <div class="txn-left">
                    <div class="icon-box <?php echo $icon_class; ?>">
                        <?php echo $icon_html; ?>
                    </div>
                    <div class="txn-details">
                        <h4><?php echo htmlspecialchars($service_name); ?></h4>
                        <p><?php echo date('d M Y, h:i A', strtotime($txn['created_at'])); ?></p>
                        <span class="txn-id">Txn ID: <?php echo htmlspecialchars($txn['txn_id']); ?></span>
                    </div>
                </div>
                <div class="txn-right">
                    <div class="<?php echo $amt_class; ?>">
                        <?php echo $amt_sign; ?> ₹<?php echo number_format($txn['amount'], 2); ?>
                    </div>
                    <div class="status <?php echo strtolower($txn['status']); ?>">
                        <?php echo htmlspecialchars($txn['status']); ?>
                    </div>
                </div>
            </div>

            <?php endforeach; ?>
        <?php else: ?>
            <div class="empty-state">
                <i class="fas fa-receipt"></i>
                <h3>No Transactions Yet</h3>
                <p>Add money to your wallet or make a recharge to see your history here.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

</body>
</html>
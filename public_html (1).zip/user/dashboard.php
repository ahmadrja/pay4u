<?php
session_start();

// Security Check: Sirf logged-in 'user' hi is page ko dekh sakta hai
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header("Location: login.php");
    exit;
}

require_once '../config/database.php';
$database = new Database();
$db = $database->getConnection();

$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['user_name'];
$wallet_balance = 0.00;

try {
    // User ka Live Wallet Balance fetch karein
    $stmt = $db->prepare("SELECT balance FROM wallets WHERE user_id = ? LIMIT 1");
    $stmt->execute([$user_id]);
    $wallet = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($wallet) {
        $wallet_balance = $wallet['balance'];
    }
} catch (Exception $e) {
    error_log("Wallet Fetch Error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SuperPay - My Dashboard</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --primary: #4F46E5; --bg: #F3F4F6; --card: #FFFFFF; --text-dark: #1F2937; }
        body { font-family: 'Segoe UI', sans-serif; background: var(--bg); margin: 0; padding-bottom: 70px; }
        
        /* Top Header Navigation */
        .header { background: var(--primary); color: white; padding: 20px; display: flex; justify-content: space-between; align-items: center; border-bottom-left-radius: 20px; border-bottom-right-radius: 20px; box-shadow: 0 4px 10px rgba(79, 70, 229, 0.2); }
        .user-info h3 { margin: 0; font-size: 18px; font-weight: 600; }
        .user-info p { margin: 5px 0 0 0; font-size: 13px; opacity: 0.9; }
        .logout-btn { background: rgba(255,255,255,0.2); color: white; text-decoration: none; padding: 8px 15px; border-radius: 8px; font-size: 13px; font-weight: bold; transition: 0.3s; }
        .logout-btn:hover { background: rgba(255,255,255,0.3); }

        /* Wallet Card */
        .container { max-width: 600px; margin: auto; padding: 20px; margin-top: -30px; }
        .wallet-card { background: var(--card); padding: 25px; border-radius: 16px; box-shadow: 0 10px 20px rgba(0,0,0,0.08); text-align: center; }
        .wallet-card p { color: #6B7280; margin: 0; font-size: 14px; font-weight: 600; text-transform: uppercase; }
        .wallet-card h1 { color: var(--text-dark); margin: 10px 0; font-size: 36px; display: flex; justify-content: center; align-items: center; gap: 5px; }
        .add-money-btn { background: #10B981; color: white; border: none; padding: 12px 25px; border-radius: 25px; font-size: 15px; font-weight: bold; cursor: pointer; transition: 0.3s; display: inline-flex; align-items: center; gap: 8px; margin-top: 10px; text-decoration: none; }
        .add-money-btn:hover { background: #059669; transform: translateY(-2px); }

        /* Services Grid */
        .services-section { margin-top: 30px; }
        .services-section h3 { color: var(--text-dark); font-size: 16px; margin-bottom: 15px; padding-left: 5px; }
        .services-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 15px; }
        .service-item { background: var(--card); padding: 20px 10px; border-radius: 12px; text-align: center; text-decoration: none; color: var(--text-dark); box-shadow: 0 4px 6px rgba(0,0,0,0.04); transition: 0.3s; display: flex; flex-direction: column; align-items: center; gap: 10px; }
        .service-item:hover { transform: translateY(-3px); box-shadow: 0 8px 12px rgba(0,0,0,0.08); }
        .icon-circle { width: 50px; height: 50px; border-radius: 50%; display: flex; justify-content: center; align-items: center; font-size: 20px; }
        
        /* Icon Colors */
        .mobile-icon { background: #EEF2FF; color: #4F46E5; }
        .dth-icon { background: #FFF7ED; color: #EA580C; }
        .elec-icon { background: #FEF2F2; color: #DC2626; }
        .history-icon { background: #F0FDF4; color: #16A34A; }

        .service-item span { font-size: 12px; font-weight: 600; }

        @media (max-width: 480px) {
            .services-grid { grid-template-columns: repeat(3, 1fr); }
        }
    </style>
</head>
<body>

    <div class="header">
        <div class="user-info">
            <h3>Hello, <?php echo htmlspecialchars($user_name); ?> 👋</h3>
            <p>Welcome to SuperPay</p>
        </div>
        <a href="../logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>

    <div class="container">
        <div class="wallet-card">
            <p>Available Balance</p>
            <h1><i class="fas fa-rupee-sign" style="font-size: 28px; color: #9CA3AF;"></i> <?php echo number_format($wallet_balance, 2); ?></h1>
            <a href="add_money.php" class="add-money-btn"><i class="fas fa-plus-circle"></i> Add Money</a>
        </div>

        <div class="services-section">
            <h3>Recharge & Pay Bills</h3>
            <div class="services-grid">
                <a href="recharge.php?type=mobile" class="service-item">
                    <div class="icon-circle mobile-icon"><i class="fas fa-mobile-alt"></i></div>
                    <span>Mobile</span>
                </a>
                <a href="recharge.php?type=dth" class="service-item">
                    <div class="icon-circle dth-icon"><i class="fas fa-satellite-dish"></i></div>
                    <span>DTH</span>
                </a>
                <a href="electricity.php" class="service-item">
                    <div class="icon-circle elec-icon"><i class="fas fa-lightbulb"></i></div>
                    <span>Electricity</span>
                </a>
                <a href="history.php" class="service-item">
                    <div class="icon-circle history-icon"><i class="fas fa-history"></i></div>
                    <span>History</span>
                </a>
            </div>
        </div>
        
        <div style="margin-top: 30px; background: white; padding: 20px; border-radius: 12px; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 4px 6px rgba(0,0,0,0.04);">
            <div>
                <h4 style="margin: 0; color: #1F2937;">Need Help?</h4>
                <p style="margin: 5px 0 0 0; font-size: 13px; color: #6B7280;">Contact 24/7 customer support.</p>
            </div>
            <i class="fas fa-headset" style="font-size: 24px; color: var(--primary);"></i>
        </div>
    </div>

</body>
</html>
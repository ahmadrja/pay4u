<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SuperPay - Login & Signup</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Segoe UI', sans-serif; background: #F3F4F6; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .auth-container { background: white; padding: 30px; border-radius: 12px; box-shadow: 0 10px 25px rgba(0,0,0,0.1); width: 100%; max-width: 400px; }
        .auth-header { text-align: center; margin-bottom: 25px; }
        .auth-header h2 { color: #4F46E5; margin: 0; font-size: 28px; }
        .auth-header p { color: #6B7280; font-size: 14px; margin-top: 5px; }
        
        .form-group { margin-bottom: 15px; }
        .form-group input { width: 100%; padding: 12px; border: 1px solid #D1D5DB; border-radius: 8px; box-sizing: border-box; outline: none; transition: 0.3s; }
        .form-group input:focus { border-color: #4F46E5; box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.1); }
        
        .btn-submit { width: 100%; background: #4F46E5; color: white; border: none; padding: 12px; border-radius: 8px; font-weight: bold; font-size: 16px; cursor: pointer; transition: 0.3s; }
        .btn-submit:hover { background: #4338CA; }
        
        .toggle-text { text-align: center; margin-top: 15px; font-size: 14px; color: #4B5563; }
        .toggle-text a { color: #4F46E5; font-weight: bold; cursor: pointer; text-decoration: none; }
        
        #register-form { display: none; } /* Default hide register form */
        #message-box { display: none; padding: 10px; border-radius: 6px; text-align: center; margin-bottom: 15px; font-weight: bold; font-size: 14px; }
        .success { background: #D1FAE5; color: #065F46; }
        .error { background: #FEE2E2; color: #991B1B; }
    </style>
</head>
<body>

<div class="auth-container">
    <div class="auth-header">
        <h2>SuperPay</h2>
        <p id="sub-title">Welcome back! Please login.</p>
    </div>

    <div id="message-box"></div>

    <form id="login-form" onsubmit="handleLogin(event)">
        <div class="form-group">
            <input type="text" id="login_phone" placeholder="Mobile Number" required>
        </div>
        <div class="form-group">
            <input type="password" id="login_password" placeholder="Password" required>
        </div>
        <button type="submit" class="btn-submit" id="login_btn">Login Securely</button>
        <div class="toggle-text">New to SuperPay? <a onclick="toggleForms('register')">Create an account</a></div>
    </form>

    <form id="register-form" onsubmit="handleRegister(event)">
        <div class="form-group">
            <input type="text" id="reg_name" placeholder="Full Name" required>
        </div>
        <div class="form-group">
            <input type="text" id="reg_phone" placeholder="Mobile Number" required>
        </div>
        <div class="form-group">
            <input type="password" id="reg_password" placeholder="Create Password" required>
        </div>
        <button type="submit" class="btn-submit" id="reg_btn">Sign Up Now</button>
        <div class="toggle-text">Already have an account? <a onclick="toggleForms('login')">Login here</a></div>
    </form>
</div>

<script>
    function toggleForms(type) {
        document.getElementById('message-box').style.display = 'none';
        if(type === 'register') {
            document.getElementById('login-form').style.display = 'none';
            document.getElementById('register-form').style.display = 'block';
            document.getElementById('sub-title').innerText = "Create your new wallet account.";
        } else {
            document.getElementById('register-form').style.display = 'none';
            document.getElementById('login-form').style.display = 'block';
            document.getElementById('sub-title').innerText = "Welcome back! Please login.";
        }
    }

    function showMessage(msg, type) {
        const box = document.getElementById('message-box');
        box.innerText = msg;
        box.className = type;
        box.style.display = 'block';
    }

    // Login API Call
    function handleLogin(e) {
        e.preventDefault();
        document.getElementById('login_btn').innerText = "Verifying...";
        
        let data = {
            phone: document.getElementById('login_phone').value,
            password: document.getElementById('login_password').value
        };

        fetch('../api/user_login.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        })
        .then(res => res.json())
        .then(res => {
            document.getElementById('login_btn').innerText = "Login Securely";
            if(res.status === 'success') {
                showMessage(res.message, 'success');
                setTimeout(() => window.location.href = res.redirect, 1000);
            } else {
                showMessage(res.message, 'error');
            }
        });
    }

    // Register API Call
    function handleRegister(e) {
        e.preventDefault();
        document.getElementById('reg_btn').innerText = "Creating Account...";
        
        let data = {
            name: document.getElementById('reg_name').value,
            phone: document.getElementById('reg_phone').value,
            password: document.getElementById('reg_password').value
        };

        fetch('../api/user_register.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        })
        .then(res => res.json())
        .then(res => {
            document.getElementById('reg_btn').innerText = "Sign Up Now";
            if(res.status === 'success') {
                showMessage(res.message, 'success');
                setTimeout(() => toggleForms('login'), 2000); // 2 second baad login par bhej dega
            } else {
                showMessage(res.message, 'error');
            }
        });
    }
</script>

</body>
</html>
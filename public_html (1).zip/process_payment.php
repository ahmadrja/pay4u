<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die("Invalid Request");
}

$user_id = $_SESSION['user_id'] ?? 101; 
$amount = floatval($_POST['amount']);

if ($amount < 10) {
    die("Minimum amount to add is ₹10");
}

// 1. Generate Unique Order ID for this transaction
$order_id = "OD" . date("YmdHis") . rand(100, 999);

// =========================================================================
// 🔒 2. DATABASE ENTRY (PENDING STATUS)
// =========================================================================
/* // Real Database Connection
$pdo = new PDO("mysql:host=localhost;dbname=superpay_db", "root", "");
$stmt = $pdo->prepare("INSERT INTO pg_transactions (order_id, user_id, amount, status) VALUES (?, ?, ?, 'PENDING')");
$stmt->execute([$order_id, $user_id, $amount]);
*/

// =========================================================================
// 🚀 3. PAYMENT GATEWAY INTEGRATION (RAZORPAY EXAMPLE)
// =========================================================================
/*
    Real world me aap yahan Razorpay/PhonePe ka cURL request likhenge
    Order ID create karne ke liye. (e.g., POST https://api.razorpay.com/v1/orders)
*/

// DUMMY API RESPONSE (Razorpay Order creation simulation)
$pg_order_id = "order_M" . rand(100000, 999999); // Gateway ka order id

// 4. Send User to Payment Page (Checkout)
// Yahan hum Razorpay ke JS checkout page ko render kar rahe hain
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Processing Payment...</title>
    <style>
        body { font-family: sans-serif; display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100vh; background: #F3F4F6; margin: 0;}
        .loader { border: 4px solid #E5E7EB; border-top: 4px solid #4F46E5; border-radius: 50%; width: 40px; height: 40px; animation: spin 1s linear infinite; margin-bottom: 20px;}
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
        h3 { color: #1F2937; margin:0;}
        p { color: #6B7280; font-size: 14px;}
    </style>
</head>
<body>
    <div class="loader"></div>
    <h3>Do not refresh this page</h3>
    <p>Redirecting to Secure Payment Gateway...</p>

    <form action="pg_callback.php" method="POST" id="pgForm">
        <input type="hidden" name="app_order_id" value="<?php echo $order_id; ?>">
        <input type="hidden" name="razorpay_payment_id" value="pay_dummy12345">
        <input type="hidden" name="razorpay_signature" value="dummy_signature">
    </form>

    <script>
        // Real app me yahan Razorpay.open() call hota hai.
        // Demo ke liye hum 2 second baad automatically pg_callback.php par submit kar rahe hain (Success man kar)
        setTimeout(() => {
            document.getElementById('pgForm').submit();
        }, 2000);
    </script>
</body>
</html>
<?php
session_start();

// 1. Saare session variables ko khali karein
$_SESSION = array();

// 2. Agar session cookie exist karti hai, toh use expire karein
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// 3. Session ko destroy karein
session_destroy();

// 4. User ko login page par redirect karein
header("Location: login.php");
exit;
?>
// API Call Setup (ES6 Fetch)
const API_BASE_URL = '/api';

async function processWalletDeduction(userId, amount, serviceType) {
    try {
        const response = await fetch(`${API_BASE_URL}/wallet.php`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ user_id: userId, amount: amount, service_type: serviceType })
        });
        const data = await response.json();
        
        if(data.status === 'success') {
            alert(`Payment Successful! TXN ID: ${data.txn_id}`);
            document.getElementById('walletBalance').innerText = `₹ ${data.new_balance.toFixed(2)}`;
        } else {
            alert(`Error: ${data.message}`);
        }
    } catch (error) {
        console.error("API Error:", error);
    }
}

// Example Trigger (Can be connected to Recharge/Booking buttons)
function openService(serviceName) {
    console.log(`Opening ${serviceName} module...`);
    // Yahan par aap HTML inject kar sakte hain ya specific service page par route kar sakte hain
}
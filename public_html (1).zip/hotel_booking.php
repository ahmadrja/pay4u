<?php
session_start();
if(!isset($_SESSION['user_id'])) { header("Location: login.php"); exit; }

require_once 'config/database.php';
$database = new Database();
$db = $database->getConnection();

$today = date('Y-m-d');
$tomorrow = date('Y-m-d', strtotime('+1 day'));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Hotels - SuperApp</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --primary: #4F46E5; --bg-color: #F3F4F6; --text-dark: #1F2937; --white: #FFFFFF; }
        body { font-family: 'Segoe UI', sans-serif; background: var(--bg-color); display: flex; justify-content: center; margin: 0; }
        .app-container { width: 100%; max-width: 480px; background: var(--white); min-height: 100vh; box-shadow: 0 0 15px rgba(0,0,0,0.05); }
        
        /* Header */
        .header { background: var(--primary); color: var(--white); padding: 20px; display: flex; align-items: center; gap: 15px; }
        .header i { font-size: 20px; cursor: pointer; }

        /* Search Section */
        .search-container { padding: 20px; background: var(--primary); border-radius: 0 0 25px 25px; margin-bottom: 20px; }
        .search-box { background: white; padding: 20px; border-radius: 15px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
        .input-group { margin-bottom: 15px; }
        .input-group label { display: block; font-size: 12px; color: #6B7280; margin-bottom: 5px; font-weight: bold; }
        .input-group input { width: 100%; padding: 12px; border: 1px solid #D1D5DB; border-radius: 8px; font-size: 14px; outline: none; box-sizing: border-box; }
        
        .btn-search { width: 100%; background: #10B981; color: white; border: none; padding: 15px; border-radius: 8px; font-size: 16px; font-weight: bold; cursor: pointer; transition: 0.3s; }
        
        /* Listing Section */
        .hotel-list { padding: 0 20px; }
        .hotel-card { background: white; border-radius: 12px; overflow: hidden; border: 1px solid #E5E7EB; margin-bottom: 20px; }
        .hotel-image { width: 100%; height: 150px; background: #EEE; object-fit: cover; }
        .hotel-content { padding: 15px; }
        .hotel-content h4 { margin: 0; font-size: 16px; color: var(--text-dark); }
        .hotel-content p { margin: 5px 0; font-size: 12px; color: #6B7280; }
        .hotel-footer { display: flex; justify-content: space-between; align-items: center; margin-top: 10px; border-top: 1px solid #F3F4F6; padding-top: 10px; }
        .price { font-size: 18px; font-weight: bold; color: var(--primary); }
        .btn-book { background: var(--primary); color: white; border: none; padding: 8px 15px; border-radius: 6px; font-size: 12px; font-weight: bold; cursor: pointer; }
    </style>
</head>
<body>

    <div class="app-container">
        <div class="header">
            <i class="fas fa-arrow-left" onclick="window.location.href='index.php'"></i>
            <h2 style="margin:0; font-size: 18px;">Search Hotels</h2>
        </div>

        <div class="search-container">
            <div class="search-box">
                <div class="input-group">
                    <label>CITY / LOCATION</label>
                    <input type="text" id="city" placeholder="e.g. Patna, Bihar" value="Patna">
                </div>
                <div style="display: flex; gap: 10px;">
                    <div class="input-group" style="flex:1;">
                        <label>CHECK-IN</label>
                        <input type="date" id="checkin" value="<?php echo $today; ?>" min="<?php echo $today; ?>">
                    </div>
                    <div class="input-group" style="flex:1;">
                        <label>CHECK-OUT</label>
                        <input type="date" id="checkout" value="<?php echo $tomorrow; ?>" min="<?php echo $tomorrow; ?>">
                    </div>
                </div>
                <button class="btn-search" onclick="searchHotels()">Search Hotels <i class="fas fa-search"></i></button>
            </div>
        </div>

        <div class="hotel-list" id="hotelResults">
            <div class="hotel-card">
                <img src="https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=480&q=80" class="hotel-image" alt="Hotel">
                <div class="hotel-content">
                    <h4>The Maurya Hotel</h4>
                    <p><i class="fas fa-map-marker-alt"></i> Gandhi Maidan, Patna</p>
                    <div class="hotel-footer">
                        <div class="price">₹ 4,500 <small style="font-size: 10px; color: #999;">/night</small></div>
                        <button class="btn-book" onclick="bookNow('HTL001', 4500)">Book Now</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function searchHotels() {
            const btn = document.querySelector('.btn-search');
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Searching...';
            
            // Yahan aap fetch() call karenge /api/hotel_search.php par
            setTimeout(() => {
                btn.innerHTML = 'Search Hotels <i class="fas fa-search"></i>';
                alert("Search functionality connected to Patna regional servers.");
            }, 1000);
        }

        async function bookNow(hotelId, amount) {
            // Humara banaya hua wallet deduction logic trigger hoga
            if(confirm(`Confirm booking for ₹${amount}?`)) {
                window.location.href = 'history.php';
            }
        }
    </script>
</body>
</html>
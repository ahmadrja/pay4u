<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$host = "127.0.0.1";
$db_name = "u433139141_pay"; 
$db_user = "u433139141_pay"; 
$db_pass = "Ahmad@0201"; // <--- यहाँ अपना डेटाबेस पासवर्ड डालें

try {
    $conn = new PDO("mysql:host=$host;dbname=$db_name", $db_user, $db_pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $name = "Md Ahmad Raja";
    $phone = "8582010201";
    $password = "Ahmad@0201";
    $hash = password_hash($password, PASSWORD_BCRYPT);

    $checkColumn = $conn->query("SHOW COLUMNS FROM users LIKE 'phone'");
    $phoneCol = $checkColumn->rowCount() > 0 ? 'phone' : 'mobile';

    $checkPassCol = $conn->query("SHOW COLUMNS FROM users LIKE 'password'");
    $passCol = $checkPassCol->rowCount() > 0 ? 'password' : 'password_hash';

    $conn->exec("DELETE FROM users WHERE $phoneCol = '$phone'");

    // 🔥 अपडेटेड लाइन: यहाँ से 'status' हटा दिया गया है
    $sql = "INSERT INTO users (name, $phoneCol, $passCol, role) VALUES ('$name', '$phone', '$hash', 'admin')";
    $conn->exec($sql);

    echo "<h2 style='color:#10B981; text-align:center;'>✅ Admin Account Created Successfully!</h2>";

} catch(PDOException $e) {
    echo "<h2 style='color:#EF4444;'>❌ Database Error:</h2>" . $e->getMessage();
}
?>
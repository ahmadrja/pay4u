<?php
session_start();
if(!isset($_SESSION['user_id'])) { header("Location: login.php"); exit; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notifications - SuperApp</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --primary: #4F46E5; --bg-color: #F3F4F6; --white: #FFFFFF; }
        body { font-family: 'Segoe UI', sans-serif; background: var(--bg-color); display: flex; justify-content: center; margin: 0; }
        .app-container { width: 100%; max-width: 480px; background: var(--white); min-height: 100vh; }
        .header { background: var(--primary); color: var(--white); padding: 20px; display: flex; align-items: center; gap: 15px; }
        .notif-list { padding: 10px; }
        .notif-card { background: #FFF; padding: 15px; border-bottom: 1px solid #EEE; display: flex; gap: 15px; align-items: flex-start; }
        .notif-icon { background: #EEF2FF; color: var(--primary); padding: 10px; border-radius: 50%; }
        .notif-content h4 { margin: 0; font-size: 14px; color: #1F2937; }
        .notif-content p { margin: 5px 0 0; font-size: 12px; color: #6B7280; }
    </style>
</head>
<body>
    <div class="app-container">
        <div class="header">
            <i class="fas fa-arrow-left" onclick="history.back()"></i>
            <h2 style="margin:0; font-size: 18px;">Notifications</h2>
        </div>
        <div class="notif-list">
            <div class="notif-card">
                <div class="notif-icon"><i class="fas fa-gift"></i></div>
                <div class="notif-content">
                    <h4>Flat ₹50 Cashback!</h4>
                    <p>Get flat ₹50 cashback on your first flight booking this month. Use code FLY50.</p>
                </div>
            </div>
            <div class="notif-card">
                <div class="notif-icon"><i class="fas fa-info-circle"></i></div>
                <div class="notif-content">
                    <h4>KYC Update</h4>
                    <p>Please complete your KYC to increase your daily wallet limit to ₹1,00,000.</p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
<?php
// Error Reporting (Production Server पर लाइव होने के बाद इसे 0 कर दें)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Timezone Setup (India के लिए)
date_default_timezone_set('Asia/Kolkata');

// Database Credentials (आपके द्वारा दी गई डिटेल्स)
define('DB_HOST', 'localhost'); // या 127.0.0.1
define('DB_NAME', 'u433139141_pay'); 
define('DB_USER', 'u433139141_pay');        
define('DB_PASS', 'Ahmad@0201');            

// =========================================================================
// 🚀 1. OOP APPROACH (यह एडमिन पैनल और नई API के लिए है)
// =========================================================================
class Database {
    public $conn;

    public function getConnection() {
        $this->conn = null;
        try {
            $this->conn = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4", DB_USER, DB_PASS);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
            $this->conn->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
        } catch(PDOException $exception) {
            die(json_encode(['status' => 'error', 'message' => 'Database Connection Error: ' . $exception->getMessage()]));
        }
        return $this->conn;
    }
}

// =========================================================================
// 🌐 2. PROCEDURAL APPROACH (यह आपकी पुरानी फ्रंटएंड फ़ाइलों के लिए है)
// =========================================================================
try {
    $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4", DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false); 
} catch (PDOException $e) {
    error_log("Connection failed: " . $e->getMessage());
    // यहाँ die() नहीं लगा रहे ताकि अगर कोई क्लास कॉल करे तो पेज क्रैश न हो
}
?>
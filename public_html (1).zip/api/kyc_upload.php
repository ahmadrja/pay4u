<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");

require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

// JWT ya Token validation yahan aana chahiye (Authentication check)
$user_id = $_POST['user_id'] ?? null; 

if (!$user_id || !isset($_FILES['document'])) {
    echo json_encode(["status" => "error", "message" => "User ID and Document are required."]);
    exit;
}

$file = $_FILES['document'];

// 1. Basic File Errors Check
if ($file['error'] !== UPLOAD_ERR_OK) {
    echo json_encode(["status" => "error", "message" => "File upload error code: " . $file['error']]);
    exit;
}

// 2. Strict File Size Limit (Max 5MB)
$max_size = 5 * 1024 * 1024;
if ($file['size'] > $max_size) {
    echo json_encode(["status" => "error", "message" => "File size exceeds 5MB limit."]);
    exit;
}

// 3. True MIME Type Validation (Spoofing prevention)
$finfo = new finfo(FILEINFO_MIME_TYPE);
$mime_type = $finfo->file($file['tmp_name']);

$allowed_types = ['image/jpeg', 'image/png', 'application/pdf'];

if (!in_array($mime_type, $allowed_types)) {
    echo json_encode(["status" => "error", "message" => "Invalid file format. Only JPG, PNG, and PDF are allowed."]);
    exit;
}

// 4. Secure Renaming (Taaki koi shell execute na kar sake)
$extension = pathinfo($file['name'], PATHINFO_EXTENSION);
// Unique secure name generate karein
$new_filename = "KYC_" . $user_id . "_" . bin2hex(random_bytes(10)) . "." . $extension;

// Upload Directory (Is directory mein .htaccess se PHP execution disable karna zaroori hai)
$upload_dir = '../uploads/kyc/';

if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0755, true);
}

$destination = $upload_dir . $new_filename;

// 5. Move File & Update DB
if (move_uploaded_file($file['tmp_name'], $destination)) {
    try {
        $db->beginTransaction();

        // User ka KYC status update karein
        $stmt = $db->prepare("UPDATE users SET kyc_status = 'pending' WHERE id = ?");
        $stmt->execute([$user_id]);

        // Yahan aap document ka path ek 'user_documents' table mein bhi save kar sakte hain
        // $docStmt = $db->prepare("INSERT INTO user_documents (user_id, doc_path) VALUES (?, ?)");
        // $docStmt->execute([$user_id, $destination]);

        $db->commit();

        echo json_encode([
            "status" => "success", 
            "message" => "Document uploaded successfully. Admin will verify soon.",
            "file_path" => "uploads/kyc/" . $new_filename // Relative path frontend ke liye
        ]);

    } catch (Exception $e) {
        $db->rollBack();
        unlink($destination); // Agar DB fail ho jaye toh upload hui file delete kar dein
        echo json_encode(["status" => "error", "message" => "Database error during upload."]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Failed to move uploaded file."]);
}
?>
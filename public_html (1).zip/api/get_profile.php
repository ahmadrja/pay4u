<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");
// Headers me Authorization allow karna zaroori hai Bearer token ke liye
header("Access-Control-Allow-Headers: Authorization, Content-Type"); 

require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

// 1. HTTP Headers read karein
$headers = apache_request_headers();
// Token header me "Authorization" key ke andar aayega
$auth_header = isset($headers['Authorization']) ? $headers['Authorization'] : '';

if ($auth_header) {
    // 2. "Bearer " word ko remove karke pure token nikaalein
    $token = trim(str_replace("Bearer ", "", $auth_header));

    if (!empty($token)) {
        try {
            // 3. Database me token verify karein aur user ki details + wallet balance nikaalein
            // LEFT JOIN ka use kiya hai taaki user aur wallet data ek hi query me aa jaye (Optimized)
            $stmt = $db->prepare("
                SELECT u.id, u.name, u.phone, u.kyc_status, w.balance 
                FROM users u 
                LEFT JOIN wallets w ON u.id = w.user_id 
                WHERE u.auth_token = ? 
                LIMIT 1
            ");
            $stmt->execute([$token]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user) {
                // Token valid hai! User ka secure data return karein
                http_response_code(200);
                echo json_encode([
                    "status" => "success",
                    "message" => "Profile fetched successfully",
                    "data" => [
                        "user_id" => $user['id'],
                        "name" => $user['name'],
                        "phone" => $user['phone'],
                        "kyc_status" => $user['kyc_status'],
                        "wallet_balance" => number_format((float)$user['balance'], 2, '.', '') // Balance proper decimal format me
                    ]
                ]);
            } else {
                // Token match nahi hua (Ya toh hacker hai, ya user logout ho chuka hai)
                http_response_code(401);
                echo json_encode(["status" => "error", "message" => "Invalid or expired session. Please login again."]);
            }
        } catch (Exception $e) {
            // Server error handling
            error_log("Profile Fetch Error: " . $e->getMessage());
            http_response_code(500);
            echo json_encode(["status" => "error", "message" => "Server error occurred while fetching profile."]);
        }
    } else {
        http_response_code(400);
        echo json_encode(["status" => "error", "message" => "Malformed token provided."]);
    }
} else {
    // Agar request me Authorization header hi nahi hai
    http_response_code(401);
    echo json_encode(["status" => "error", "message" => "Authorization header is missing. Access Denied."]);
}
?>
<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");

require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

// Input parameters get karein
$user_id = $_GET['user_id'] ?? null;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 20;

$service_type = $_GET['service_type'] ?? null; // e.g., 'recharge', 'transfer'
$status = $_GET['status'] ?? null;             // e.g., 'success', 'failed', 'pending'
$start_date = $_GET['start_date'] ?? null;
$end_date = $_GET['end_date'] ?? null;

if (!$user_id) {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "User ID is required."]);
    exit;
}

try {
    // Offset calculate karein pagination ke liye
    $offset = ($page - 1) * $limit;

    // Dynamic Query Builder start
    $query = "SELECT txn_id, type, amount, service_type, status, description, created_at FROM transactions WHERE user_id = :user_id";
    $count_query = "SELECT COUNT(*) as total_records FROM transactions WHERE user_id = :user_id";
    
    $params = [':user_id' => $user_id];

    // Filter by Service Type
    if ($service_type) {
        $query .= " AND service_type = :service_type";
        $count_query .= " AND service_type = :service_type";
        $params[':service_type'] = $service_type;
    }

    // Filter by Status
    if ($status) {
        $query .= " AND status = :status";
        $count_query .= " AND status = :status";
        $params[':status'] = $status;
    }

    // Filter by Date Range (e.g., 2026-03-01 to 2026-03-15)
    if ($start_date && $end_date) {
        $query .= " AND DATE(created_at) BETWEEN :start_date AND :end_date";
        $count_query .= " AND DATE(created_at) BETWEEN :start_date AND :end_date";
        $params[':start_date'] = $start_date;
        $params[':end_date'] = $end_date;
    }

    // Sorting aur Pagination (PDO mein LIMIT aur OFFSET direct bindParam se integer me bhejne chahiye)
    $query .= " ORDER BY created_at DESC LIMIT :limit OFFSET :offset";

    // Pehle Total Count nikalein (Frontend me total pages dikhane ke liye)
    $stmt_count = $db->prepare($count_query);
    // Count query me limit/offset nahi chahiye, sirf filters pass karein
    foreach ($params as $key => &$val) {
        $stmt_count->bindParam($key, $val);
    }
    $stmt_count->execute();
    $total_records = $stmt_count->fetch(PDO::FETCH_ASSOC)['total_records'];
    $total_pages = ceil($total_records / $limit);

    // Ab Data Fetch karein
    $stmt = $db->prepare($query);
    
    // Bind dynamic parameters safely
    foreach ($params as $key => &$val) {
        $stmt->bindParam($key, $val);
    }
    // Bind Limit and Offset strictly as Integers
    $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
    
    $stmt->execute();
    $transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        "status" => "success",
        "data" => $transactions,
        "pagination" => [
            "current_page" => $page,
            "per_page" => $limit,
            "total_records" => $total_records,
            "total_pages" => $total_pages
        ]
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Database error: " . $e->getMessage()]);
}
?>
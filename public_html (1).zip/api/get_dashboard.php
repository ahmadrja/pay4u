<?php
// CORS and Security Headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Authorization, Content-Type");

require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

// 1. Authorization Token एक्स्ट्रेक्ट करें (Security)
$headers = apache_request_headers();
$auth_header = isset($headers['Authorization']) ? $headers['Authorization'] : (isset($headers['authorization']) ? $headers['authorization'] : '');

if (!empty($auth_header) && preg_match('/Bearer\s(\S+)/', $auth_header, $matches)) {
    $token = $matches[1];

    try {
        // 2. User Details & KYC Status फेच करें
        $stmt = $db->prepare("SELECT id, name, phone, kyc_status FROM users WHERE auth_token = ? AND role = 'user' LIMIT 1");
        $stmt->execute([$token]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            $user_id = $user['id'];

            // 3. Wallet Balance फेच करें
            $walletStmt = $db->prepare("SELECT balance FROM wallets WHERE user_id = ? LIMIT 1");
            $walletStmt->execute([$user_id]);
            $wallet = $walletStmt->fetch(PDO::FETCH_ASSOC);
            $current_balance = $wallet ? floatval($wallet['balance']) : 0.00;

            // 4. Recent 5 Transactions फेच करें (होमपेज के लिए)
            $txnStmt = $db->prepare("SELECT txn_id, amount, service_type, status, created_at FROM transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT 5");
            $txnStmt->execute([$user_id]);
            $recent_txns = $txnStmt->fetchAll(PDO::FETCH_ASSOC);

            // 5. Dynamic App Banners (Growth Marketing)
            // प्रो टिप: आप डेटाबेस में एक 'banners' टेबल बना सकते हैं ताकि ऐप के बैनर सर्वर से बदल सकें
            $banners = [
                ["id" => 1, "image_url" => "https://yourdomain.com/assets/banners/offer1.jpg", "action" => "recharge_page"],
                ["id" => 2, "image_url" => "https://yourdomain.com/assets/banners/kyc_promo.jpg", "action" => "kyc_page"]
            ];

            // 6. Final JSON Response (Unified Data)
            http_response_code(200);
            echo json_encode([
                "status" => "success",
                "data" => [
                    "user_profile" => [
                        "name" => $user['name'],
                        "phone" => $user['phone'],
                        "kyc_status" => $user['kyc_status'], // 'pending', 'under_review', 'approved'
                    ],
                    "wallet" => [
                        "balance" => number_format($current_balance, 2, '.', ''),
                        "currency" => "INR"
                    ],
                    "recent_transactions" => $recent_txns,
                    "promotional_banners" => $banners // ऐप के ऊपर घूमने वाले बैनर्स के लिए
                ]
            ]);

        } else {
            http_response_code(401);
            echo json_encode(["status" => "error", "message" => "Invalid or expired token. Please login again."]);
        }
    } catch (Exception $e) {
        error_log("Dashboard API Error: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(["status" => "error", "message" => "Server error while loading dashboard."]);
    }
} else {
    http_response_code(401);
    echo json_encode(["status" => "error", "message" => "Authorization header missing or invalid."]);
}
?>
<?php
// CORS and Security Headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Authorization, Content-Type");

require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

// 1. Authorization Token चेक करें
$headers = apache_request_headers();
$auth_header = isset($headers['Authorization']) ? $headers['Authorization'] : (isset($headers['authorization']) ? $headers['authorization'] : '');

if (!empty($auth_header) && preg_match('/Bearer\s(\S+)/', $auth_header, $matches)) {
    $token = $matches[1];
    
    // इनपुट रीड करें
    $data = json_decode(file_get_contents("php://input"));
    $receiver_phone = isset($data->receiver_phone) ? htmlspecialchars(strip_tags($data->receiver_phone)) : '';
    $amount = isset($data->amount) ? floatval($data->amount) : 0;
    $remark = isset($data->remark) ? htmlspecialchars(strip_tags($data->remark)) : 'Wallet Transfer';

    if (strlen($receiver_phone) >= 10 && $amount > 0) {
        try {
            // 2. Sender (भेजने वाले) को वेरीफाई करें
            $stmt = $db->prepare("SELECT id, phone, kyc_status FROM users WHERE auth_token = ? AND role = 'user' LIMIT 1");
            $stmt->execute([$token]);
            $sender = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($sender) {
                $sender_id = $sender['id'];

                // खुद को पैसे भेजने से रोकें
                if ($sender['phone'] === $receiver_phone) {
                    echo json_encode(["status" => "error", "message" => "You cannot send money to yourself."]);
                    exit();
                }

                // 3. Receiver (प्राप्त करने वाले) को खोजें
                $recvStmt = $db->prepare("SELECT id, name FROM users WHERE phone = ? AND role = 'user' LIMIT 1");
                $recvStmt->execute([$receiver_phone]);
                $receiver = $recvStmt->fetch(PDO::FETCH_ASSOC);

                if ($receiver) {
                    $receiver_id = $receiver['id'];
                    $receiver_name = $receiver['name'];

                    // ==========================================
                    // CRITICAL SECTION: TRANSACTION & LOCKING
                    // ==========================================
                    $db->beginTransaction();

                    try {
                        // A. Sender का बैलेंस चेक करें (FOR UPDATE के साथ ताकि बैलेंस लॉक हो जाए)
                        $senderWalletStmt = $db->prepare("SELECT balance FROM wallets WHERE user_id = ? FOR UPDATE");
                        $senderWalletStmt->execute([$sender_id]);
                        $sender_wallet = $senderWalletStmt->fetch(PDO::FETCH_ASSOC);

                        if ($sender_wallet && $sender_wallet['balance'] >= $amount) {
                            
                            // B. Receiver के वॉलेट को भी लॉक करें
                            $receiverWalletStmt = $db->prepare("SELECT balance FROM wallets WHERE user_id = ? FOR UPDATE");
                            $receiverWalletStmt->execute([$receiver_id]);

                            // C. Sender के पैसे काटें
                            $deductSender = $db->prepare("UPDATE wallets SET balance = balance - ? WHERE user_id = ?");
                            $deductSender->execute([$amount, $sender_id]);

                            // D. Receiver को पैसे दें
                            $addReceiver = $db->prepare("UPDATE wallets SET balance = balance + ? WHERE user_id = ?");
                            $addReceiver->execute([$amount, $receiver_id]);

                            // E. Transactions History जनरेट करें
                            $base_txn_id = "P2P" . time() . rand(100, 999);
                            $sender_txn_id = $base_txn_id . "D"; // D for Debit
                            $receiver_txn_id = $base_txn_id . "C"; // C for Credit

                            // Sender की डेबिट एंट्री
                            $insertSenderTxn = $db->prepare("INSERT INTO transactions (txn_id, user_id, amount, service_type, status, created_at) VALUES (?, ?, ?, ?, 'success', NOW())");
                            $insertSenderTxn->execute([$sender_txn_id, $sender_id, $amount, "sent_to_" . $receiver_phone]);

                            // Receiver की क्रेडिट एंट्री
                            $insertReceiverTxn = $db->prepare("INSERT INTO transactions (txn_id, user_id, amount, service_type, status, created_at) VALUES (?, ?, ?, ?, 'success', NOW())");
                            $insertReceiverTxn->execute([$receiver_txn_id, $receiver_id, $amount, "received_from_" . $sender['phone']]);

                            // सब कुछ सही रहा, डेटाबेस में कमिट कर दें
                            $db->commit();

                            echo json_encode([
                                "status" => "success", 
                                "message" => "₹{$amount} sent successfully to {$receiver_name}.",
                                "txn_id" => $sender_txn_id
                            ]);

                        } else {
                            $db->rollBack();
                            http_response_code(400);
                            echo json_encode(["status" => "error", "message" => "Insufficient wallet balance."]);
                        }
                    } catch (Exception $e) {
                        $db->rollBack();
                        error_log("P2P Transfer Error: " . $e->getMessage());
                        http_response_code(500);
                        echo json_encode(["status" => "error", "message" => "Transaction failed due to server error."]);
                    }
                } else {
                    http_response_code(404);
                    echo json_encode(["status" => "error", "message" => "Receiver not found. Please ask them to register on SuperPay."]);
                }
            } else {
                http_response_code(401);
                echo json_encode(["status" => "error", "message" => "Invalid or expired token."]);
            }
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(["status" => "error", "message" => "Server error occurred."]);
        }
    } else {
        http_response_code(400);
        echo json_encode(["status" => "error", "message" => "Valid receiver phone number and amount are required."]);
    }
} else {
    http_response_code(401);
    echo json_encode(["status" => "error", "message" => "Authorization header missing."]);
}
?>
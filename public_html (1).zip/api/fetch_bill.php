<?php
// CORS and Security Headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Authorization, Content-Type");

require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

// 1. Authorization Token चेक करें
$headers = apache_request_headers();
$auth_header = isset($headers['Authorization']) ? $headers['Authorization'] : (isset($headers['authorization']) ? $headers['authorization'] : '');

if (!empty($auth_header) && preg_match('/Bearer\s(\S+)/', $auth_header, $matches)) {
    $token = $matches[1];
    
    // इनपुट रीड करें
    $data = json_decode(file_get_contents("php://input"));
    $operator_code = isset($data->operator_code) ? htmlspecialchars(strip_tags($data->operator_code)) : ''; // e.g., 'NBPDCL'
    $consumer_number = isset($data->consumer_number) ? htmlspecialchars(strip_tags($data->consumer_number)) : ''; // CA Number / Account Number

    if (!empty($operator_code) && !empty($consumer_number)) {
        try {
            // 2. User Authentication (सिर्फ वैलिड यूजर ही बिल फेच कर सकता है)
            $stmt = $db->prepare("SELECT id FROM users WHERE auth_token = ? AND role = 'user' LIMIT 1");
            $stmt->execute([$token]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user) {
                
                // =========================================================
                // 3. THIRD-PARTY BBPS API CALL (Fetch Bill Logic)
                // (यहाँ आप Setu, Cashfree, या Cyberplat का BBPS API कॉल करेंगे)
                // =========================================================
                
                /* DUMMY CURL CODE - UNCOMMENT IN PRODUCTION
                $api_url = "https://thirdparty-bbps.com/api/v1/fetch-bill";
                $post_data = json_encode([
                    "api_key" => "YOUR_BBPS_API_KEY",
                    "operator" => $operator_code,
                    "consumer_no" => $consumer_number
                ]);

                $ch = curl_init($api_url);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
                curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
                $response = curl_exec($ch);
                curl_close($ch);
                
                $bill_data = json_decode($response, true);
                */

                // अभी टेस्टिंग के लिए हम मान लेते हैं कि API ने यह डमी बिल भेजा है:
                // प्रो टिप: थर्ड-पार्टी API 'bill_fetch_status' रिटर्न करती है
                $bill_data = [
                    "status" => "success",
                    "data" => [
                        "customer_name" => "Ramesh Kumar",
                        "bill_amount" => 1450.00,
                        "due_date" => "2026-04-10",
                        "bill_number" => "INV987654321",
                        "bill_period" => "Feb 2026"
                    ]
                ];

                if ($bill_data['status'] === 'success') {
                    // 4. ऐप को बिल का डेटा भेजें ताकि यूजर को UI पर 'Pay' बटन दिख सके
                    http_response_code(200);
                    echo json_encode([
                        "status" => "success",
                        "message" => "Bill fetched successfully.",
                        "bill_details" => [
                            "customer_name" => $bill_data['data']['customer_name'],
                            "amount_due" => number_format($bill_data['data']['bill_amount'], 2, '.', ''),
                            "due_date" => date("d M Y", strtotime($bill_data['data']['due_date'])),
                            "bill_number" => $bill_data['data']['bill_number'],
                            // Security: पेमेंट करते वक्त वेरीफाई करने के लिए एक हैश या टोकन भी भेज सकते हैं
                            "fetch_reference" => md5($consumer_number . time()) 
                        ]
                    ]);
                } else {
                    http_response_code(404);
                    echo json_encode(["status" => "error", "message" => "No pending bill found or invalid consumer number."]);
                }

            } else {
                http_response_code(401);
                echo json_encode(["status" => "error", "message" => "Invalid or expired token."]);
            }
        } catch (Exception $e) {
            error_log("Fetch Bill Error: " . $e->getMessage());
            http_response_code(500);
            echo json_encode(["status" => "error", "message" => "Server error occurred while fetching bill."]);
        }
    } else {
        http_response_code(400);
        echo json_encode(["status" => "error", "message" => "Operator code and Consumer number are required."]);
    }
} else {
    http_response_code(401);
    echo json_encode(["status" => "error", "message" => "Authorization header missing."]);
}
?>
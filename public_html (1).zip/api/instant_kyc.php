<?php
// CORS and Security Headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Authorization, Content-Type");

require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

// Authorization Token Check
$headers = apache_request_headers();
$auth_header = isset($headers['Authorization']) ? $headers['Authorization'] : '';

if (!empty($auth_header) && preg_match('/Bearer\s(\S+)/', $auth_header, $matches)) {
    $token = $matches[1];
    $data = json_decode(file_get_contents("php://input"));
    
    // इनपुट: PAN नंबर और Aadhaar से मिला डेटा (जो वेंडर API से आएगा)
    $pan_number = isset($data->pan_number) ? strtoupper(htmlspecialchars(strip_tags($data->pan_number))) : '';
    $aadhaar_number = isset($data->aadhaar_number) ? htmlspecialchars(strip_tags($data->aadhaar_number)) : '';
    
    if (!empty($pan_number) && !empty($aadhaar_number)) {
        try {
            $stmt = $db->prepare("SELECT id, name FROM users WHERE auth_token = ? LIMIT 1");
            $stmt->execute([$token]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user) {
                $user_id = $user['id'];
                $app_registered_name = strtolower($user['name']);

                // =================================================================
                // THIRD-PARTY API CALL (e.g., Cashfree PAN & Aadhaar Verification)
                // =================================================================
                
                // (यहाँ आपका cURL कोड होगा जो PAN और Aadhaar को वेंडर API को भेजेगा)
                // टेस्टिंग के लिए हम मान लेते हैं कि API ने यह असली डेटा रिटर्न किया है:
                $vendor_api_response = [
                    "status" => "VALID",
                    "pan_registered_name" => "Md Ahmad Rja", // NSDL से आया नाम
                    "aadhaar_registered_name" => "Ahmad Rja"   // UIDAI से आया नाम
                ];

                if ($vendor_api_response['status'] === 'VALID') {
                    
                    // PRO-LEVEL LOGIC: Name Matching Algorithm (Fuzzy Match)
                    $pan_name = strtolower($vendor_api_response['pan_registered_name']);
                    $aadhaar_name = strtolower($vendor_api_response['aadhaar_registered_name']);
                    
                    // PHP का similar_text फंक्शन चेक करता है कि नाम कितने % सेम हैं
                    similar_text($pan_name, $aadhaar_name, $match_percentage);

                    // अगर नाम 80% से ज्यादा मैच करते हैं, तो इंस्टेंट अप्रूव कर दें
                    if ($match_percentage >= 80.0) {
                        
                        $db->beginTransaction();
                        try {
                            // डेटाबेस में KYC को इंस्टेंट 'approved' कर दें
                            $updateKyc = $db->prepare("UPDATE users SET doc_type = 'PAN_AADHAAR', doc_number = ?, kyc_status = 'approved' WHERE id = ?");
                            $updateKyc->execute([$pan_number, $user_id]);
                            
                            $db->commit();
                            
                            echo json_encode([
                                "status" => "success", 
                                "message" => "KYC Verified & Approved Instantly!", 
                                "match_score" => round($match_percentage, 2) . "%"
                            ]);
                            
                        } catch (Exception $e) {
                            $db->rollBack();
                            http_response_code(500);
                            echo json_encode(["status" => "error", "message" => "Database error during approval."]);
                        }
                    } else {
                        // नाम मैच नहीं हुआ (Fraud Prevention) -> इसे Admin Review में डाल दें
                        $updateKyc = $db->prepare("UPDATE users SET doc_type = 'PAN_AADHAAR', doc_number = ?, kyc_status = 'under_review' WHERE id = ?");
                        $updateKyc->execute([$pan_number, $user_id]);
                        
                        echo json_encode([
                            "status" => "pending", 
                            "message" => "Name mismatch detected. Sent to Admin for manual review."
                        ]);
                    }
                } else {
                    echo json_encode(["status" => "error", "message" => "Invalid PAN or Aadhaar details."]);
                }
            } else {
                http_response_code(401);
                echo json_encode(["status" => "error", "message" => "Invalid token."]);
            }
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(["status" => "error", "message" => "Server error."]);
        }
    } else {
        http_response_code(400);
        echo json_encode(["status" => "error", "message" => "PAN and Aadhaar numbers are required."]);
    }
} else {
    http_response_code(401);
    echo json_encode(["status" => "error", "message" => "Authorization header missing."]);
}
?>
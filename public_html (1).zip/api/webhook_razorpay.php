<?php
// Is endpoint ko Razorpay dashboard mein webhook URL ki tarah add karein
header("Content-Type: application/json; charset=UTF-8");

require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

// Razorpay Secret Key (Jo aapne Razorpay dashboard mein set ki hai)
$webhook_secret = "YOUR_WEBHOOK_SECRET_KEY";

// Payload aur Signature receive karein
$payload = file_get_contents('php://input');
$signature = $_SERVER['HTTP_X_RAZORPAY_SIGNATURE'] ?? '';

if (empty($payload) || empty($signature)) {
    http_response_code(400);
    exit("Invalid Payload or Signature");
}

// 1. Signature Verification (Security Check)
$expected_signature = hash_hmac('sha256', $payload, $webhook_secret);

if (!hash_equals($expected_signature, $signature)) {
    // Agar signature match nahi hota, toh request fake hai (Hack attempt)
    error_log("Webhook Signature Mismatch! Possible Fraud Attempt.");
    http_response_code(401);
    exit("Unauthorized");
}

$data = json_decode($payload, true);
$event = $data['event'] ?? '';

if ($event === 'payment.captured') {
    $payment = $data['payload']['payment']['entity'];
    
    $amount_in_paise = $payment['amount'];
    $amount_in_rupees = $amount_in_paise / 100; // Razorpay paise mein amount bhejta hai
    $provider_txn_id = $payment['id'];
    $order_id = $payment['order_id'];
    
    // Notes section se user_id nikalna (Aapko order create karte time notes mein user_id bhejna hoga)
    $user_id = $payment['notes']['user_id'] ?? null;

    if (!$user_id) {
        http_response_code(400);
        exit("User ID not found in notes");
    }

    try {
        $db->beginTransaction();

        // 2. Idempotency Check: Verify karein ki ye transaction pehle process toh nahi ho chuka?
        $stmt = $db->prepare("SELECT id FROM transactions WHERE txn_id = ? FOR UPDATE");
        $stmt->execute([$provider_txn_id]);
        if ($stmt->rowCount() > 0) {
            // Transaction already processed, webhook dobara aaya hai
            $db->rollBack();
            http_response_code(200); // 200 return karein taaki Razorpay dobara webhook na bheje
            exit("Already processed");
        }

        // 3. User ke wallet mein balance add karein
        $updateWallet = $db->prepare("UPDATE wallets SET balance = balance + ? WHERE user_id = ?");
        $updateWallet->execute([$amount_in_rupees, $user_id]);

        // 4. Transaction Log create karein (Credit)
        $logStmt = $db->prepare("INSERT INTO transactions (user_id, txn_id, type, amount, service_type, status, description) VALUES (?, ?, 'credit', ?, 'add_money', 'success', ?)");
        $desc = "Wallet Topup via Razorpay: " . $order_id;
        $logStmt->execute([$user_id, $provider_txn_id, $amount_in_rupees, $desc]);

        $db->commit();
        http_response_code(200);
        echo json_encode(["status" => "success"]);

    } catch (Exception $e) {
        $db->rollBack();
        error_log("Webhook Error: " . $e->getMessage());
        http_response_code(500);
        exit("Database Error");
    }
} else {
    // Any other event (e.g., payment.failed)
    http_response_code(200);
}
?>
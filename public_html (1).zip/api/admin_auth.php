<?php
session_start();

// 🐛 डिबगिंग के लिए एरर ऑन (ताकि असल समस्या स्क्रीन पर दिखे)
error_reporting(E_ALL);
ini_set('display_errors', 1);

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");

// Database File Path Check
$db_path = dirname(__DIR__) . '/config/database.php';
if (file_exists($db_path)) {
    require_once $db_path;
} else {
    die("Error: config/database.php file not found!");
}

$database = new Database();
$db = $database->getConnection();

// Form Data (Web Panel)
$phone = $_POST['username'] ?? ''; 
$password = $_POST['password'] ?? '';

if (!empty($phone) && !empty($password)) {
    try {
        // 🔥 UPDATE: हमने 'SELECT *' कर दिया है ताकि 'Unknown Column' का एरर कभी न आए
        $stmt = $db->prepare("SELECT * FROM users WHERE phone = ? AND role = 'admin' LIMIT 1");
        $stmt->execute([trim($phone)]);
        $admin = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($admin) {
            // 🔥 SMART CHECK: पासवर्ड कॉलम का नाम 'password' है या 'password_hash', ये खुद ढूँढ लेगा
            $db_password = $admin['password'] ?? $admin['password_hash'] ?? '';

            if (password_verify($password, $db_password)) {
                
                // SUCCESS: Session Setup
                session_regenerate_id(true); 
                $_SESSION['user_id'] = $admin['id'];
                $_SESSION['user_name'] = $admin['name'] ?? 'Admin';
                $_SESSION['role'] = 'admin';
                $_SESSION['admin_logged_in'] = true;

                // सीधा डैशबोर्ड पर भेजें
                header("Location: ../admin/index.php");
                exit();

            } else {
                // FAILED: गलत पासवर्ड
                header("Location: ../admin/login.php?error=1");
                exit();
            }
        } else {
            // FAILED: यूज़र नहीं मिला या रोल एडमिन नहीं है
            header("Location: ../admin/login.php?error=1");
            exit();
        }

    } catch (Exception $e) {
        // 🛑 अगर अब भी डेटाबेस में कोई दिक्कत होगी, तो 'Access Denied' की जगह असली एरर लाल रंग में स्क्रीन पर दिखेगा!
        die("<div style='background:#FEE2E2; padding:20px; color:#991B1B; font-family:sans-serif; text-align:center;'>
                <h2>🚨 SQL Database Error</h2>
                <p><b>Error Details:</b> " . $e->getMessage() . "</p>
             </div>");
    }
} else {
    header("Location: ../admin/login.php?error=empty");
    exit();
}
?>
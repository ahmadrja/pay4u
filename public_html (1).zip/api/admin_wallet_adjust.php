<?php
session_start();
header('Content-Type: application/json');

// 1. मास्टर डेटाबेस कनेक्शन
require_once '../config/database.php';
$database = new Database();
$db = $database->getConnection();

// 2. Strict Security: सिर्फ एडमिन ही इस API को कॉल कर सकता है
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized Access. Admin login required.']);
    exit;
}

// 3. Inputs प्राप्त करना
$user_id = intval($_POST['user_id'] ?? 0);
$amount  = floatval($_POST['amount'] ?? 0);
$action  = $_POST['action'] ?? ''; // 'add' या 'sub' (Deduct)

if ($user_id <= 0 || $amount <= 0 || !in_array($action, ['add', 'sub'])) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid input parameters.']);
    exit;
}

try {
    $db->beginTransaction();

    // 4. यूज़र का वर्तमान बैलेंस चेक करें
    $stmt = $db->prepare("SELECT balance FROM wallets WHERE user_id = ? FOR UPDATE");
    $stmt->execute([$user_id]);
    $wallet = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$wallet) {
        throw new Exception("User wallet not found.");
    }

    $current_balance = $wallet['balance'];
    
    if ($action === 'add') {
        $new_balance = $current_balance + $amount;
        $type = 'CREDIT';
        $description = "Admin Adjustment: Amount Added";
    } else {
        if ($current_balance < $amount) {
            throw new Exception("Insufficient user balance to deduct.");
        }
        $new_balance = $current_balance - $amount;
        $type = 'DEBIT';
        $description = "Admin Adjustment: Amount Deducted";
    }

    // 5. वॉलेट अपडेट करें
    $updateStmt = $db->prepare("UPDATE wallets SET balance = ?, updated_at = NOW() WHERE user_id = ?");
    $updateStmt->execute([$new_balance, $user_id]);

    // 6. मास्टर ट्रांज़ैक्शन लॉग (Ledger) में एंट्री करें
    $txn_id = "ADM" . date("YmdHis") . rand(100, 999);
    $logStmt = $db->prepare("INSERT INTO wallet_ledger (user_id, txn_id, type, amount, closing_balance, description) VALUES (?, ?, ?, ?, ?, ?)");
    $logStmt->execute([$user_id, $txn_id, $type, $amount, $new_balance, $description]);

    $db->commit();

    echo json_encode([
        'status' => 'success', 
        'message' => "Wallet successfully " . ($action === 'add' ? 'credited' : 'debited') . " with ₹$amount"
    ]);

} catch (Exception $e) {
    if ($db->inTransaction()) { $db->rollBack(); }
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>
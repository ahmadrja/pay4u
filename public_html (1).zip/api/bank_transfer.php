<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();
$data = json_decode(file_get_contents("php://input"));

if(!empty($data->user_id) && !empty($data->account_no) && !empty($data->ifsc) && !empty($data->amount)) {
    
    $transfer_fee = 10.00; // Convenience fee
    $total_deduction = $data->amount + $transfer_fee;

    try {
        $db->beginTransaction();

        // 1. Check & Lock Wallet Balance
        $stmt = $db->prepare("SELECT balance FROM wallets WHERE user_id = ? FOR UPDATE");
        $stmt->execute([$data->user_id]);
        $wallet = $stmt->fetch(PDO::FETCH_ASSOC);

        if($wallet['balance'] < $total_deduction) {
            throw new Exception("Insufficient wallet balance including charges.");
        }

        // 2. Deduct from Wallet (Temporary State)
        $new_bal = $wallet['balance'] - $total_deduction;
        $upd = $db->prepare("UPDATE wallets SET balance = ? WHERE user_id = ?");
        $upd->execute([$new_bal, $data->user_id]);

        // 3. Log Pending Transaction
        $txn_id = "IMPS" . time() . rand(1000,9999);
        $log = $db->prepare("INSERT INTO transactions (user_id, txn_id, type, amount, service_type, status) VALUES (?, ?, 'debit', ?, 'transfer', 'pending')");
        $log->execute([$data->user_id, $txn_id, $total_deduction]);
        
        $db->commit(); // Save wallet state before hitting Bank API

        // 4. Hit Bank Payout API (e.g., Cashfree, RazorpayX, ICICI CIB)
        // Yahan cURL request aayegi...
        $bank_api_success = true; // Assume API call was successful for now

        if($bank_api_success) {
            // Update txn status to success
            $updTxn = $db->prepare("UPDATE transactions SET status = 'success' WHERE txn_id = ?");
            $updTxn->execute([$txn_id]);
            echo json_encode(["status" => "success", "message" => "Transfer Successful", "utr_number" => "UTR" . rand(1111111,9999999)]);
        } else {
            // 5. IF FAILED: Process Auto-Refund
            $db->beginTransaction();
            $refund = $db->prepare("UPDATE wallets SET balance = balance + ? WHERE user_id = ?");
            $refund->execute([$total_deduction, $data->user_id]);
            
            $updTxn = $db->prepare("UPDATE transactions SET status = 'failed' WHERE txn_id = ?");
            $updTxn->execute([$txn_id]);
            $db->commit();

            echo json_encode(["status" => "error", "message" => "Bank network down. Refund processed automatically."]);
        }

    } catch (Exception $e) {
        if($db->inTransaction()) $db->rollBack();
        echo json_encode(["status" => "error", "message" => $e->getMessage()]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Missing bank details."]);
}
?>
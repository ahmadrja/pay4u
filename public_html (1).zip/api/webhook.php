<?php
// यह फ़ाइल बैकग्राउंड में कॉल होगी, इसलिए कोई HTML या UI नहीं होगा।
// Error Reporting (प्रोडक्शन में इसे लॉग फ़ाइल में डायवर्ट करें)
error_reporting(E_ALL);
ini_set('display_errors', 0);

// =========================================================================
// 🔒 1. SECURITY: IP WHITELISTING (सबसे महत्वपूर्ण)
// =========================================================================
// कोई हैकर डमी डेटा भेजकर यूज़र का बैलेंस न बढ़ा ले, इसके लिए सिर्फ API प्रोवाइडर 
// के IP Address को ही इस फ़ाइल को एक्सेस करने की परमिशन दें।
$allowed_ips = ['192.168.1.100', '203.0.113.50']; // (यहाँ अपने प्रोवाइडर के असली IP डालें)
$client_ip = $_SERVER['REMOTE_ADDR'];

/* // रियल ऐप में इस चेक को इनेबल करें:
if (!in_array($client_ip, $allowed_ips)) {
    http_response_code(403);
    die(json_encode(['status' => 'error', 'message' => 'Unauthorized IP Address']));
}
*/

// =========================================================================
// 📥 2. CAPTURE INCOMING DATA
// =========================================================================
// प्रोवाइडर आमतौर पर JSON फॉर्मेट में डेटा भेजते हैं
$json_data = file_get_contents('php://input');
$data = json_decode($json_data, true);

// अगर डेटा JSON नहीं है, तो GET/POST पैरामीटर्स चेक करें (प्रोवाइडर के डॉक्यूमेंटेशन के अनुसार)
$txn_id = $data['client_txn_id'] ?? $_REQUEST['txnid'] ?? '';
$operator_ref = $data['operator_ref'] ?? $_REQUEST['op_ref'] ?? '';
$status = strtoupper($data['status'] ?? $_REQUEST['status'] ?? ''); // SUCCESS, FAILED, REFUNDED

if (empty($txn_id) || empty($status)) {
    http_response_code(400);
    die(json_encode(['status' => 'error', 'message' => 'Invalid Callback Data']));
}

// =========================================================================
// ⚙️ 3. DATABASE LOGIC & IDEMPOTENCY CHECK
// =========================================================================
/* // PDO Database Connection
$pdo = new PDO("mysql:host=localhost;dbname=superpay_db", "root", "");
*/

// STEP A: ट्रांजैक्शन की वर्तमान स्थिति चेक करें
// $stmt = $pdo->prepare("SELECT user_id, amount, status FROM transactions WHERE txn_id = ? FOR UPDATE");
// $stmt->execute([$txn_id]);
// $transaction = $stmt->fetch(PDO::FETCH_ASSOC);

// डमी डेटा (डेमो के लिए)
$transaction = [
    'user_id' => 101,
    'amount' => 299.00,
    'status' => 'PENDING' // वर्तमान स्टेटस
];

if (!$transaction) {
    http_response_code(404);
    die(json_encode(['status' => 'error', 'message' => 'Transaction not found']));
}

// IDEMPOTENCY: अगर ट्रांजैक्शन पहले ही Success या Failed हो चुका है, तो दोबारा प्रोसेस न करें
if ($transaction['status'] === 'SUCCESS' || $transaction['status'] === 'FAILED') {
    http_response_code(200);
    die(json_encode(['status' => 'success', 'message' => 'Already processed']));
}

// =========================================================================
// 🔄 4. PROCESS THE UPDATE (SUCCESS OR FAIL)
// =========================================================================
try {
    // $pdo->beginTransaction();

    if ($status === 'SUCCESS') {
        // रिचार्ज पास हो गया है
        // Query: UPDATE transactions SET status = 'SUCCESS', op_ref = ? WHERE txn_id = ?
        
        // (ऑप्शनल) अगर आपने कमीशन/कैशबैक पेंडिंग रखा था, तो अब यूज़र के वॉलेट में क्रेडिट करें।
        
    } elseif ($status === 'FAILED' || $status === 'REFUNDED') {
        // रिचार्ज फ़ेल हो गया है
        // Query: UPDATE transactions SET status = 'FAILED' WHERE txn_id = ?
        
        // 💰 AUTO-REFUND LOGIC (यूज़र का पैसा वापस वॉलेट में डालें)
        // Query: UPDATE users SET wallet_balance = wallet_balance + ? WHERE id = ?
        
        // एक रिफंड की एंट्री लेज़र (Passbook) में करें ताकि यूज़र को रिफंड की हिस्ट्री दिखे
        // Query: INSERT INTO wallet_ledger (user_id, txn_id, type, amount, description) 
        //        VALUES (?, ?, 'CREDIT', ?, 'Refund for failed recharge')
    }

    // $pdo->commit();

    // 5. प्रोवाइडर को 200 OK रिस्पॉन्स दें ताकि वह दोबारा सेम Webhook न भेजे
    http_response_code(200);
    echo json_encode(['status' => 'success', 'message' => 'Callback received and processed']);

} catch (Exception $e) {
    // $pdo->rollBack();
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'Internal Server Error']);
}
?>
<?php
// CORS and Security Headers
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
// नोट: multipart/form-data के लिए Content-Type हैडर ऐप खुद सेट करता है, इसलिए यहाँ नहीं लिखा है।

require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

// 1. Authorization Token एक्स्ट्रेक्ट करें
$headers = apache_request_headers();
$auth_header = isset($headers['Authorization']) ? $headers['Authorization'] : (isset($headers['authorization']) ? $headers['authorization'] : '');

if (!empty($auth_header) && preg_match('/Bearer\s(\S+)/', $auth_header, $matches)) {
    $token = $matches[1];
    
    // 2. Token Verify करें
    try {
        $stmt = $db->prepare("SELECT id, kyc_status FROM users WHERE auth_token = ? AND role = 'user' LIMIT 1");
        $stmt->execute([$token]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            // अगर KYC पहले से Approved या Under Review है, तो दोबारा अपलोड न करने दें
            if ($user['kyc_status'] === 'approved' || $user['kyc_status'] === 'under_review') {
                http_response_code(400);
                echo json_encode(["status" => "error", "message" => "KYC is already {$user['kyc_status']}."]);
                exit();
            }

            $user_id = $user['id'];
            
            // 3. फॉर्म डेटा रीड करें
            $doc_type = isset($_POST['doc_type']) ? htmlspecialchars(strip_tags($_POST['doc_type'])) : '';
            $doc_number = isset($_POST['doc_number']) ? htmlspecialchars(strip_tags($_POST['doc_number'])) : '';

            // 4. File Upload Security Logic
            if (!empty($doc_type) && !empty($doc_number) && isset($_FILES['document_image'])) {
                
                $upload_dir = "../uploads/kyc/";
                // अगर फोल्डर नहीं है, तो बना लें
                if (!is_dir($upload_dir)) {
                    mkdir($upload_dir, 0755, true);
                }

                $file = $_FILES['document_image'];
                $file_name = $file['name'];
                $file_tmp = $file['tmp_name'];
                $file_size = $file['size'];
                $file_error = $file['error'];

                // फाइल एक्सटेंशन चेक करें (सिर्फ Images अलाउड हैं)
                $allowed_ext = ['jpg', 'jpeg', 'png'];
                $file_ext = explode('.', $file_name);
                $file_ext = strtolower(end($file_ext));

                if (in_array($file_ext, $allowed_ext)) {
                    if ($file_error === 0) {
                        // साइज लिमिट: Max 5MB
                        if ($file_size <= 5000000) {
                            
                            // फाइल का एक सिक्योर और यूनिक नाम बनाएं (ताकि हैकर्स फाइल रिप्लेस ना कर सकें)
                            $new_file_name = "KYC_" . $user_id . "_" . time() . "." . $file_ext;
                            $destination = $upload_dir . $new_file_name;

                            if (move_uploaded_file($file_tmp, $destination)) {
                                
                                // 5. Database में KYC डिटेल्स अपडेट करें
                                $updateKyc = $db->prepare("UPDATE users SET doc_type = ?, doc_number = ?, doc_image = ?, kyc_status = 'under_review' WHERE id = ?");
                                
                                if($updateKyc->execute([$doc_type, $doc_number, $new_file_name, $user_id])) {
                                    http_response_code(200);
                                    echo json_encode(["status" => "success", "message" => "KYC documents submitted successfully. Status is now under review."]);
                                } else {
                                    http_response_code(500);
                                    echo json_encode(["status" => "error", "message" => "Failed to update database."]);
                                }

                            } else {
                                http_response_code(500);
                                echo json_encode(["status" => "error", "message" => "Failed to save file on server."]);
                            }
                        } else {
                            http_response_code(400);
                            echo json_encode(["status" => "error", "message" => "File size too large. Max allowed size is 5MB."]);
                        }
                    } else {
                        http_response_code(400);
                        echo json_encode(["status" => "error", "message" => "Error uploading file."]);
                    }
                } else {
                    http_response_code(400);
                    echo json_encode(["status" => "error", "message" => "Invalid file type. Only JPG, JPEG, and PNG are allowed."]);
                }
            } else {
                http_response_code(400);
                echo json_encode(["status" => "error", "message" => "Document type, number, and image are required."]);
            }
        } else {
            http_response_code(401);
            echo json_encode(["status" => "error", "message" => "Invalid or expired token."]);
        }
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(["status" => "error", "message" => "Server error occurred."]);
    }
} else {
    http_response_code(401);
    echo json_encode(["status" => "error", "message" => "Authorization header missing or invalid."]);
}
?>
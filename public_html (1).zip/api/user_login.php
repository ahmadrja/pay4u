<?php
session_start();
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");

require_once '../config/database.php';
$database = new Database();
$db = $database->getConnection();

$data = json_decode(file_get_contents("php://input"));
$phone = $data->phone ?? $_POST['phone'] ?? '';
$password = $data->password ?? $_POST['password'] ?? '';

if (!empty($phone) && !empty($password)) {
    try {
        // Sirf 'user' role walo ko login karne dega (Admin ko nahi)
        $stmt = $db->prepare("SELECT id, name, password, status FROM users WHERE phone = ? AND role = 'user' LIMIT 1");
        $stmt->execute([trim($phone)]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            if ($user['status'] !== 'active') {
                echo json_encode(["status" => "error", "message" => "Your account is inactive or blocked."]);
                exit;
            }

            if (password_verify($password, $user['password'])) {
                // Login Success - Session Create karein
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['name'];
                $_SESSION['role'] = 'user';
                $_SESSION['user_logged_in'] = true;

                echo json_encode(["status" => "success", "message" => "Login successful!", "redirect" => "dashboard.php"]);
            } else {
                echo json_encode(["status" => "error", "message" => "Incorrect password!"]);
            }
        } else {
            echo json_encode(["status" => "error", "message" => "Phone number not registered!"]);
        }
    } catch (Exception $e) {
        echo json_encode(["status" => "error", "message" => "Server error occurred."]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Phone and password are required."]);
}
?>
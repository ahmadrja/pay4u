<?php
session_start();
// Security Check
if(!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
$wallet_balance = $_SESSION['wallet_balance'] ?? 0.00;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pay Utility Bills - SuperPay</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --primary: #4F46E5; --bg-color: #F3F4F6; --card-bg: #FFFFFF; }
        body { font-family: 'Segoe UI', sans-serif; background: var(--bg-color); margin: 0; display: flex; justify-content: center; }
        .app-container { width: 100%; max-width: 480px; background: var(--card-bg); min-height: 100vh; position: relative; box-shadow: 0 0 20px rgba(0,0,0,0.05); }
        
        .header { background: var(--primary); color: white; padding: 20px; display: flex; align-items: center; gap: 15px; font-size: 18px; font-weight: 600; }
        .header i { cursor: pointer; }
        
        .form-container { padding: 20px; }
        .input-group { margin-bottom: 20px; }
        .input-group label { display: block; font-size: 13px; color: #4B5563; margin-bottom: 8px; font-weight: 600; }
        .input-group select, .input-group input { width: 100%; padding: 14px; border: 1px solid #D1D5DB; border-radius: 10px; font-size: 15px; outline: none; box-sizing: border-box; }
        .input-group select:focus, .input-group input:focus { border-color: var(--primary); box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.1); }
        
        .btn-action { width: 100%; background: var(--primary); color: white; border: none; padding: 15px; border-radius: 10px; font-size: 16px; font-weight: 600; cursor: pointer; transition: 0.2s; }
        .btn-action:hover { background: #4338CA; }
        
        /* Bill Fetch Details Card */
        #billDetailsCard { display: none; background: #F9FAFB; border: 1px solid #E5E7EB; border-radius: 12px; padding: 20px; margin-top: 20px; }
        .bill-row { display: flex; justify-content: space-between; margin-bottom: 10px; font-size: 14px; }
        .bill-amount { font-size: 24px; font-weight: bold; color: #1F2937; margin-bottom: 15px; text-align: center; }
        
        /* Toast Notification */
        #toast { visibility: hidden; min-width: 250px; background-color: #333; color: #fff; text-align: center; border-radius: 8px; padding: 16px; position: fixed; z-index: 1001; left: 50%; bottom: 30px; transform: translateX(-50%); opacity: 0; transition: 0.3s; }
        #toast.show { visibility: visible; bottom: 50px; opacity: 1; }
    </style>
</head>
<body>

    <div class="app-container">
        <div class="header">
            <i class="fas fa-arrow-left" onclick="window.location.href='index.php'"></i>
            Pay Utility Bills
        </div>

        <div class="form-container">
            <div style="background: #EEF2FF; color: var(--primary); padding: 10px 15px; border-radius: 8px; font-weight: 600; font-size: 14px; margin-bottom: 20px;">
                <i class="fas fa-wallet"></i> Wallet Balance: ₹<?php echo number_format($wallet_balance, 2); ?>
            </div>

            <div class="input-group">
                <label>Biller Category</label>
                <select id="billerCategory">
                    <option value="Electricity">Electricity</option>
                    <option value="Water">Water</option>
                    <option value="Gas">Piped Gas</option>
                    <option value="Broadband">Broadband</option>
                </select>
            </div>

            <div class="input-group">
                <label>Select Biller Board</label>
                <select id="billerBoard">
                    <option value="UPPCL">Uttar Pradesh Power Corp (UPPCL)</option>
                    <option value="BSES_RAJDHANI">BSES Rajdhani Power Limited</option>
                    <option value="MAHAVITARAN">Maharashtra State Electricity (MSEDCL)</option>
                    <option value="NBPDCL">North Bihar Power Distribution</option>
                </select>
            </div>

            <div class="input-group">
                <label>Consumer Number / CA Number</label>
                <input type="text" id="consumerNumber" placeholder="Enter Consumer ID" required autocomplete="off">
            </div>

            <button class="btn-action" id="fetchBtn" onclick="fetchBill()">Fetch Bill</button>

            <div id="billDetailsCard">
                <div class="bill-amount" id="displayAmount">₹ 0.00</div>
                <div class="bill-row">
                    <span style="color: #6B7280;">Customer Name:</span>
                    <strong id="displayName" style="color: #1F2937;">-</strong>
                </div>
                <div class="bill-row">
                    <span style="color: #6B7280;">Due Date:</span>
                    <strong id="displayDueDate" style="color: #EF4444;">-</strong>
                </div>
                
                <input type="hidden" id="finalAmount">
                <button class="btn-action" id="payBtn" style="margin-top: 15px; background: #10B981;" onclick="processPayment()">
                    <i class="fas fa-check-circle"></i> Pay Securely
                </button>
            </div>
        </div>
    </div>

    <div id="toast">Notification</div>

    <script>
        // 1. Fetch Bill Logic (AJAX Simulation)
        function fetchBill() {
            const consumerNo = document.getElementById('consumerNumber').value;
            if(!consumerNo) { showToast('Please enter consumer number'); return; }

            const btn = document.getElementById('fetchBtn');
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Fetching from Biller...';
            btn.disabled = true;

            // रियल ऐप में यहाँ api/fetch_bill.php को कॉल किया जाएगा। 
            // डेमो के लिए हम setTimeout का उपयोग कर रहे हैं।
            setTimeout(() => {
                document.getElementById('displayAmount').innerText = '₹ 1,250.00';
                document.getElementById('finalAmount').value = '1250.00';
                document.getElementById('displayName').innerText = 'Ramesh Kumar';
                document.getElementById('displayDueDate').innerText = '25 Mar 2026';
                
                document.getElementById('billDetailsCard').style.display = 'block';
                btn.style.display = 'none'; // Fetch बटन छुपा दें
            }, 1500);
        }

        // 2. Process Payment Logic (AJAX Call to api/pay_bill.php)
        function processPayment() {
            const payBtn = document.getElementById('payBtn');
            const amount = document.getElementById('finalAmount').value;
            const category = document.getElementById('billerCategory').value;
            const board = document.getElementById('billerBoard').value;
            const consumerNo = document.getElementById('consumerNumber').value;

            payBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
            payBtn.disabled = true;

            const payload = { category: category, board: board, consumer_no: consumerNo, amount: amount };

            fetch('api/pay_bill.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            })
            .then(res => res.json())
            .then(data => {
                if(data.status === 'success') {
                    showToast(data.message);
                    setTimeout(() => window.location.href = 'history.php', 2000); // रीडायरेक्ट
                } else {
                    showToast(data.message);
                    payBtn.innerHTML = '<i class="fas fa-check-circle"></i> Pay Securely';
                    payBtn.disabled = false;
                }
            })
            .catch(err => {
                showToast("Server Error! Please try again.");
                payBtn.innerHTML = '<i class="fas fa-check-circle"></i> Pay Securely';
                payBtn.disabled = false;
            });
        }

        function showToast(msg) {
            const toast = document.getElementById("toast");
            toast.innerText = msg;
            toast.className = "show";
            setTimeout(() => { toast.className = toast.className.replace("show", ""); }, 3000);
        }
    </script>
</body>
</html>
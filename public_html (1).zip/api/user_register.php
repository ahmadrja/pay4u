<?php
// API Headers for App & Web support
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");

require_once '../config/database.php';
$database = new Database();
$db = $database->getConnection();

// Hybrid Input: JSON (App) or Form Data (Web)
$data = json_decode(file_get_contents("php://input"));

$name = $data->name ?? $_POST['name'] ?? '';
$phone = $data->phone ?? $_POST['phone'] ?? '';
$password = $data->password ?? $_POST['password'] ?? '';

// Validation check
if (!empty($name) && !empty($phone) && !empty($password)) {
    
    // 1. Check karein ki user pehle se registered toh nahi hai
    $check_stmt = $db->prepare("SELECT id FROM users WHERE phone = ? LIMIT 1");
    $check_stmt->execute([$phone]);
    
    if ($check_stmt->rowCount() > 0) {
        echo json_encode(["status" => "error", "message" => "This phone number is already registered! Please login."]);
        exit;
    }

    try {
        // Transaction start (Ya toh dono table me entry hogi, ya kisi me nahi)
        $db->beginTransaction();

        // 2. Naya User Create karein (role = 'user')
        $hashed_password = password_hash($password, PASSWORD_BCRYPT);
        $user_query = "INSERT INTO users (name, phone, password, role, status) VALUES (?, ?, ?, 'user', 'active')";
        $user_stmt = $db->prepare($user_query);
        $user_stmt->execute([$name, $phone, $hashed_password]);

        // Naye user ki ID nikalein
        $new_user_id = $db->lastInsertId();

        // 3. User ke liye naya Wallet banayein (0.00 balance ke sath)
        $wallet_query = "INSERT INTO wallets (user_id, balance) VALUES (?, 0.00)";
        $wallet_stmt = $db->prepare($wallet_query);
        $wallet_stmt->execute([$new_user_id]);

        // Sab kuch save karein
        $db->commit();

        echo json_encode([
            "status" => "success", 
            "message" => "Account created successfully! Wallet is now active.",
            "user_id" => $new_user_id
        ]);

    } catch (Exception $e) {
        // Agar koi error aaya toh database entry cancel kar dein
        $db->rollBack();
        echo json_encode(["status" => "error", "message" => "Registration failed due to server error."]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Name, Phone, and Password are required fields."]);
}
?>
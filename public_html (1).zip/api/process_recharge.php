<?php
session_start();
header('Content-Type: application/json'); // API response format

// 1. Database Connection को सुरक्षित रूप से शामिल करें
require_once '../config/database.php';

// 2. Security Check: यूज़र का लॉग-इन होना ज़रूरी है
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized Access. Please login.']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 'error', 'message' => 'Invalid Request Method']);
    exit;
}

// 3. User Inputs (सुरक्षित तरीके से लेना)
$user_id  = $_SESSION['user_id'];
$mobile   = htmlspecialchars($_POST['mobile_number'] ?? '');
$operator = htmlspecialchars($_POST['operator'] ?? '');
$amount   = floatval($_POST['amount'] ?? 0);

if (empty($mobile) || empty($operator) || $amount <= 0) {
    echo json_encode(['status' => 'error', 'message' => 'Please fill all details correctly.']);
    exit;
}

try {
    // 4. WALLET BALANCE CHECK (डबल खर्च रोकने के लिए FOR UPDATE का उपयोग)
    $stmt = $pdo->prepare("SELECT wallet_balance FROM users WHERE id = ? FOR UPDATE");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();

    if (!$user || $user['wallet_balance'] < $amount) {
        echo json_encode(['status' => 'error', 'message' => 'Insufficient Wallet Balance! Please add money.']);
        exit;
    }

    // =========================================================================
    // 🚀 MASTER ADMIN CONTROL: FETCH ACTIVE APIs DYNAMICALLY
    // =========================================================================
    // यह एडमिन पैनल से सिर्फ चालू (Active) API लाएगा और Priority के हिसाब से सेट करेगा
    $stmt = $pdo->prepare("SELECT * FROM api_providers WHERE service_type = 'Mobile Recharge' AND status = 'active' ORDER BY priority ASC");
    $stmt->execute();
    $active_apis = $stmt->fetchAll();

    if (count($active_apis) === 0) {
        echo json_encode(['status' => 'error', 'message' => 'Service is temporarily down. No active providers found.']);
        exit;
    }

    $txn_id = "TXN" . date("YmdHis") . rand(1000, 9999);
    $recharge_successful = false;
    $final_provider = "";
    $profit_earned = 0;
    $api_ref_id = "";

    // =========================================================================
    // 🔄 SMART API FAILOVER LOOP
    // =========================================================================
    foreach ($active_apis as $api) {
        
        // डेटाबेस से API डिटेल्स प्राप्त करना
        $provider_name = $api['provider_name'];
        $api_url       = $api['api_url'];
        $api_key       = $api['api_token'];
        $margin        = $api['admin_margin_percent'];

        /* // -----------------------------------------------------------------
        // 🌐 REAL cURL API CALL (प्रोडक्शन में इसे अनकमेंट करें और प्रोवाइडर के अनुसार सेट करें)
        // -----------------------------------------------------------------
        $post_data = json_encode([
            'api_key' => $api_key,
            'number' => $mobile,
            'operator' => $operator,
            'amount' => $amount,
            'client_txn_id' => $txn_id
        ]);

        $ch = curl_init($api_url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
        curl_setopt($ch, CURLOPT_TIMEOUT, 15); // 15 Second Timeout
        $response = curl_exec($ch);
        curl_close($ch);
        
        $result = json_decode($response, true);
        */

        // SIMULATION: डेमो के लिए हम मान रहे हैं कि API ने Success रिटर्न किया है
        $result = ['status' => 'SUCCESS', 'ref_id' => 'OPR_' . rand(11111, 99999)]; 

        // 5. Checking API Response
        if ($result['status'] === 'SUCCESS') {
            $recharge_successful = true;
            $final_provider = $provider_name;
            $profit_earned = ($amount * $margin) / 100;
            $api_ref_id = $result['ref_id'] ?? 'N/A';
            
            break; // SUCCESS मिल गया! लूप यहीं रोक दें, अगली API ट्राई न करें।
        } 
        // अगर Fail हुआ तो लूप आगे बढ़ेगा और दूसरी API को ट्राई करेगा
    }

    // =========================================================================
    // 💰 FINAL DATABASE PROCESSING (WALLET DEDUCTION & LEDGER)
    // =========================================================================
    if ($recharge_successful) {
        
        $pdo->beginTransaction(); // डेटाबेस ट्रांसक्शन शुरू

        // STEP A: वॉलेट से पैसे काटें
        $new_balance = $user['wallet_balance'] - $amount;
        $stmt = $pdo->prepare("UPDATE users SET wallet_balance = ? WHERE id = ?");
        $stmt->execute([$new_balance, $user_id]);
        
        $_SESSION['wallet_balance'] = $new_balance; // Session बैलेंस अपडेट करें

        // STEP B: Transactions टेबल में एंट्री करें
        $stmt = $pdo->prepare("INSERT INTO transactions (txn_id, user_id, service_type, provider_used, amount, profit_earned, operator_ref, status) VALUES (?, ?, 'Mobile Recharge', ?, ?, ?, ?, 'SUCCESS')");
        $stmt->execute([$txn_id, $user_id, $final_provider, $amount, $profit_earned, $api_ref_id]);

        // STEP C: Wallet Ledger (पासबुक) में एंट्री करें
        $desc = "Recharge for " . $mobile . " (" . $operator . ")";
        $stmt = $pdo->prepare("INSERT INTO wallet_ledger (user_id, txn_id, type, amount, closing_balance, description) VALUES (?, ?, 'DEBIT', ?, ?, ?)");
        $stmt->execute([$user_id, $txn_id, $amount, $new_balance, $desc]);

        $pdo->commit(); // सब कुछ सही है, डेटाबेस में सेव करें

        echo json_encode([
            'status' => 'success',
            'message' => 'Recharge Successful!',
            'txn_id' => $txn_id,
            'operator_ref' => $api_ref_id
        ]);

    } else {
        // अगर सभी APIs फ़ेल हो गईं (पैसे नहीं कटेंगे)
        echo json_encode([
            'status' => 'error',
            'message' => 'All operator networks are currently down. Please try again later.',
            'txn_id' => $txn_id
        ]);
    }

} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack(); // अगर कोई एरर आई, तो कटे हुए पैसे वापस कर दो
    }
    error_log("Recharge Error: " . $e->getMessage()); // एरर को लॉग फ़ाइल में सेव करें
    echo json_encode(['status' => 'error', 'message' => 'System error occurred. Please try again.']);
}
?>
<?php
// Admin Authentication Check (सबसे जरूरी सुरक्षा)
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['role'] !== 'admin') {
    http_response_code(403);
    echo json_encode(["status" => "error", "message" => "Unauthorized access. Only admins can perform this action."]);
    exit();
}

header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");

require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

// Admin Panel से आने वाला डेटा (POST request)
$user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;
$action = isset($_POST['action']) ? htmlspecialchars(strip_tags($_POST['action'])) : ''; // 'approve' या 'reject'
$reject_reason = isset($_POST['reject_reason']) ? htmlspecialchars(strip_tags($_POST['reject_reason'])) : ''; 

if ($user_id > 0 && ($action === 'approve' || $action === 'reject')) {
    try {
        // पहले चेक करें कि यूजर मौजूद है या नहीं और उसकी KYC 'under_review' है या नहीं
        $stmt = $db->prepare("SELECT id, kyc_status FROM users WHERE id = ? LIMIT 1");
        $stmt->execute([$user_id]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            if ($user['kyc_status'] === 'approved') {
                echo json_encode(["status" => "error", "message" => "User KYC is already approved."]);
                exit();
            }

            $db->beginTransaction();

            if ($action === 'approve') {
                // KYC Approved: स्टेटस बदलें
                $updateKyc = $db->prepare("UPDATE users SET kyc_status = 'approved' WHERE id = ?");
                $updateKyc->execute([$user_id]);
                
                $msg = "KYC successfully approved.";
                
                // Pro-Tip: यहाँ आप यूजर को SMS/Email भेजने का कोड ट्रिगर कर सकते हैं
                
            } elseif ($action === 'reject') {
                // KYC Rejected: इमेज और डेटा डिलीट करें ताकि यूजर दोबारा सही डॉक्यूमेंट अपलोड कर सके
                // नोट: आप चाहें तो एक 'kyc_remarks' कॉलम बनाकर उसमें $reject_reason सेव कर सकते हैं
                
                $updateKyc = $db->prepare("UPDATE users SET kyc_status = 'rejected', doc_type = NULL, doc_number = NULL, doc_image = NULL WHERE id = ?");
                $updateKyc->execute([$user_id]);
                
                $msg = "KYC rejected. User data cleared for re-upload.";
                
                // (Optional) अगर 'kyc_remarks' टेबल में है, तो यहाँ सेव करें
            }

            $db->commit();
            http_response_code(200);
            echo json_encode(["status" => "success", "message" => $msg]);

        } else {
            http_response_code(404);
            echo json_encode(["status" => "error", "message" => "User not found."]);
        }
    } catch (Exception $e) {
        $db->rollBack();
        error_log("Admin KYC Action Error: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(["status" => "error", "message" => "Server error while updating KYC."]);
    }
} else {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "Invalid User ID or Action."]);
}
?>
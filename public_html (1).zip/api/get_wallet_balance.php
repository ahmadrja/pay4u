<?php
// CORS and Security Headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Authorization, Content-Type");

require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

// 1. HTTP Headers से Authorization Token एक्स्ट्रेक्ट करें (Pro-Level Security)
$headers = apache_request_headers();
$auth_header = isset($headers['Authorization']) ? $headers['Authorization'] : (isset($headers['authorization']) ? $headers['authorization'] : '');

// रेगुलर एक्सप्रेशन (Regex) का उपयोग करके 'Bearer ' वर्ड को हटाएं और सिर्फ टोकन निकालें
if (!empty($auth_header) && preg_match('/Bearer\s(\S+)/', $auth_header, $matches)) {
    $token = $matches[1];

    try {
        // 2. Token Verification & User Fetching (SQL Injection Safe)
        $stmt = $db->prepare("SELECT id, name, kyc_status FROM users WHERE auth_token = ? AND role = 'user' LIMIT 1");
        $stmt->execute([$token]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            // 3. User Authenticated Successfully! अब वॉलेट डेटा निकालें
            $walletStmt = $db->prepare("SELECT balance FROM wallets WHERE user_id = ? LIMIT 1");
            $walletStmt->execute([$user['id']]);
            $wallet = $walletStmt->fetch(PDO::FETCH_ASSOC);

            if ($wallet) {
                http_response_code(200); // 200 OK
                echo json_encode([
                    "status" => "success",
                    "data" => [
                        "user_name" => $user['name'],
                        "kyc_status" => $user['kyc_status'],
                        "wallet_balance" => number_format($wallet['balance'], 2, '.', '')
                    ]
                ]);
            } else {
                http_response_code(404); // 404 Not Found
                echo json_encode(["status" => "error", "message" => "Critical Error: Wallet not found for this user."]);
            }
        } else {
            // अगर हैकर गलत या पुराना टोकन भेजे
            http_response_code(401); // 401 Unauthorized
            echo json_encode(["status" => "error", "message" => "Invalid or expired token. Please login again."]);
        }
    } catch (Exception $e) {
        // Error Logging (Production Practice)
        error_log("Wallet Balance API Error: " . $e->getMessage());
        http_response_code(500); // 500 Internal Server Error
        echo json_encode(["status" => "error", "message" => "Internal server error occurred."]);
    }
} else {
    // अगर बिना टोकन के रिक्वेस्ट आए
    http_response_code(401);
    echo json_encode(["status" => "error", "message" => "Security Alert: Authorization header missing or invalid. Format must be 'Bearer <token>'"]);
}
?>
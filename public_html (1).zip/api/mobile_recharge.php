<?php
// CORS and Security Headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Authorization, Content-Type");

require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

// Authorization Token एक्स्ट्रेक्ट करें
$headers = apache_request_headers();
$auth_header = isset($headers['Authorization']) ? $headers['Authorization'] : (isset($headers['authorization']) ? $headers['authorization'] : '');

if (!empty($auth_header) && preg_match('/Bearer\s(\S+)/', $auth_header, $matches)) {
    $token = $matches[1];
    
    // इनपुट डेटा (JSON) रीड करें
    $data = json_decode(file_get_contents("php://input"));
    $mobile_number = isset($data->mobile_number) ? htmlspecialchars(strip_tags($data->mobile_number)) : '';
    $operator = isset($data->operator) ? htmlspecialchars(strip_tags($data->operator)) : '';
    $amount = isset($data->amount) ? floatval($data->amount) : 0;

    if (strlen($mobile_number) >= 10 && !empty($operator) && $amount > 0) {
        try {
            // 1. Token Verify करें
            $stmt = $db->prepare("SELECT id FROM users WHERE auth_token = ? AND role = 'user' LIMIT 1");
            $stmt->execute([$token]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user) {
                $user_id = $user['id'];

                // 2. वॉलेट बैलेंस चेक करें
                $walletStmt = $db->prepare("SELECT balance FROM wallets WHERE user_id = ? LIMIT 1");
                $walletStmt->execute([$user_id]);
                $wallet = $walletStmt->fetch(PDO::FETCH_ASSOC);

                if ($wallet && $wallet['balance'] >= $amount) {
                    
                    // 3. Database Transaction 1: वॉलेट से पैसे काटना
                    $db->beginTransaction();
                    $txn_id = "RCHG" . time() . rand(1000, 9999);

                    try {
                        // बैलेंस कम करें
                        $deductWallet = $db->prepare("UPDATE wallets SET balance = balance - ? WHERE user_id = ?");
                        $deductWallet->execute([$amount, $user_id]);

                        // ट्रांज़ैक्शन को 'Pending' स्टेटस के साथ सेव करें
                        $insertTxn = $db->prepare("INSERT INTO transactions (txn_id, user_id, amount, service_type, status, created_at) VALUES (?, ?, ?, ?, 'pending', NOW())");
                        $insertTxn->execute([$txn_id, $user_id, $amount, 'mobile_recharge']);

                        // ऑपरेटर को हिट करने से पहले ही बैलेंस काटना कन्फर्म करें (Safe Architecture)
                        $db->commit();

                        // =========================================================
                        // 4. THIRD-PARTY API CALL (cURL Request)
                        // =========================================================
                        
                        /* DUMMY CURL CODE - UNCOMMENT IN PRODUCTION
                        $api_url = "https://thirdparty-recharge.com/api/v1/recharge";
                        $post_data = json_encode([
                            "api_key" => "YOUR_API_KEY",
                            "mobile" => $mobile_number,
                            "operator" => $operator,
                            "amount" => $amount,
                            "client_txn_id" => $txn_id
                        ]);

                        $ch = curl_init($api_url);
                        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                        curl_setopt($ch, CURLOPT_POST, true);
                        curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
                        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
                        $response = curl_exec($ch);
                        curl_close($ch);
                        
                        $api_result = json_decode($response, true);
                        $api_status = $api_result['status']; // success, failed, pending
                        */

                        // अभी टेस्टिंग के लिए हम मान लेते हैं कि API ने 'success' दिया है
                        $api_status = 'success'; // Testing purpose
                        
                        // =========================================================
                        // 5. API के जवाब के आधार पर सेटलमेंट & COMMISSION ENGINE
                        // =========================================================
                        
                        if ($api_status === 'success') {
                            
                            // Database Transaction 2: कमीशन और स्टेटस अपडेट
                            $db->beginTransaction();
                            try {
                                // ट्रांज़ैक्शन को 'success' मार्क करें
                                $updateTxn = $db->prepare("UPDATE transactions SET status = 'success' WHERE txn_id = ?");
                                $updateTxn->execute([$txn_id]);

                                // ऑपरेटर का कमीशन रेट निकालें
                                $commStmt = $db->prepare("SELECT type, admin_margin, user_cashback FROM commissions WHERE operator_code = ? AND status = 'active' LIMIT 1");
                                $commStmt->execute([$operator]);
                                $commission_data = $commStmt->fetch(PDO::FETCH_ASSOC);

                                $cashback_msg = "";

                                if ($commission_data) {
                                    $user_cashback_amt = 0;
                                    $admin_profit_amt = 0;

                                    // कैलकुलेशन
                                    if ($commission_data['type'] === 'percentage') {
                                        $user_cashback_amt = ($amount * $commission_data['user_cashback']) / 100;
                                        $admin_profit_amt = ($amount * $commission_data['admin_margin']) / 100;
                                    } else {
                                        $user_cashback_amt = $commission_data['user_cashback'];
                                        $admin_profit_amt = $commission_data['admin_margin'];
                                    }

                                    // User को Cashback क्रेडिट करें
                                    if ($user_cashback_amt > 0) {
                                        $addCashback = $db->prepare("UPDATE wallets SET balance = balance + ? WHERE user_id = ?");
                                        $addCashback->execute([$user_cashback_amt, $user_id]);

                                        $cb_txn_id = "CBK" . time() . rand(10, 99);
                                        $insertCb = $db->prepare("INSERT INTO transactions (txn_id, user_id, amount, service_type, status, created_at) VALUES (?, ?, ?, 'cashback', 'success', NOW())");
                                        $insertCb->execute([$cb_txn_id, $user_id, $user_cashback_amt]);
                                        
                                        $cashback_msg = " and ₹" . number_format($user_cashback_amt, 2) . " cashback credited";
                                    }

                                    // Admin Profit को मेन सिस्टम में रिकॉर्ड करें
                                    if ($admin_profit_amt > 0) {
                                        // नोट: इसके लिए 'admin_revenue' नाम की टेबल होना जरूरी है
                                        $insertProfit = $db->prepare("INSERT INTO admin_revenue (txn_id, profit_amount, date) VALUES (?, ?, NOW())");
                                        $insertProfit->execute([$txn_id, $admin_profit_amt]);
                                    }
                                }

                                $db->commit();
                                echo json_encode(["status" => "success", "message" => "Recharge successful{$cashback_msg}.", "txn_id" => $txn_id]);
                                
                            } catch (Exception $e) {
                                $db->rollBack();
                                // क्रिटिकल लॉग: रिचार्ज सक्सेस था पर कमीशन फेल हो गया
                                error_log("Commission Engine Error for TXN $txn_id: " . $e->getMessage());
                                echo json_encode(["status" => "success", "message" => "Recharge successful.", "txn_id" => $txn_id]);
                            }

                        } 
                        elseif ($api_status === 'failed') {
                            // रिफंड प्रोसेस
                            $db->beginTransaction();
                            try {
                                $refundWallet = $db->prepare("UPDATE wallets SET balance = balance + ? WHERE user_id = ?");
                                $refundWallet->execute([$amount, $user_id]);

                                $updateTxn = $db->prepare("UPDATE transactions SET status = 'failed' WHERE txn_id = ?");
                                $updateTxn->execute([$txn_id]);

                                $db->commit();
                                echo json_encode(["status" => "error", "message" => "Recharge failed by operator. Amount refunded to wallet.", "txn_id" => $txn_id]);
                            } catch (Exception $e) {
                                $db->rollBack();
                                error_log("Refund Failed for TXN: $txn_id");
                                http_response_code(500);
                                echo json_encode(["status" => "error", "message" => "Recharge failed. Refund processing delayed. Please contact support."]);
                            }
                        } else {
                            // Pending state
                            echo json_encode(["status" => "pending", "message" => "Recharge is pending with operator. Please check status after 5 minutes.", "txn_id" => $txn_id]);
                        }

                    } catch (Exception $e) {
                        $db->rollBack();
                        http_response_code(500);
                        error_log("Deduction Transaction Failed: " . $e->getMessage());
                        echo json_encode(["status" => "error", "message" => "Transaction initiation failed."]);
                    }

                } else {
                    http_response_code(400);
                    echo json_encode(["status" => "error", "message" => "Insufficient wallet balance."]);
                }
            } else {
                http_response_code(401);
                echo json_encode(["status" => "error", "message" => "Invalid or expired token."]);
            }
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(["status" => "error", "message" => "Server error occurred."]);
        }
    } else {
        http_response_code(400);
        echo json_encode(["status" => "error", "message" => "Invalid input data."]);
    }
} else {
    http_response_code(401);
    echo json_encode(["status" => "error", "message" => "Authorization header missing or invalid."]);
}
?>
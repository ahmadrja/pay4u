<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");

require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

$data = json_decode(file_get_contents("php://input"));

if(!empty($data->user_id) && !empty($data->amount) && !empty($data->service_type)) {
    try {
        // Transaction shuru karein (ACID compliance)
        $db->beginTransaction();

        // 1. Wallet balance check karein (FOR UPDATE lock ke sath taaki race condition na ho)
        $stmt = $db->prepare("SELECT balance FROM wallets WHERE user_id = ? FOR UPDATE");
        $stmt->execute([$data->user_id]);
        $wallet = $stmt->fetch(PDO::FETCH_ASSOC);

        if($wallet['balance'] < $data->amount) {
            throw new Exception("Insufficient balance.");
        }

        // 2. Wallet se amount debit karein
        $new_balance = $wallet['balance'] - $data->amount;
        $updateStmt = $db->prepare("UPDATE wallets SET balance = ? WHERE user_id = ?");
        $updateStmt->execute([$new_balance, $data->user_id]);

        // 3. Transaction log banayein
        $txn_id = "TXN" . time() . rand(1000,9999);
        $logStmt = $db->prepare("INSERT INTO transactions (user_id, txn_id, type, amount, service_type, status) VALUES (?, ?, 'debit', ?, ?, 'success')");
        $logStmt->execute([$data->user_id, $txn_id, $data->amount, $data->service_type]);

        // Transaction commit karein
        $db->commit();
        
        echo json_encode(["status" => "success", "message" => "Transaction successful", "txn_id" => $txn_id, "new_balance" => $new_balance]);

    } catch (Exception $e) {
        // Yadi koi error aaye toh rollback karein
        $db->rollBack();
        echo json_encode(["status" => "error", "message" => $e->getMessage()]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Incomplete data."]);
}
?>
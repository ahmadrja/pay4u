<?php
// वेबहुक हमेशा सर्वर-टू-सर्वर होता है, इसलिए CORS की ज़्यादा जरूरत नहीं होती
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");

require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

// 1. थर्ड-पार्टी सर्वर से आने वाला डेटा (JSON) रीड करें
$data = json_decode(file_get_contents("php://input"));

// मान लेते हैं थर्ड-पार्टी कंपनी हमें यह डेटा भेज रही है:
$txn_id = isset($data->client_txn_id) ? htmlspecialchars(strip_tags($data->client_txn_id)) : '';
$operator_ref = isset($data->operator_ref) ? htmlspecialchars(strip_tags($data->operator_ref)) : '';
$new_status = isset($data->status) ? strtolower(htmlspecialchars(strip_tags($data->status))) : ''; // 'success' या 'failed'
$secret_key = isset($data->secret_key) ? $data->secret_key : '';

// 2. Security Check (अपना एक हार्ड-कोडेड सीक्रेट की सेट करें)
$MY_WEBHOOK_SECRET = "SuperPay@2026_SecureHook!#";

if ($secret_key !== $MY_WEBHOOK_SECRET) {
    http_response_code(401);
    echo json_encode(["status" => "error", "message" => "Unauthorized webhook call."]);
    exit();
}

if (!empty($txn_id) && !empty($new_status)) {
    try {
        // 3. डेटाबेस से ट्रांज़ैक्शन फेच करें (सिर्फ Pending वाली)
        // Idempotency: अगर यह पहले ही success/failed हो चुकी है, तो इग्नोर करें
        $stmt = $db->prepare("SELECT user_id, amount, status, service_type FROM transactions WHERE txn_id = ? LIMIT 1");
        $stmt->execute([$txn_id]);
        $txn = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($txn) {
            if ($txn['status'] !== 'pending') {
                // अगर स्टेटस पहले से अपडेटेड है, तो दोबारा प्रोसेस ना करें (Prevent Double Refund)
                echo json_encode(["status" => "success", "message" => "Transaction already processed earlier."]);
                exit();
            }

            $user_id = $txn['user_id'];
            $amount = $txn['amount'];

            // ==========================================
            // LOGIC 1: अगर रिचार्ज FAILED हो गया
            // ==========================================
            if ($new_status === 'failed') {
                $db->beginTransaction();
                try {
                    // यूजर को उसका पैसा वापस करें
                    $refundWallet = $db->prepare("UPDATE wallets SET balance = balance + ? WHERE user_id = ?");
                    $refundWallet->execute([$amount, $user_id]);

                    // स्टेटस 'failed' अपडेट करें और ऑपरेटर का रेफरेंस नंबर भी सेव करें
                    $updateTxn = $db->prepare("UPDATE transactions SET status = 'failed' WHERE txn_id = ?");
                    $updateTxn->execute([$txn_id]);

                    $db->commit();
                    error_log("WEBHOOK: TXN $txn_id Failed. ₹$amount refunded to User $user_id.");
                    
                    echo json_encode(["status" => "success", "message" => "Refund processed successfully."]);
                } catch (Exception $e) {
                    $db->rollBack();
                    error_log("WEBHOOK REFUND ERROR: TXN $txn_id. " . $e->getMessage());
                    http_response_code(500);
                    echo json_encode(["status" => "error", "message" => "Refund failed on database level."]);
                }
            } 
            
            // ==========================================
            // LOGIC 2: अगर रिचार्ज SUCCESS हो गया
            // ==========================================
            elseif ($new_status === 'success') {
                // (नोट: यहाँ आपको कमीशन इंजन का वही कोड डालना होगा जो हमने mobile_recharge.php में डाला था, 
                // क्योंकि जब ट्रांज़ैक्शन पेंडिंग था, तब कमीशन नहीं बंटा था।)
                
                $db->beginTransaction();
                try {
                    $updateTxn = $db->prepare("UPDATE transactions SET status = 'success' WHERE txn_id = ?");
                    $updateTxn->execute([$txn_id]);

                    // (Optional) यहाँ आप User को Commission/Cashback देने का लॉजिक रन कर सकते हैं 
                    // जैसा हमने पिछले कोड में किया था।

                    $db->commit();
                    error_log("WEBHOOK: TXN $txn_id Success confirmed by operator.");
                    
                    echo json_encode(["status" => "success", "message" => "Status updated to success."]);
                } catch (Exception $e) {
                    $db->rollBack();
                    error_log("WEBHOOK SUCCESS UPDATE ERROR: TXN $txn_id. " . $e->getMessage());
                    http_response_code(500);
                    echo json_encode(["status" => "error", "message" => "Status update failed."]);
                }
            } else {
                echo json_encode(["status" => "error", "message" => "Invalid status received."]);
            }
        } else {
            http_response_code(404);
            echo json_encode(["status" => "error", "message" => "Transaction ID not found."]);
        }
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(["status" => "error", "message" => "Server error occurred."]);
    }
} else {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "Invalid Webhook Payload."]);
}
?>
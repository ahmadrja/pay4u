<?php
// Session start for Web Users (Website compatibility)
session_start();

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");

require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

$data = json_decode(file_get_contents("php://input"));
// Agar request Web Form ($_POST) se aayi hai, toh data wahan se lein
if(empty($data)) {
    $data = (object) $_POST;
}

$action = $_GET['action'] ?? '';

if ($action === 'register') {
    // 1. User Registration Logic with Validation
    if (!empty($data->phone) && !empty($data->name) && !empty($data->password)) {
        
        // Basic Validation: Phone number must be 10 digits
        if(strlen($data->phone) < 10) {
            echo json_encode(["status" => "error", "message" => "Please enter a valid 10-digit phone number."]);
            exit;
        }

        try {
            // Password securely hash karein
            $password_hash = password_hash($data->password, PASSWORD_BCRYPT, ['cost' => 12]);
            
            $stmt = $db->prepare("INSERT INTO users (phone, name, password_hash, role, kyc_status) VALUES (?, ?, ?, 'user', 'pending')");
            $stmt->execute([$data->phone, $data->name, $password_hash]);
            
            $user_id = $db->lastInsertId();

            // Default wallet create karein
            $walletStmt = $db->prepare("INSERT INTO wallets (user_id, balance) VALUES (?, 0.00)");
            $walletStmt->execute([$user_id]);
            
            echo json_encode([
                "status" => "success", 
                "message" => "User registered successfully.", 
                "user_id" => $user_id
            ]);
        } catch (PDOException $e) {
            // Duplicate phone number catch karein
            if ($e->getCode() == 23000) {
                echo json_encode(["status" => "error", "message" => "Phone number already registered."]);
            } else {
                http_response_code(500);
                echo json_encode(["status" => "error", "message" => "Database error occurred."]);
            }
        }
    } else {
        echo json_encode(["status" => "error", "message" => "Name, Phone, and Password are required."]);
    }

} elseif ($action === 'login') {
    // 2. User Login Logic with Token Saving & Sessions
    if (!empty($data->phone) && !empty($data->password)) {
        try {
            $stmt = $db->prepare("SELECT id, name, password_hash, kyc_status, role FROM users WHERE phone = ? LIMIT 1");
            $stmt->execute([$data->phone]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user && password_verify($data->password, $user['password_hash'])) {
                
                // Secure API Token Generate Karein
                $auth_token = bin2hex(random_bytes(32)); 
                
                // CRITICAL FIX: Token ko database mein user ke aage save karein taaki aage verify ho sake
                // NOTE: Make sure aapki 'users' table mein 'auth_token' naam ka ek column ho.
                $updateTokenStmt = $db->prepare("UPDATE users SET auth_token = ? WHERE id = ?");
                $updateTokenStmt->execute([$auth_token, $user['id']]);

                // Web Login ke liye Session set karein
                $_SESSION['user_logged_in'] = true;
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['role'] = $user['role'];
                $_SESSION['user_name'] = $user['name'];
                
                // Password hash hata dein security ke liye
                unset($user['password_hash']);
                
                echo json_encode([
                    "status" => "success", 
                    "message" => "Login successful", 
                    "token" => $auth_token, // Android App yeh token store karega
                    "user_data" => $user
                ]);
            } else {
                http_response_code(401);
                echo json_encode(["status" => "error", "message" => "Invalid phone number or password."]);
            }
        } catch (Exception $e) {
            error_log("User Login Error: " . $e->getMessage());
            http_response_code(500);
            echo json_encode(["status" => "error", "message" => "Server error."]);
        }
    } else {
        echo json_encode(["status" => "error", "message" => "Phone and password are required."]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Invalid action specified. Use ?action=register or ?action=login"]);
}
?>
<?php
// CORS and Security Headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Authorization, Content-Type");

require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

// 1. Authorization Token एक्स्ट्रेक्ट करें (Security Check)
$headers = apache_request_headers();
$auth_header = isset($headers['Authorization']) ? $headers['Authorization'] : (isset($headers['authorization']) ? $headers['authorization'] : '');

if (!empty($auth_header) && preg_match('/Bearer\s(\S+)/', $auth_header, $matches)) {
    $token = $matches[1];

    try {
        // 2. Token Verify करें और User ID निकालें
        $stmt = $db->prepare("SELECT id FROM users WHERE auth_token = ? AND role = 'user' LIMIT 1");
        $stmt->execute([$token]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            $user_id = $user['id'];

            // 3. Pagination Setup (Pro-Level Scaling)
            // URL से पेज नंबर लें, डिफ़ॉल्ट पेज 1 होगा (e.g., ?page=1)
            $page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
            $limit = 15; // एक बार में 15 ट्रांज़ैक्शन दिखाएं
            $offset = ($page - 1) * $limit;

            // 4. Fetch Transactions (Latest First)
            // PDO में LIMIT और OFFSET के साथ bindParam इस्तेमाल करना जरूरी है
            $txnQuery = "SELECT txn_id, amount, service_type, status, created_at 
                         FROM transactions 
                         WHERE user_id = :user_id 
                         ORDER BY created_at DESC 
                         LIMIT :limit OFFSET :offset";
            
            $txnStmt = $db->prepare($txnQuery);
            $txnStmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
            $txnStmt->bindParam(':limit', $limit, PDO::PARAM_INT);
            $txnStmt->bindParam(':offset', $offset, PDO::PARAM_INT);
            $txnStmt->execute();

            $transactions = $txnStmt->fetchAll(PDO::FETCH_ASSOC);

            // 5. Total Transactions Count (ताकि ऐप को पता चले कि और डेटा है या नहीं)
            $countStmt = $db->prepare("SELECT COUNT(id) as total FROM transactions WHERE user_id = ?");
            $countStmt->execute([$user_id]);
            $total_row = $countStmt->fetch(PDO::FETCH_ASSOC);
            $total_transactions = $total_row['total'];
            $total_pages = ceil($total_transactions / $limit);

            // 6. Response Format
            http_response_code(200);
            echo json_encode([
                "status" => "success",
                "message" => "Transactions fetched successfully.",
                "data" => [
                    "current_page" => $page,
                    "total_pages" => $total_pages,
                    "total_transactions" => $total_transactions,
                    "transactions" => $transactions
                ]
            ]);

        } else {
            http_response_code(401);
            echo json_encode(["status" => "error", "message" => "Invalid or expired token. Please login again."]);
        }
    } catch (Exception $e) {
        error_log("Transaction History API Error: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(["status" => "error", "message" => "Server error while fetching history."]);
    }
} else {
    http_response_code(401);
    echo json_encode(["status" => "error", "message" => "Security Alert: Authorization header missing."]);
}
?>
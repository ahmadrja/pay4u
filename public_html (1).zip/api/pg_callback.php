<?php
session_start();

// 1. Database Connection (Secure PDO)
/*
$host = 'localhost'; $dbname = 'superpay_db'; $db_user = 'root'; $db_pass = '';
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $db_user, $db_pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (Exception $e) {
    die("Database Connection Failed.");
}
*/

// 2. Gateway Secret Keys (रियल ऐप में इसे config.php में रखें)
$key_id = 'YOUR_RAZORPAY_KEY_ID';
$key_secret = 'YOUR_RAZORPAY_SECRET_KEY';

// 3. Capture POST Data from Payment Gateway
$razorpay_payment_id = $_POST['razorpay_payment_id'] ?? '';
$razorpay_signature  = $_POST['razorpay_signature'] ?? '';
$app_order_id        = $_POST['app_order_id'] ?? ''; // हमारा जनरेट किया हुआ Order ID
$user_id             = $_SESSION['user_id'] ?? 101; 

$payment_successful = false;
$error_message = "";

// 4. Cryptographic Signature Verification (Anti-Hacking Security)
if (!empty($razorpay_payment_id) && !empty($razorpay_signature)) {
    try {
        // Signature बनाने का फॉर्मूला: hash_hmac('sha256', order_id + "|" + payment_id, secret_key)
        $generated_signature = hash_hmac('sha256', $app_order_id . "|" . $razorpay_payment_id, $key_secret);

        // डमी वेरिफिकेशन (Demo के लिए हम इसे True मान रहे हैं)
        // रियल ऐप में: if (hash_equals($generated_signature, $razorpay_signature)) { ... }
        $payment_successful = true; 

    } catch (Exception $e) {
        $error_message = "Signature Verification Failed! Suspicious Activity Detected.";
    }
} else {
    $error_message = "Invalid Payment Details Received.";
}

// =========================================================================
// 💰 5. WALLET & LEDGER UPDATE LOGIC
// =========================================================================
if ($payment_successful) {
    // $pdo->beginTransaction();

    try {
        // STEP A: Order Details डेटाबेस से निकालें (अमाउंट चेक करने के लिए)
        // $stmt = $pdo->prepare("SELECT amount, status FROM pg_transactions WHERE order_id = ? FOR UPDATE");
        // $stmt->execute([$app_order_id]);
        // $order = $stmt->fetch();
        
        $order_amount = 1000.00; // डमी अमाउंट
        $order_status = 'PENDING'; // डमी स्टेटस

        // Idempotency Check (डबल क्रेडिट से बचाव)
        if ($order_status === 'SUCCESS') {
            die("Payment Already Processed.");
        }

        // STEP B: User का वर्तमान वॉलेट बैलेंस निकालें
        $current_balance = $_SESSION['wallet_balance'] ?? 5430.00;
        $new_balance = $current_balance + $order_amount;

        // STEP C: User के वॉलेट में पैसा ऐड करें
        // Query: UPDATE users SET wallet_balance = ? WHERE id = ?
        $_SESSION['wallet_balance'] = $new_balance; // Demo के लिए सेशन अपडेट

        // STEP D: Passbook (Ledger) में एंट्री करें
        $description = "Money Added via Gateway (ID: " . $razorpay_payment_id . ")";
        // Query: INSERT INTO wallet_ledger (user_id, txn_id, type, amount, opening_balance, closing_balance, description) 
        // VALUES (?, ?, 'CREDIT', ?, ?, ?, ?)

        // STEP E: Transaction Status को 'SUCCESS' मार्क करें
        // Query: UPDATE pg_transactions SET status = 'SUCCESS', payment_id = ? WHERE order_id = ?

        // $pdo->commit();

        $display_status = "success";
        $display_message = "₹" . $order_amount . " has been successfully added to your wallet!";

    } catch (Exception $e) {
        // $pdo->rollBack();
        $display_status = "error";
        $display_message = "Database Error! Contact Support with Payment ID: " . $razorpay_payment_id;
    }
} else {
    // Query: UPDATE pg_transactions SET status = 'FAILED' WHERE order_id = ?
    $display_status = "error";
    $display_message = $error_message ?: "Payment was cancelled or failed.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Status - SuperPay</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Segoe UI', sans-serif; background: #F3F4F6; margin: 0; display: flex; justify-content: center; align-items: center; height: 100vh; }
        .status-card { background: white; width: 100%; max-width: 400px; padding: 40px 20px; border-radius: 16px; text-align: center; box-shadow: 0 10px 25px rgba(0,0,0,0.05); }
        .icon-box { width: 80px; height: 80px; border-radius: 50%; display: flex; justify-content: center; align-items: center; font-size: 35px; margin: 0 auto 20px; color: white; }
        .success .icon-box { background: #10B981; box-shadow: 0 0 20px rgba(16, 185, 129, 0.4); }
        .error .icon-box { background: #EF4444; box-shadow: 0 0 20px rgba(239, 68, 68, 0.4); }
        h2 { margin: 0 0 10px; color: #1F2937; }
        p { color: #6B7280; font-size: 14px; margin-bottom: 30px; line-height: 1.5; }
        .btn-home { display: inline-block; background: #4F46E5; color: white; text-decoration: none; padding: 12px 30px; border-radius: 8px; font-weight: 600; transition: 0.2s; }
        .btn-home:hover { background: #4338CA; }
    </style>
</head>
<body>

    <div class="status-card <?php echo $display_status; ?>">
        <div class="icon-box">
            <i class="fas <?php echo $display_status == 'success' ? 'fa-check' : 'fa-times'; ?>"></i>
        </div>
        <h2><?php echo $display_status == 'success' ? 'Payment Successful!' : 'Payment Failed'; ?></h2>
        <p><?php echo $display_message; ?></p>
        
        <?php if($display_status == 'success'): ?>
            <p style="font-weight: bold; color: #1F2937; margin-top: -15px;">New Balance: ₹<?php echo number_format($_SESSION['wallet_balance'], 2); ?></p>
        <?php endif; ?>

        <a href="../index.php" class="btn-home">Go to Dashboard</a>
    </div>

</body>
</html>
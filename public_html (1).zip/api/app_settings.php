<?php
// CORS Headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type, App-Secret-Key");

require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

// 1. Basic Security (Optional but recommended for public APIs)
$headers = apache_request_headers();
$app_secret = isset($headers['App-Secret-Key']) ? $headers['App-Secret-Key'] : '';

// एक स्टैटिक सीक्रेट की सेट करें जिसे आप अपने Android/Flutter कोड में हार्डकोड करेंगे
$MY_APP_SECRET = "SuperPay_App_Secret_2026"; 

if ($app_secret !== $MY_APP_SECRET) {
    http_response_code(401);
    echo json_encode(["status" => "error", "message" => "Unauthorized App Access."]);
    exit();
}

try {
    // 2. डेटाबेस से सारी सेटिंग्स निकालें
    $stmt = $db->query("SELECT setting_key, setting_value FROM app_settings");
    $settings_raw = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // 3. डेटा को एक क्लीन Key-Value JSON ऑब्जेक्ट में बदलें
    $settings = [];
    foreach ($settings_raw as $row) {
        // अगर वैल्यू 'true' या 'false' (स्ट्रिंग) है, तो उसे असली Boolean में बदलें
        $val = $row['setting_value'];
        if (strtolower($val) === 'true') $val = true;
        elseif (strtolower($val) === 'false') $val = false;
        
        $settings[$row['setting_key']] = $val;
    }

    // 4. ऐप को रिस्पॉन्स भेजें
    http_response_code(200);
    echo json_encode([
        "status" => "success",
        "data" => $settings
    ]);

} catch (Exception $e) {
    error_log("App Settings API Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Server error occurred."]);
}
?>
<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");

require_once '../config/database.php';

$data = json_decode(file_get_contents("php://input"));

if(!empty($data->source) && !empty($data->destination) && !empty($data->date)) {
    
    // Pro Tip: Yahan DB Check lagayein ki kya ye same search last 15 mins mein hui hai? Agar haan, toh DB se fast return karein (Caching).

    // Mock Third-Party API Call (e.g., Travelport, TBO, or local aggregator)
    $api_url = "https://api.thirdparty-flight.com/v1/search";
    $api_key = "YOUR_SECRET_API_KEY";

    $payload = json_encode([
        "from" => $data->source,
        "to" => $data->destination,
        "travelDate" => $data->date,
        "adults" => 1
    ]);

    // cURL setup for External API
    $ch = curl_init($api_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $api_key
    ]);

    // Note: Development ke liye hum mock response generate kar rahe hain
    // $response = curl_exec($ch);
    $response = json_encode([
        "status" => "success",
        "flights" => [
            ["airline" => "IndiGo", "flight_no" => "6E-123", "departure" => "10:00", "arrival" => "12:00", "net_fare" => 4500.00],
            ["airline" => "Air India", "flight_no" => "AI-456", "departure" => "14:00", "arrival" => "16:30", "net_fare" => 5200.00]
        ]
    ]);
    curl_close($ch);

    $api_data = json_decode($response, true);

    // Business Logic: Apply Dynamic Markup (Profit Margin)
    $admin_markup = 350.00; // Flat ₹350 profit per ticket

    if($api_data['status'] == 'success') {
        foreach($api_data['flights'] as &$flight) {
            $flight['gross_fare'] = $flight['net_fare'] + $admin_markup;
            // Hum frontend ko kabhi net_fare nahi bhejenge, sirf gross_fare bhejenge
            unset($flight['net_fare']); 
        }
        echo json_encode(["status" => "success", "data" => $api_data['flights']]);
    } else {
        echo json_encode(["status" => "error", "message" => "No flights found."]);
    }

} else {
    echo json_encode(["status" => "error", "message" => "Invalid search parameters."]);
}
?>
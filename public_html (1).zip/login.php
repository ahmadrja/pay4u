<?php
session_start();

// अगर यूज़र पहले से लॉग-इन है, तो सीधा डैशबोर्ड पर भेजें
if(isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

$error_msg = "";
$success_msg = "";

// =========================================================================
// 🔒 1. SECURE DATABASE CONNECTION (PDO)
// =========================================================================
/* $host = 'localhost'; $dbname = 'superpay_db'; $db_user = 'root'; $db_pass = '';
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $db_user, $db_pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (Exception $e) {
    die("Database Connection Error");
}
*/

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    // =========================================================================
    // 🆕 2. REGISTRATION LOGIC (Sign Up)
    // =========================================================================
    if (isset($_POST['action']) && $_POST['action'] == 'register') {
        $name = trim(htmlspecialchars($_POST['full_name']));
        $mobile = trim(htmlspecialchars($_POST['mobile']));
        $password = $_POST['password'];
        
        // Basic Validation
        if(empty($name) || empty($mobile) || empty($password)) {
            $error_msg = "All fields are required!";
        } elseif(strlen($mobile) != 10) {
            $error_msg = "Enter a valid 10-digit mobile number.";
        } else {
            // STEP A: Check if mobile already exists
            // $stmt = $pdo->prepare("SELECT id FROM users WHERE mobile = ?");
            // $stmt->execute([$mobile]);
            // if($stmt->rowCount() > 0) {
            //     $error_msg = "Account with this mobile number already exists! Please login.";
            // } else {
                
                // STEP B: Secure Password Hashing (Bcrypt) - NEVER save plain text passwords
                $hashed_password = password_hash($password, PASSWORD_BCRYPT);
                
                // STEP C: Insert New User
                // $stmt = $pdo->prepare("INSERT INTO users (full_name, mobile, password, wallet_balance, kyc_status) VALUES (?, ?, ?, 0.00, 'pending')");
                // if($stmt->execute([$name, $mobile, $hashed_password])) {
                    $success_msg = "Account created successfully! You can now login.";
                // } else {
                //     $error_msg = "Server Error. Please try again.";
                // }
            // }
        }
    }

    // =========================================================================
    // 🔑 3. LOGIN LOGIC (Sign In)
    // =========================================================================
    if (isset($_POST['action']) && $_POST['action'] == 'login') {
        $mobile = trim(htmlspecialchars($_POST['mobile']));
        $password = $_POST['password'];

        if(empty($mobile) || empty($password)) {
            $error_msg = "Mobile and Password are required!";
        } else {
            // STEP A: Fetch User from DB
            // $stmt = $pdo->prepare("SELECT id, full_name, password, wallet_balance, kyc_status FROM users WHERE mobile = ? LIMIT 1");
            // $stmt->execute([$mobile]);
            // $user = $stmt->fetch(PDO::FETCH_ASSOC);

            // SIMULATED USER FOR DEMO
            $user = [
                'id' => 101, 
                'full_name' => 'Md Ahmad', 
                'wallet_balance' => 5430.00, 
                'kyc_status' => 'verified',
                'password' => password_hash('demo123', PASSWORD_BCRYPT) // डमी पासवर्ड: demo123
            ];

            // STEP B: Verify Hashed Password
            if ($user && password_verify($password, $user['password'])) {
                
                // Session Fixation Attack से बचने के लिए ID रीजनरेट करें
                session_regenerate_id(true);

                // Session Data Set करें
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['full_name'];
                $_SESSION['wallet_balance'] = $user['wallet_balance'];
                $_SESSION['kyc_status'] = $user['kyc_status'];

                // Last Login Time और IP अपडेट करें (Security Audit के लिए)
                // $stmt = $pdo->prepare("UPDATE users SET last_login_ip = ?, last_login_time = NOW() WHERE id = ?");
                // $stmt->execute([$_SERVER['REMOTE_ADDR'], $user['id']]);

                header("Location: index.php"); // डैशबोर्ड पर भेजें
                exit;
            } else {
                $error_msg = "Invalid Mobile Number or Password!";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SuperPay - Login & Register</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --primary: #4F46E5; --bg-color: #F3F4F6; --card-bg: #FFFFFF; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: var(--bg-color); margin: 0; display: flex; justify-content: center; align-items: center; min-height: 100vh; }
        .auth-container { width: 100%; max-width: 400px; background: var(--card-bg); padding: 40px 30px; border-radius: 20px; box-shadow: 0 10px 25px rgba(0,0,0,0.05); text-align: center; }
        
        .logo-box { width: 60px; height: 60px; background: #EEF2FF; color: var(--primary); font-size: 30px; display: flex; justify-content: center; align-items: center; border-radius: 15px; margin: 0 auto 20px; }
        h2 { color: #1F2937; margin: 0 0 5px 0; }
        p.subtitle { color: #6B7280; font-size: 14px; margin-bottom: 30px; }

        /* Form Inputs */
        .form-group { position: relative; margin-bottom: 20px; text-align: left; }
        .form-group i { position: absolute; left: 15px; top: 15px; color: #9CA3AF; font-size: 16px; }
        .form-group input { width: 100%; padding: 14px 14px 14px 45px; border: 1px solid #D1D5DB; border-radius: 10px; font-size: 14px; outline: none; transition: 0.3s; box-sizing: border-box; }
        .form-group input:focus { border-color: var(--primary); box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.1); }
        
        /* Buttons */
        .btn-submit { width: 100%; background: var(--primary); color: white; border: none; padding: 15px; border-radius: 10px; font-size: 16px; font-weight: 600; cursor: pointer; transition: 0.2s; margin-top: 10px; }
        .btn-submit:hover { background: #4338CA; transform: translateY(-2px); box-shadow: 0 4px 10px rgba(79, 70, 229, 0.3);}
        
        /* Toggle Forms */
        .toggle-link { color: var(--primary); font-weight: 600; cursor: pointer; text-decoration: none; font-size: 14px; display: inline-block; margin-top: 20px; }
        .toggle-link:hover { text-decoration: underline; }
        
        /* Alerts */
        .alert { padding: 12px; border-radius: 8px; margin-bottom: 20px; font-size: 13px; font-weight: 500; text-align: left; display: flex; align-items: center; gap: 8px;}
        .alert.error { background: #FEE2E2; color: #991B1B; border: 1px solid #FECACA; }
        .alert.success { background: #D1FAE5; color: #065F46; border: 1px solid #A7F3D0; }

        /* Hide Register Form initially */
        #registerForm { display: none; }
    </style>
</head>
<body>

    <div class="auth-container">
        <div class="logo-box">
            <i class="fas fa-bolt"></i>
        </div>

        <?php if(!empty($error_msg)): ?>
            <div class="alert error"><i class="fas fa-exclamation-circle"></i> <?php echo $error_msg; ?></div>
        <?php endif; ?>
        <?php if(!empty($success_msg)): ?>
            <div class="alert success"><i class="fas fa-check-circle"></i> <?php echo $success_msg; ?></div>
        <?php endif; ?>

        <div id="loginForm">
            <h2>Welcome Back</h2>
            <p class="subtitle">Enter your details to access your wallet</p>
            
            <form method="POST" action="">
                <input type="hidden" name="action" value="login">
                
                <div class="form-group">
                    <i class="fas fa-mobile-alt"></i>
                    <input type="tel" name="mobile" placeholder="Mobile Number" required pattern="[0-9]{10}">
                </div>
                
                <div class="form-group">
                    <i class="fas fa-lock"></i>
                    <input type="password" name="password" placeholder="Password" required>
                </div>
                
                <div style="text-align: right; margin-bottom: 15px;">
                    <a href="#" style="font-size: 12px; color: #6B7280; text-decoration: none;">Forgot Password?</a>
                </div>

                <button type="submit" class="btn-submit">Secure Login</button>
            </form>
            
            <span class="toggle-link" onclick="toggleForms()">New to SuperPay? Create an account</span>
        </div>

        <div id="registerForm">
            <h2>Create Account</h2>
            <p class="subtitle">Join SuperPay in less than a minute</p>
            
            <form method="POST" action="">
                <input type="hidden" name="action" value="register">
                
                <div class="form-group">
                    <i class="fas fa-user"></i>
                    <input type="text" name="full_name" placeholder="Full Name (as per Aadhaar)" required>
                </div>

                <div class="form-group">
                    <i class="fas fa-mobile-alt"></i>
                    <input type="tel" name="mobile" placeholder="Mobile Number" required pattern="[0-9]{10}">
                </div>
                
                <div class="form-group">
                    <i class="fas fa-lock"></i>
                    <input type="password" name="password" placeholder="Create a strong password" required minlength="6">
                </div>

                <button type="submit" class="btn-submit">Sign Up Now</button>
            </form>
            
            <span class="toggle-link" onclick="toggleForms()">Already have an account? Login here</span>
        </div>

    </div>

    <script>
        // Toggle between Login and Register views
        function toggleForms() {
            const loginForm = document.getElementById('loginForm');
            const registerForm = document.getElementById('registerForm');
            
            if (loginForm.style.display === 'none') {
                loginForm.style.display = 'block';
                registerForm.style.display = 'none';
            } else {
                loginForm.style.display = 'none';
                registerForm.style.display = 'block';
            }
        }

        // If registration was successful, show login form
        <?php if(!empty($success_msg)): ?>
            document.getElementById('loginForm').style.display = 'block';
            document.getElementById('registerForm').style.display = 'none';
        <?php endif; ?>
    </script>
</body>
</html>
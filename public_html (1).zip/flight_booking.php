<?php
// PHP ब्लॉक: यहाँ आप सेशन और सिक्योरिटी चेक लगा सकते हैं
session_start();

// अगर यूज़र लॉग इन नहीं है, तो उसे लॉगिन पेज पर रीडायरेक्ट करने का लॉजिक (अभी कमेंट किया है)
// if(!isset($_SESSION['user_id'])) {
//     header("Location: login.php");
//     exit;
// }

// PHP से आज की डायनामिक तारीख निकालें ताकि यूज़र बीते हुए कल की फ्लाइट बुक न कर सके
$today = date('Y-m-d');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Flights - SuperApp</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Segoe UI', sans-serif; background: #F3F4F6; display: flex; justify-content: center; margin: 0; }
        .app-container { width: 100%; max-width: 480px; background: #FFFFFF; min-height: 100vh; box-shadow: 0 0 15px rgba(0,0,0,0.1); position: relative; }
        
        .header { background: #4F46E5; color: white; padding: 20px; display: flex; align-items: center; gap: 15px; }
        .header i { font-size: 20px; cursor: pointer; }
        
        .search-card { background: white; margin: -10px 20px 20px; padding: 20px; border-radius: 12px; box-shadow: 0 5px 15px rgba(0,0,0,0.08); position: relative; z-index: 10; border: 1px solid #E5E7EB; }
        
        .input-group { margin-bottom: 15px; }
        .input-group label { display: block; font-size: 12px; color: #6B7280; margin-bottom: 5px; font-weight: bold; }
        .input-group input { width: 100%; padding: 12px; border: 1px solid #D1D5DB; border-radius: 8px; font-size: 16px; outline: none; transition: border 0.3s; }
        .input-group input:focus { border-color: #4F46E5; }
        
        .btn-search { width: 100%; background: #10B981; color: white; border: none; padding: 15px; border-radius: 8px; font-size: 16px; font-weight: bold; cursor: pointer; transition: 0.3s; }
        .btn-search:hover { background: #059669; }

        .flight-list { padding: 20px; }
        .flight-card { background: white; padding: 15px; border-radius: 10px; border: 1px solid #E5E7EB; margin-bottom: 15px; display: flex; justify-content: space-between; align-items: center; }
        .flight-info h4 { margin: 0; color: #1F2937; }
        .flight-info p { margin: 5px 0 0; font-size: 12px; color: #6B7280; }
        .flight-price { text-align: right; }
        .flight-price h3 { margin: 0; color: #4F46E5; }
        .book-btn { background: #4F46E5; color: white; border: none; padding: 5px 15px; border-radius: 5px; margin-top: 5px; cursor: pointer; }
    </style>
</head>
<body>
    <div class="app-container">
        <div class="header">
            <i class="fas fa-arrow-left" onclick="history.back()"></i>
            <h2>Flight Search</h2>
        </div>

        <div class="search-card">
            <div class="input-group">
                <label>FROM (City or Airport)</label>
                <input type="text" id="source" placeholder="e.g., DEL">
            </div>
            <div class="input-group">
                <label>TO (City or Airport)</label>
                <input type="text" id="destination" placeholder="e.g., BOM">
            </div>
            <div class="input-group">
                <label>TRAVEL DATE</label>
                <input type="date" id="travelDate" min="<?php echo $today; ?>" value="<?php echo $today; ?>">
            </div>
            <button class="btn-search" onclick="searchFlights()">Search Flights <i class="fas fa-paper-plane"></i></button>
        </div>

        <div class="flight-list" id="flightResults">
            </div>
    </div>

    <script>
        async function searchFlights() {
            const btn = document.querySelector('.btn-search');
            btn.innerHTML = 'Searching... <i class="fas fa-spinner fa-spin"></i>';
            
            const payload = {
                source: document.getElementById('source').value,
                destination: document.getElementById('destination').value,
                date: document.getElementById('travelDate').value
            };

            try {
                // हमारे PHP बैकएंड API को कॉल करना
                const response = await fetch('/api/flight_search.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });
                const data = await response.json();

                let html = '';
                if(data.status === 'success') {
                    data.data.forEach(flight => {
                        html += `
                        <div class="flight-card">
                            <div class="flight-info">
                                <h4>${flight.airline}</h4>
                                <p>${flight.flight_no} | ${flight.departure} - ${flight.arrival}</p>
                            </div>
                            <div class="flight-price">
                                <h3>₹ ${flight.gross_fare}</h3>
                                <button class="book-btn">Book Now</button>
                            </div>
                        </div>`;
                    });
                } else {
                    html = `<p style="text-align:center; color:red;">${data.message}</p>`;
                }
                document.getElementById('flightResults').innerHTML = html;
            } catch(e) {
                alert("Error fetching flights.");
            } finally {
                btn.innerHTML = 'Search Flights <i class="fas fa-paper-plane"></i>';
            }
        }
    </script>
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page Not Found - SuperApp</title>
    <style>
        body { font-family: 'Segoe UI', sans-serif; background: #F3F4F6; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; text-align: center; }
        .error-container { background: white; padding: 40px; border-radius: 20px; box-shadow: 0 10px 25px rgba(0,0,0,0.05); max-width: 400px; }
        h1 { font-size: 80px; margin: 0; color: #4F46E5; }
        p { color: #6B7280; margin: 10px 0 25px; }
        .btn-home { background: #4F46E5; color: white; padding: 12px 25px; border-radius: 8px; text-decoration: none; font-weight: bold; }
    </style>
</head>
<body>
    <div class="error-container">
        <h1>404</h1>
        <p>Oops! The service you are looking for is currently under maintenance or does not exist.</p>
        <a href="index.php" class="btn-home">Back to Dashboard</a>
    </div>
</body>
</html>
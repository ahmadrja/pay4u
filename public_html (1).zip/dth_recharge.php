<?php
session_start();
// 1. डेटाबेस कनेक्शन (config फोल्डर में database.php होना अनिवार्य है)
require_once 'config/database.php';

// Security Check
if(!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// =========================================================================
// ⚙️ BACKEND LOGIC: TRANSACTION PROCESSING (Single File Engine)
// =========================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] == 'PROCESS_DTH') {
    header('Content-Type: application/json');
    
    $customer_id = htmlspecialchars($_POST['customer_id'] ?? '');
    $operator = htmlspecialchars($_POST['operator'] ?? '');
    $amount = floatval($_POST['amount'] ?? 0);

    // Basic Validation
    if (empty($customer_id) || empty($operator) || $amount <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid details entered.']);
        exit;
    }

    try {
        // A. Wallet Balance & Concurrency Lock
        $stmt = $pdo->prepare("SELECT wallet_balance FROM users WHERE id = ? FOR UPDATE");
        $stmt->execute([$user_id]);
        $user = $stmt->fetch();

        if (!$user || $user['wallet_balance'] < $amount) {
            echo json_encode(['status' => 'error', 'message' => 'Insufficient Wallet Balance!']);
            exit;
        }

        // B. MASTER ADMIN CONTROL: Fetch Active DTH API Provider
        // यह एडमिन पैनल द्वारा सेट की गई Active API को ही उठाएगा
        $stmt = $pdo->prepare("SELECT * FROM api_providers WHERE service_type = 'DTH' AND status = 'active' ORDER BY priority ASC LIMIT 1");
        $stmt->execute();
        $api = $stmt->fetch();

        if (!$api) {
            echo json_encode(['status' => 'error', 'message' => 'DTH Service is temporarily disabled by Admin.']);
            exit;
        }

        $txn_id = "DTH" . date("YmdHis") . rand(100, 999);
        $profit = ($amount * $api['admin_margin_percent']) / 100;

        // C. EXECUTE TRANSACTION (Database Updates)
        $pdo->beginTransaction();

        // 1. Deduct Balance
        $new_bal = $user['wallet_balance'] - $amount;
        $stmt = $pdo->prepare("UPDATE users SET wallet_balance = ? WHERE id = ?");
        $stmt->execute([$new_bal, $user_id]);
        $_SESSION['wallet_balance'] = $new_bal;

        // 2. Insert Transaction Record
        $stmt = $pdo->prepare("INSERT INTO transactions (txn_id, user_id, service_type, provider_used, amount, profit_earned, status) VALUES (?, ?, 'DTH Recharge', ?, ?, ?, 'SUCCESS')");
        $stmt->execute([$txn_id, $user_id, $api['provider_name'], $amount, $profit]);

        // 3. Update Ledger (Passbook)
        $desc = "DTH Recharge: " . $operator . " (ID: " . $customer_id . ")";
        $stmt = $pdo->prepare("INSERT INTO wallet_ledger (user_id, txn_id, type, amount, closing_balance, description) VALUES (?, ?, 'DEBIT', ?, ?, ?)");
        $stmt->execute([$user_id, $txn_id, $amount, $new_bal, $desc]);

        $pdo->commit();

        echo json_encode(['status' => 'success', 'message' => 'DTH Recharge Successful!', 'txn_id' => $txn_id]);
        exit;

    } catch (Exception $e) {
        if ($pdo->inTransaction()) { $pdo->rollBack(); }
        echo json_encode(['status' => 'error', 'message' => 'Server Error. Please try later.']);
        exit;
    }
}

// =========================================================================
// 📱 FRONTEND UI: USER INTERFACE
// =========================================================================
$wallet_balance = $_SESSION['wallet_balance'] ?? 0.00;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DTH Recharge - SuperPay</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --primary: #4F46E5; --bg: #F3F4F6; }
        body { font-family: 'Segoe UI', sans-serif; background: var(--bg); margin: 0; display: flex; justify-content: center; }
        .app-container { width: 100%; max-width: 480px; background: #fff; min-height: 100vh; box-shadow: 0 0 20px rgba(0,0,0,0.05); }
        .header { background: var(--primary); color: white; padding: 20px; display: flex; align-items: center; gap: 15px; font-weight: 600; }
        .form-body { padding: 20px; }
        .balance-chip { background: #EEF2FF; color: var(--primary); padding: 10px; border-radius: 8px; font-weight: bold; margin-bottom: 25px; text-align: center; }
        .input-group { margin-bottom: 20px; }
        .input-group label { display: block; font-size: 13px; font-weight: 600; color: #4B5563; margin-bottom: 8px; }
        .input-group input, .input-group select { width: 100%; padding: 14px; border: 1px solid #D1D5DB; border-radius: 10px; box-sizing: border-box; outline: none; }
        .btn-pay { width: 100%; background: var(--primary); color: white; border: none; padding: 16px; border-radius: 10px; font-size: 16px; font-weight: bold; cursor: pointer; }
        #msg { margin-top: 15px; padding: 10px; border-radius: 8px; display: none; font-size: 14px; text-align: center; }
    </style>
</head>
<body>

<div class="app-container">
    <div class="header">
        <i class="fas fa-arrow-left" onclick="history.back()"></i>
        DTH Recharge
    </div>

    <div class="form-body">
        <div class="balance-chip">Wallet Balance: ₹<?php echo number_format($wallet_balance, 2); ?></div>

        <div id="msg"></div>

        <div class="input-group">
            <label>Select Operator</label>
            <select id="operator">
                <option value="Airtel DTH">Airtel Digital TV</option>
                <option value="Dish TV">Dish TV</option>
                <option value="Tata Play">Tata Play</option>
                <option value="Videocon D2H">Videocon D2H</option>
                <option value="Sun Direct">Sun Direct</option>
            </select>
        </div>

        <div class="input-group">
            <label>Customer ID / VC Number</label>
            <input type="text" id="customerId" placeholder="Enter Customer ID">
        </div>

        <div class="input-group">
            <label>Amount (₹)</label>
            <input type="number" id="amount" placeholder="Enter Amount">
        </div>

        <button class="btn-pay" onclick="processDTH()">Proceed to Recharge</button>
    </div>
</div>

<script>
function processDTH() {
    const cid = document.getElementById('customerId').value;
    const op = document.getElementById('operator').value;
    const amt = document.getElementById('amount').value;
    const msgDiv = document.getElementById('msg');

    if(!cid || !amt) { alert('Fill all details'); return; }

    const btn = document.querySelector('.btn-pay');
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
    btn.disabled = true;

    const formData = new FormData();
    formData.append('action', 'PROCESS_DTH');
    formData.append('customer_id', cid);
    formData.append('operator', op);
    formData.append('amount', amt);

    fetch('dth_recharge.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        msgDiv.style.display = 'block';
        msgDiv.innerText = data.message;
        msgDiv.style.background = data.status === 'success' ? '#D1FAE5' : '#FEE2E2';
        msgDiv.style.color = data.status === 'success' ? '#065F46' : '#991B1B';
        
        if(data.status === 'success') {
            setTimeout(() => window.location.href='history.php', 2000);
        } else {
            btn.innerHTML = 'Proceed to Recharge';
            btn.disabled = false;
        }
    });
}
</script>
</body>
</html>
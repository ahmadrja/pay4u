<?php
// Database connection (PDO) - Strict Error Mode ke sath
class Database {
    private $host = "localhost";
    private $db_name = "u433139141_pay";
    private $username = "u433139141_pay";
    private $password = "Ahmad@0201";
    public $conn;

    public function getConnection() {
        $this->conn = null;
        try {
            $this->conn = new PDO("mysql:host=" . $this->host . ";dbname=" . $this->db_name, $this->username, $this->password);
            // Security: Disable emulated prepares, use real prepared statements
            $this->conn->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch(PDOException $exception) {
            echo "Connection error: " . $exception->getMessage();
            exit;
        }
        return $this->conn;
    }
}
?>
<?php
session_start();
if(!isset($_SESSION['user_id'])) { header("Location: login.php"); exit; }

require_once 'config/database.php';
$database = new Database();
$db = $database->getConnection();

$user_id = $_SESSION['user_id'];
$wallet_balance = $_SESSION['wallet_balance'] ?? 0.00;

$type = $_GET['type'] ?? 'electricity';
$title = ucfirst($type) . " Bill Payment";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title; ?> - SuperApp</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --primary: #4F46E5; --bg-color: #F3F4F6; --text-dark: #1F2937; --white: #FFFFFF; }
        body { font-family: 'Segoe UI', sans-serif; background: var(--bg-color); display: flex; justify-content: center; margin: 0; }
        .app-container { width: 100%; max-width: 480px; background: var(--white); min-height: 100vh; box-shadow: 0 0 15px rgba(0,0,0,0.05); }
        .header { background: var(--primary); color: var(--white); padding: 20px; display: flex; align-items: center; gap: 15px; }
        .header i { font-size: 20px; cursor: pointer; }
        .form-section { padding: 25px 20px; }
        .input-group { margin-bottom: 20px; }
        .input-group label { display: block; font-size: 13px; color: #6B7280; margin-bottom: 8px; font-weight: 600; }
        .input-group input, .input-group select { width: 100%; padding: 14px; border: 1px solid #D1D5DB; border-radius: 8px; font-size: 16px; outline: none; box-sizing: border-box; }
        .btn-pay { width: 100%; background: #10B981; color: var(--white); border: none; padding: 16px; border-radius: 8px; font-size: 16px; font-weight: bold; cursor: pointer; }
        .info-box { background: #EEF2FF; padding: 15px; border-radius: 10px; margin-top: 20px; font-size: 13px; color: #4B5563; }
    </style>
</head>
<body>
    <div class="app-container">
        <div class="header">
            <i class="fas fa-arrow-left" onclick="window.location.href='index.php'"></i>
            <h2 style="margin:0; font-size: 18px;"><?php echo $title; ?></h2>
        </div>

        <div class="form-section">
            <div class="input-group">
                <label>Select Board / Provider</label>
                <select id="provider">
                    <option value="">Choose your electricity board</option>
                    <option value="NBPDCL">North Bihar Power Distribution (NBPDCL)</option>
                    <option value="SBPDCL">South Bihar Power Distribution (SBPDCL)</option>
                    <option value="UPPCL">UPPCL - Uttar Pradesh</option>
                    <option value="TATA">Tata Power</option>
                </select>
            </div>

            <div class="input-group">
                <label>Consumer Number / CA Number</label>
                <input type="text" id="consumer_no" placeholder="Enter your consumer ID">
            </div>

            <button class="btn-pay" onclick="fetchBill()">Fetch Bill Amount <i class="fas fa-search"></i></button>

            <div id="billDetails" style="display:none; margin-top:25px; border-top: 1px solid #EEE; padding-top:20px;">
                <p>Consumer Name: <strong id="billName">Rahul Kumar</strong></p>
                <p>Due Date: <strong id="billDate">25 Mar 2026</strong></p>
                <h3 style="color:var(--primary);">Amount: ₹ <span id="billAmount">0.00</span></h3>
                <button class="btn-pay" style="background:var(--primary);" onclick="payBillNow()">Pay Bill Now</button>
            </div>

            <div class="info-box">
                <i class="fas fa-shield-alt"></i> BBPS Enabled: Your bill payments are processed securely via Bharat Bill Pay System.
            </div>
        </div>
    </div>

    <script>
        function fetchBill() {
            // Asli app mein ye API se name aur amount fetch karega
            const consumer = document.getElementById('consumer_no').value;
            if(!consumer) { alert("Please enter Consumer Number"); return; }
            
            document.getElementById('billAmount').innerText = (Math.random() * 2000 + 100).toFixed(2);
            document.getElementById('billDetails').style.display = 'block';
        }

        async function payBillNow() {
            alert("Bill payment request sent to BBPS. Please check transaction history for status.");
            window.location.href = 'history.php';
        }
    </script>
</body>
</html>
<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");

require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();
$data = json_decode(file_get_contents("php://input"));

// सुरक्षा चेक: आवश्यक पैरामीटर्स की मौजूदगी
if (!empty($data->user_id) && !empty($data->operator) && !empty($data->target_number) && !empty($data->amount) && !empty($data->type)) {
    
    // इनपुट वैलिडेशन
    $amount = floatval($data->amount);
    if ($amount <= 0) {
        echo json_encode(["status" => "error", "message" => "Invalid recharge amount."]);
        exit;
    }

    try {
        // डेटाबेस ट्रांज़ैक्शन शुरू करें (ताकि विफलता पर सब कुछ रोलबैक हो सके)
        $db->beginTransaction();

        // 1. वॉलेट बैलेंस चेक करें (FOR UPDATE का उपयोग करके कॉनकरेंसी समस्याओं को रोकें)
        $stmt = $db->prepare("SELECT balance FROM wallets WHERE user_id = ? FOR UPDATE");
        $stmt->execute([$data->user_id]);
        $wallet = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$wallet || $wallet['balance'] < $amount) {
            throw new Exception("Insufficient wallet balance. Please add money.");
        }

        // 2. वॉलेट से अमाउंट डेबिट करें
        $new_balance = $wallet['balance'] - $amount;
        $updateWallet = $db->prepare("UPDATE wallets SET balance = ? WHERE user_id = ?");
        $updateWallet->execute([$new_balance, $data->user_id]);

        // 3. प्राइमरी ट्रांज़ैक्शन लॉग एंट्री बनाएं (Status: Pending)
        $txn_id = "REC" . time() . rand(1000, 9999);
        $logStmt = $db->prepare("INSERT INTO transactions (user_id, txn_id, type, amount, service_type, status, description) VALUES (?, ?, 'debit', ?, 'recharge', 'pending', ?)");
        $log_desc = "Recharge for " . $data->operator . " - " . $data->target_number;
        $logStmt->execute([$data->user_id, $txn_id, $amount, $log_desc]);

        // 4. रिचार्ज ऑर्डर टेबल में एंट्री करें
        $orderStmt = $db->prepare("INSERT INTO recharge_orders (txn_id, operator, target_number, amount) VALUES (?, ?, ?, ?)");
        $orderStmt->execute([$txn_id, $data->operator, $data->target_number, $amount]);

        // ट्रांज़ैक्शन कमिट करें: अब वॉलेट से पैसा कट चुका है और सिस्टम ने इसे रिकॉर्ड कर लिया है।
        $db->commit();

        // 5. थर्ड-पार्टी रिचार्ज API को कॉल करें (जैसे Cyberplat, Lapu, या कोई B2B Provider)
        // यह API कॉल बाहरी नेटवर्क पर निर्भर है, इसलिए इसे डेटाबेस कमिट के बाद करते हैं।
        
        $api_url = "https://api.rechargeprovider.com/v1/process";
        $api_payload = json_encode([
            "api_key" => "YOUR_PRODUCTION_API_KEY",
            "operator_code" => $data->operator,
            "number" => $data->target_number,
            "amount" => $amount,
            "client_txn_id" => $txn_id
        ]);

        /* cURL कॉल का उदाहरण (प्रोडक्शन में इसे अन-कमेंट करें)
        $ch = curl_init($api_url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $api_payload);
        $api_response_raw = curl_exec($ch);
        curl_close($ch);
        $api_response = json_decode($api_response_raw, true);
        */

        // विकास के लिए मॉक रेस्पोंस (Mock Response)
        $api_response = ["status" => "SUCCESS", "operator_ref" => "OPR" . rand(111111, 999999)];

        // 6. API के परिणाम के आधार पर डेटाबेस को अपडेट करें
        if ($api_response['status'] === 'SUCCESS') {
            
            // ट्रांज़ैक्शन को 'success' मार्क करें
            $updTxn = $db->prepare("UPDATE transactions SET status = 'success' WHERE txn_id = ?");
            $updTxn->execute([$txn_id]);
            
            // API रेस्पोंस को JSON के रूप में सेव करें
            $updOrder = $db->prepare("UPDATE recharge_orders SET api_response = ? WHERE txn_id = ?");
            $updOrder->execute([json_encode($api_response), $txn_id]);

            // प्रो टिप: यहाँ आप कमीशन डिस्ट्रीब्यूशन मॉड्यूल (Commission.php) को ट्रिगर कर सकते हैं।

            echo json_encode([
                "status" => "success", 
                "message" => "Recharge successful", 
                "txn_id" => $txn_id, 
                "operator_ref" => $api_response['operator_ref'],
                "current_balance" => $new_balance
            ]);

        } else {
            // यदि ऑपरेटर API फेल हो जाती है, तो यूज़र का पैसा तुरंत वापस करें (Auto Refund Process)
            $db->beginTransaction();
            
            $refundStmt = $db->prepare("UPDATE wallets SET balance = balance + ? WHERE user_id = ?");
            $refundStmt->execute([$amount, $data->user_id]);

            $updFailTxn = $db->prepare("UPDATE transactions SET status = 'failed' WHERE txn_id = ?");
            $updFailTxn->execute([$txn_id]);

            $db->commit();

            echo json_encode(["status" => "error", "message" => "Recharge failed at operator end. Amount refunded securely.", "txn_id" => $txn_id]);
        }

    } catch (Exception $e) {
        // यदि बीच में कोई डेटाबेस एरर आती है, तो रोलबैक करें
        if ($db->inTransaction()) {
            $db->rollBack();
        }
        error_log("Recharge Error: " . $e->getMessage()); // लॉगिंग सुरक्षा के लिए
        echo json_encode(["status" => "error", "message" => $e->getMessage()]);
    }

} else {
    echo json_encode(["status" => "error", "message" => "Missing required parameters."]);
}
?>
<?php
// 1. Session start karna zaroori hai (Web Panel ke liye)
session_start();

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");

require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

// --- Hybrid Input Detection Strategy ---
$is_json_request = false;
$phone = '';
$password = '';

// Check 1: Kya request Mobile App/Postman se JSON format mein aayi hai?
$json_data = json_decode(file_get_contents("php://input"));
if (!empty($json_data->phone) && !empty($json_data->password)) {
    $phone = $json_data->phone;
    $password = $json_data->password;
    $is_json_request = true;
} 
// Check 2: Kya request Web Panel HTML Form ($_POST) se aayi hai?
elseif (isset($_POST['username']) && isset($_POST['password'])) {
    // Note: Humne login.php mein name="username" rakha tha, isliye yahan use phone mein map kar rahe hain
    $phone = trim($_POST['username']); 
    $password = $_POST['password'];
}

// --- Main Authentication Logic ---
if (!empty($phone) && !empty($password)) {
    try {
        // SQL Injection Safe Query
        $stmt = $db->prepare("SELECT id, name, password_hash, role FROM users WHERE phone = ? AND role = 'admin' LIMIT 1");
        $stmt->execute([$phone]);
        $admin = $stmt->fetch(PDO::FETCH_ASSOC);

        // Password verification check
        if ($admin && password_verify($password, $admin['password_hash'])) {
            
            // 2. CRITICAL STEP: Web Session Create Karein
            $_SESSION['admin_logged_in'] = true;
            $_SESSION['user_id'] = $admin['id'];
            $_SESSION['role'] = $admin['role'];
            $_SESSION['user_name'] = $admin['name'];

            // 3. Mobile API Token Generate Karein
            $token = bin2hex(random_bytes(32)); 

            // 4. Smart Response Distribution
            if ($is_json_request) {
                // Agar Mobile App hai toh JSON bhejein
                header("Content-Type: application/json; charset=UTF-8");
                echo json_encode([
                    "status" => "success", 
                    "message" => "Admin login successful", 
                    "token" => $token,
                    "admin_name" => $admin['name']
                ]);
                exit();
            } else {
                // Agar Web Panel hai toh Dashboard par Redirect karein
                header("Location: ../admin/index.php");
                exit();
            }
        } else {
            // Login Fail Logic
            if ($is_json_request) {
                http_response_code(401);
                header("Content-Type: application/json; charset=UTF-8");
                echo json_encode(["status" => "error", "message" => "Invalid credentials or unauthorized access."]);
                exit();
            } else {
                header("Location: ../admin/login.php?error=1");
                exit();
            }
        }
    } catch (Exception $e) {
        // System Error Logic
        error_log("Login Exception: " . $e->getMessage());
        if ($is_json_request) {
            http_response_code(500);
            header("Content-Type: application/json; charset=UTF-8");
            echo json_encode(["status" => "error", "message" => "Server error occurred."]);
            exit();
        } else {
            header("Location: ../admin/login.php?error=server");
            exit();
        }
    }
} else {
    // Empty Data Error Logic
    if ($is_json_request || empty($_POST)) {
        http_response_code(400);
        header("Content-Type: application/json; charset=UTF-8");
        echo json_encode(["status" => "error", "message" => "Phone and password are required."]);
        exit();
    } else {
        header("Location: ../admin/login.php?error=empty");
        exit();
    }
}
?>
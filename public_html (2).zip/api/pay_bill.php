<?php
// CORS and Security Headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Authorization, Content-Type");

require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

// 1. Authorization Token एक्स्ट्रेक्ट करें
$headers = apache_request_headers();
$auth_header = isset($headers['Authorization']) ? $headers['Authorization'] : (isset($headers['authorization']) ? $headers['authorization'] : '');

if (!empty($auth_header) && preg_match('/Bearer\s(\S+)/', $auth_header, $matches)) {
    $token = $matches[1];
    
    // इनपुट रीड करें
    $data = json_decode(file_get_contents("php://input"));
    $operator_code = isset($data->operator_code) ? htmlspecialchars(strip_tags($data->operator_code)) : '';
    $consumer_number = isset($data->consumer_number) ? htmlspecialchars(strip_tags($data->consumer_number)) : '';
    $bill_amount = isset($data->amount) ? floatval($data->amount) : 0;
    
    // यह वही रेफ़रेन्स है जो हमने Fetch Bill API में भेजा था (सिक्योरिटी के लिए)
    $fetch_reference = isset($data->fetch_reference) ? htmlspecialchars(strip_tags($data->fetch_reference)) : ''; 

    if (!empty($operator_code) && !empty($consumer_number) && $bill_amount > 0) {
        try {
            // 2. Token Verify करें
            $stmt = $db->prepare("SELECT id FROM users WHERE auth_token = ? AND role = 'user' LIMIT 1");
            $stmt->execute([$token]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user) {
                $user_id = $user['id'];

                // 3. Convenience Fee (Monetization Logic)
                $convenience_fee = 0.00;
                if ($bill_amount >= 1000) {
                    $convenience_fee = 2.50; // ₹1000 से ऊपर के बिल पर ₹2.50 का चार्ज
                }
                
                $total_deduction = $bill_amount + $convenience_fee;

                // 4. Database Transaction शुरू करें (पैसे काटना)
                $db->beginTransaction();

                // वॉलेट लॉक करें और बैलेंस चेक करें
                $walletStmt = $db->prepare("SELECT balance FROM wallets WHERE user_id = ? FOR UPDATE");
                $walletStmt->execute([$user_id]);
                $wallet = $walletStmt->fetch(PDO::FETCH_ASSOC);

                if ($wallet && $wallet['balance'] >= $total_deduction) {
                    $txn_id = "BBPS" . time() . rand(1000, 9999);

                    try {
                        // वॉलेट से टोटल अमाउंट (बिल + फीस) काटें
                        $deductWallet = $db->prepare("UPDATE wallets SET balance = balance - ? WHERE user_id = ?");
                        $deductWallet->execute([$total_deduction, $user_id]);

                        // ट्रांज़ैक्शन को 'Pending' स्टेटस के साथ सेव करें
                        $insertTxn = $db->prepare("INSERT INTO transactions (txn_id, user_id, amount, service_type, status, created_at) VALUES (?, ?, ?, ?, 'pending', NOW())");
                        $insertTxn->execute([$txn_id, $user_id, $total_deduction, "bbps_" . strtolower($operator_code)]);

                        $db->commit(); // पैसे सेफली कट चुके हैं

                        // =========================================================
                        // 5. THIRD-PARTY BBPS API CALL (Pay Bill Request)
                        // =========================================================
                        
                        /* DUMMY CURL CODE - UNCOMMENT IN PRODUCTION
                        $api_url = "https://thirdparty-bbps.com/api/v1/pay-bill";
                        $post_data = json_encode([
                            "api_key" => "YOUR_BBPS_API_KEY",
                            "operator" => $operator_code,
                            "consumer_no" => $consumer_number,
                            "amount" => $bill_amount,
                            "reference_id" => $fetch_reference,
                            "client_txn_id" => $txn_id
                        ]);

                        $ch = curl_init($api_url);
                        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                        curl_setopt($ch, CURLOPT_POST, true);
                        curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
                        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
                        $response = curl_exec($ch);
                        curl_close($ch);
                        
                        $api_result = json_decode($response, true);
                        $api_status = $api_result['status']; // success, failed, pending
                        */

                        // टेस्टिंग के लिए हम 'success' मान रहे हैं
                        $api_status = 'success'; 
                        
                        // 6. Payment Settlement Logic
                        if ($api_status === 'success') {
                            $db->beginTransaction();
                            try {
                                $updateTxn = $db->prepare("UPDATE transactions SET status = 'success' WHERE txn_id = ?");
                                $updateTxn->execute([$txn_id]);

                                // Admin Profit (Convenience Fee) को डेटाबेस में सेव करें
                                if ($convenience_fee > 0) {
                                    $insertProfit = $db->prepare("INSERT INTO admin_revenue (txn_id, profit_amount, date) VALUES (?, ?, NOW())");
                                    $insertProfit->execute([$txn_id, $convenience_fee]);
                                }

                                $db->commit();
                                echo json_encode([
                                    "status" => "success", 
                                    "message" => "Bill paid successfully.", 
                                    "txn_id" => $txn_id,
                                    "convenience_fee_applied" => $convenience_fee > 0 ? true : false
                                ]);
                            } catch (Exception $e) {
                                $db->rollBack();
                                error_log("BBPS Success Update Error: " . $e->getMessage());
                                echo json_encode(["status" => "success", "message" => "Bill paid successfully.", "txn_id" => $txn_id]);
                            }
                        } 
                        elseif ($api_status === 'failed') {
                            // रिफंड प्रोसेस (बिल अमाउंट + फीस दोनों वापस करें)
                            $db->beginTransaction();
                            try {
                                $refundWallet = $db->prepare("UPDATE wallets SET balance = balance + ? WHERE user_id = ?");
                                $refundWallet->execute([$total_deduction, $user_id]);

                                $updateTxn = $db->prepare("UPDATE transactions SET status = 'failed' WHERE txn_id = ?");
                                $updateTxn->execute([$txn_id]);

                                $db->commit();
                                echo json_encode(["status" => "error", "message" => "Payment failed by biller. Full amount refunded to wallet.", "txn_id" => $txn_id]);
                            } catch (Exception $e) {
                                $db->rollBack();
                                error_log("BBPS Refund Failed for TXN: $txn_id");
                                http_response_code(500);
                                echo json_encode(["status" => "error", "message" => "Payment failed. Refund delayed. Please contact support."]);
                            }
                        } else {
                            echo json_encode(["status" => "pending", "message" => "Bill payment is processing. Please check status after 10 minutes.", "txn_id" => $txn_id]);
                        }

                    } catch (Exception $e) {
                        $db->rollBack();
                        http_response_code(500);
                        echo json_encode(["status" => "error", "message" => "Transaction failed at wallet deduction."]);
                    }

                } else {
                    http_response_code(400);
                    echo json_encode(["status" => "error", "message" => "Insufficient wallet balance. Total required: ₹" . number_format($total_deduction, 2)]);
                }
            } else {
                http_response_code(401);
                echo json_encode(["status" => "error", "message" => "Invalid or expired token."]);
            }
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(["status" => "error", "message" => "Server error occurred."]);
        }
    } else {
        http_response_code(400);
        echo json_encode(["status" => "error", "message" => "Invalid input data."]);
    }
} else {
    http_response_code(401);
    echo json_encode(["status" => "error", "message" => "Authorization header missing."]);
}
?>
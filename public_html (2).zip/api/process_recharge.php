<?php
session_start();
// header('Content-Type: application/json'); // API response format

// 1. Security & Input Validation
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 'error', 'message' => 'Invalid Request Method']);
    exit;
}

// User inputs (recharge.php se aayenge)
$mobile = htmlspecialchars($_POST['mobile_number'] ?? '');
$operator = htmlspecialchars($_POST['operator'] ?? '');
$amount = floatval($_POST['amount'] ?? 0);
$user_id = $_SESSION['user_id'] ?? 101; // Demo User ID

if (empty($mobile) || empty($operator) || $amount <= 0) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid input parameters.']);
    exit;
}

// =========================================================================
// 🔒 ENTERPRISE DATABASE CONNECTION (Use PDO for Security)
// =========================================================================
/* $host = 'localhost'; $dbname = 'superpay_db'; $user = 'root'; $pass = '';
$pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
*/

// DUMMY ACTIVE APIs DATA (Real app me DB se ORDER BY margin DESC aayega)
// Logic: Sabse zyada margin wali API pehle try hogi, fail hone par dusri.
$active_apis = [
    [
        "provider" => "Mrobotics",
        "url" => "https://api.mrobotics.in/v2/recharge",
        "key" => "mrob_892374982374",
        "margin" => 2.5 // Highest profit, try first
    ],
    [
        "provider" => "Cyberplat",
        "url" => "https://in.cyberplat.com/api/transact",
        "key" => "cyb_9988223344",
        "margin" => 2.0 // Backup API
    ]
];

// Transaction ID Generate karna
$txn_id = "TXN" . date("YmdHis") . rand(1000, 9999);
$recharge_successful = false;
$final_provider = "";
$profit_earned = 0;
$api_ref_id = "";

// =========================================================================
// 🚀 SMART API FAILOVER LOOP (The Magic Happens Here)
// =========================================================================
foreach ($active_apis as $api) {
    
    // Yahan hum 3rd party API ko cURL ke through request bhejenge
    /*
    $post_data = json_encode([
        'api_key' => $api['key'],
        'number' => $mobile,
        'operator' => $operator,
        'amount' => $amount,
        'client_txn_id' => $txn_id
    ]);

    $ch = curl_init($api['url']);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
    curl_setopt($ch, CURLOPT_TIMEOUT, 15); // 15 Second timeout fail-safe
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    $result = json_decode($response, true);
    */

    // SIMULATION: Maan lijiye pehli API (Mrobotics) fail ho gayi, aur dusri (Cyberplat) pass ho gayi.
    if ($api['provider'] == 'Mrobotics') {
        $result = ['status' => 'FAILED', 'message' => 'Operator Server Down'];
    } else {
        $result = ['status' => 'SUCCESS', 'ref_id' => 'OPR_987654321'];
    }

    // Checking Response
    if ($result['status'] === 'SUCCESS') {
        $recharge_successful = true;
        $final_provider = $api['provider'];
        $profit_earned = ($amount * $api['margin']) / 100;
        $api_ref_id = $result['ref_id'];
        
        break; // SUCCESS mil gaya! Loop yahan rok do, agli API try mat karo.
    } else {
        // FAILED: Is provider ka response log karein DB me (Audit ke liye)
        // Query: INSERT INTO api_error_logs (txn_id, provider, error) VALUES (...)
        continue; // Agli API try karo
    }
}

// =========================================================================
// 💰 FINAL TRANSACTION PROCESSING
// =========================================================================
if ($recharge_successful) {
    // 1. Update Database Status to SUCCESS
    // Query: UPDATE transactions SET status = 'SUCCESS', provider = ?, profit = ?, op_ref = ? WHERE txn_id = ?
    
    // 2. Add SuperCoins (User Retention Strategy)
    $reward_points = floor($amount / 100); // Har Rs.100 pe 1 point
    // Query: UPDATE users SET reward_points = reward_points + ? WHERE id = ?
    
    echo json_encode([
        'status' => 'success',
        'message' => 'Recharge Successful!',
        'txn_id' => $txn_id,
        'operator_ref' => $api_ref_id,
        'provider_used' => $final_provider // (Sif debug ya admin panel ke liye)
    ]);

} else {
    // Agar dono API fail ho gayi
    
    // 1. Refund Amount to Wallet
    // Query: UPDATE users SET wallet_balance = wallet_balance + ? WHERE id = ?
    
    // 2. Update Transaction as FAILED
    // Query: UPDATE transactions SET status = 'FAILED' WHERE txn_id = ?
    
    echo json_encode([
        'status' => 'error',
        'message' => 'Recharge Failed by Operators. Amount has been refunded to your wallet.',
        'txn_id' => $txn_id
    ]);
}
?>
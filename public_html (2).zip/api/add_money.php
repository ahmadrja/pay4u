<?php
// CORS and Security Headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Authorization, Content-Type");

require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

// 1. Authorization Token एक्स्ट्रेक्ट करें
$headers = apache_request_headers();
$auth_header = isset($headers['Authorization']) ? $headers['Authorization'] : (isset($headers['authorization']) ? $headers['authorization'] : '');

if (!empty($auth_header) && preg_match('/Bearer\s(\S+)/', $auth_header, $matches)) {
    $token = $matches[1];
    
    // इनपुट डेटा (JSON) रीड करें
    $data = json_decode(file_get_contents("php://input"));
    $amount = isset($data->amount) ? floatval($data->amount) : 0;
    // प्रोडक्शन में यहाँ Payment Gateway का Transaction ID भी आएगा
    $pg_txn_id = isset($data->pg_txn_id) ? $data->pg_txn_id : 'MANUAL_ADD'; 

    if ($amount > 0) {
        try {
            // 2. Token Verify करें और User ID निकालें
            $stmt = $db->prepare("SELECT id FROM users WHERE auth_token = ? AND role = 'user' LIMIT 1");
            $stmt->execute([$token]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user) {
                $user_id = $user['id'];

                // 3. Database Transaction शुरू करें (ACID Compliance)
                $db->beginTransaction();

                try {
                    // Step A: वॉलेट बैलेंस अपडेट करें (Atomic Update to avoid Race Conditions)
                    $updateWallet = $db->prepare("UPDATE wallets SET balance = balance + ? WHERE user_id = ?");
                    $updateWallet->execute([$amount, $user_id]);

                    // Step B: Transactions टेबल में रिकॉर्ड दर्ज करें
                    $txn_id = "TXN" . time() . rand(1000, 9999); // यूनिक ID जनरेट करें
                    $insertTxn = $db->prepare("INSERT INTO transactions (txn_id, user_id, amount, service_type, status, created_at) VALUES (?, ?, ?, 'wallet_load', 'success', NOW())");
                    $insertTxn->execute([$txn_id, $user_id, $amount]);

                    // अगर दोनों स्टेप्स सफल हुए, तो डेटाबेस में सेव (Commit) कर दें
                    $db->commit();

                    http_response_code(200);
                    echo json_encode([
                        "status" => "success",
                        "message" => "Money added to wallet successfully.",
                        "data" => [
                            "txn_id" => $txn_id,
                            "amount_added" => number_format($amount, 2, '.', '')
                        ]
                    ]);

                } catch (Exception $e) {
                    // अगर वॉलेट अपडेट या ट्रांजैक्शन इन्सर्ट में कोई एरर आया, तो पूरा प्रोसेस कैंसल (Rollback) कर दें
                    $db->rollBack();
                    error_log("Transaction Failed: " . $e->getMessage());
                    
                    http_response_code(500);
                    echo json_encode(["status" => "error", "message" => "Transaction failed. No amount was added."]);
                }

            } else {
                http_response_code(401);
                echo json_encode(["status" => "error", "message" => "Invalid or expired token."]);
            }
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(["status" => "error", "message" => "Server error occurred."]);
        }
    } else {
        http_response_code(400);
        echo json_encode(["status" => "error", "message" => "Invalid amount. Must be greater than 0."]);
    }
} else {
    http_response_code(401);
    echo json_encode(["status" => "error", "message" => "Authorization header missing or invalid."]);
}
?>
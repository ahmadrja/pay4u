<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");

require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();
$data = json_decode(file_get_contents("php://input"));

if(!empty($data->user_id) && !empty($data->hotel_id) && !empty($data->check_in) && !empty($data->check_out) && !empty($data->amount)) {
    
    // Security: Validate dates
    if(strtotime($data->check_in) >= strtotime($data->check_out)) {
        echo json_encode(["status" => "error", "message" => "Check-out date must be after Check-in date."]);
        exit;
    }

    // Amount validation (Frontend se aane wale amount par blind trust na karein, ideally DB/Cache se cross-verify karein)
    $booking_amount = floatval($data->amount);

    try {
        $db->beginTransaction();

        // 1. Wallet lock and check
        $stmt = $db->prepare("SELECT balance FROM wallets WHERE user_id = ? FOR UPDATE");
        $stmt->execute([$data->user_id]);
        $wallet = $stmt->fetch(PDO::FETCH_ASSOC);

        if($wallet['balance'] < $booking_amount) {
            throw new Exception("Insufficient wallet balance for hotel booking.");
        }

        // 2. Deduct from wallet
        $new_bal = $wallet['balance'] - $booking_amount;
        $updWallet = $db->prepare("UPDATE wallets SET balance = ? WHERE user_id = ?");
        $updWallet->execute([$new_bal, $data->user_id]);

        // 3. Create Transaction Log
        $txn_id = "HTL" . time() . rand(1000,9999);
        $logDesc = "Hotel Booking: " . $data->hotel_id . " (" . $data->check_in . " to " . $data->check_out . ")";
        $logStmt = $db->prepare("INSERT INTO transactions (user_id, txn_id, type, amount, service_type, status, description) VALUES (?, ?, 'debit', ?, 'hotel', 'pending', ?)");
        $logStmt->execute([$data->user_id, $txn_id, $booking_amount, $logDesc]);

        $db->commit(); // Wallet deduction saved safely

        // 4. Hit Third-Party Hotel API (e.g., TBO Holidays, Agoda Partner, MakeMyTrip B2B)
        // Mocking API Call for production structure
        $hotel_api_success = true; 
        $booking_reference = "BKG-" . strtoupper(bin2hex(random_bytes(4)));

        if($hotel_api_success) {
            // 5. Save final booking record
            $booking_details = json_encode([
                "hotel_id" => $data->hotel_id,
                "check_in" => $data->check_in,
                "check_out" => $data->check_out,
                "guests" => $data->guests ?? 1,
                "pnr" => $booking_reference
            ]);

            $bookStmt = $db->prepare("INSERT INTO bookings (txn_id, booking_type, booking_details, status) VALUES (?, 'hotel', ?, 'confirmed')");
            $bookStmt->execute([$txn_id, $booking_details]);

            // Update transaction status
            $updTxn = $db->prepare("UPDATE transactions SET status = 'success' WHERE txn_id = ?");
            $updTxn->execute([$txn_id]);

            echo json_encode([
                "status" => "success", 
                "message" => "Hotel booked successfully!", 
                "booking_ref" => $booking_reference,
                "txn_id" => $txn_id
            ]);

        } else {
            // 6. Fallback: Auto Refund if Hotel API fails
            $db->beginTransaction();
            $refund = $db->prepare("UPDATE wallets SET balance = balance + ? WHERE user_id = ?");
            $refund->execute([$booking_amount, $data->user_id]);

            $updTxn = $db->prepare("UPDATE transactions SET status = 'failed' WHERE txn_id = ?");
            $updTxn->execute([$txn_id]);
            $db->commit();

            echo json_encode(["status" => "error", "message" => "Hotel inventory sold out. Amount refunded instantly."]);
        }

    } catch (Exception $e) {
        if($db->inTransaction()) $db->rollBack();
        echo json_encode(["status" => "error", "message" => $e->getMessage()]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Missing booking parameters."]);
}
?>
<?php
session_start();

// Strict Security Check: Only Admin can access
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

require_once '../config/database.php';
$database = new Database();
$db = $database->getConnection();

$admin_name = $_SESSION['user_name'] ?? 'Super Admin';

// यूज़र्स और उनके वॉलेट बैलेंस को फेच करें (Latest First)
try {
    $stmt = $db->query("
        SELECT u.id, u.name, u.phone, u.kyc_status, u.doc_type, u.doc_number, u.doc_image, u.created_at, w.balance 
        FROM users u 
        LEFT JOIN wallets w ON u.id = w.user_id 
        WHERE u.role = 'user' 
        ORDER BY u.id DESC
    ");
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    error_log("Manage Users Error: " . $e->getMessage());
    $users = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users & KYC - SuperPay Admin</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        /* Base Theme (Same as Dashboard) */
        :root { --sidebar-bg: #111827; --primary: #4F46E5; --bg-color: #F3F4F6; --text-dark: #1F2937; --white: #FFFFFF; }
        body { margin: 0; font-family: 'Segoe UI', sans-serif; background: var(--bg-color); display: flex; height: 100vh; overflow: hidden; }
        
        /* Sidebar */
        .sidebar { width: 260px; background: var(--sidebar-bg); color: var(--white); display: flex; flex-direction: column; }
        .sidebar-header { padding: 20px; font-size: 22px; font-weight: bold; border-bottom: 1px solid #374151; display: flex; align-items: center; gap: 10px; }
        .sidebar-menu { list-style: none; padding: 20px 0; margin: 0; flex: 1; }
        .sidebar-menu li a { display: flex; align-items: center; gap: 15px; padding: 15px 25px; color: #9CA3AF; text-decoration: none; transition: 0.3s; font-size: 15px; }
        .sidebar-menu li a:hover, .sidebar-menu li a.active { background: #1F2937; color: var(--white); border-left: 4px solid var(--primary); }
        .logout-btn { padding: 20px; border-top: 1px solid #374151; }
        .logout-btn a { color: #EF4444; text-decoration: none; display: flex; align-items: center; gap: 10px; font-weight: bold; }

        /* Main Content & Topbar */
        .main-content { flex: 1; overflow-y: auto; display: flex; flex-direction: column; }
        .topbar { background: var(--white); padding: 20px 30px; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 1px 3px rgba(0,0,0,0.05); }
        .topbar h2 { margin: 0; color: var(--text-dark); font-size: 20px; }
        .admin-profile { display: flex; align-items: center; gap: 10px; font-weight: bold; color: var(--text-dark); }
        .admin-profile img { width: 35px; height: 35px; border-radius: 50%; }

        .content-container { padding: 30px; }
        
        /* Table Styles */
        .table-section { background: var(--white); border-radius: 12px; padding: 25px; box-shadow: 0 2px 10px rgba(0,0,0,0.02); border: 1px solid #E5E7EB; overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; min-width: 900px; }
        th, td { text-align: left; padding: 15px; border-bottom: 1px solid #F3F4F6; font-size: 14px; vertical-align: middle; }
        th { color: #6B7280; font-weight: 600; text-transform: uppercase; font-size: 12px; background: #F9FAFB; }
        
        .badge { padding: 5px 10px; border-radius: 20px; font-size: 12px; font-weight: bold; display: inline-block; }
        .badge-approved { background: #D1FAE5; color: #065F46; }
        .badge-rejected { background: #FEE2E2; color: #991B1B; }
        .badge-review { background: #FEF3C7; color: #92400E; }
        .badge-pending { background: #E5E7EB; color: #4B5563; }

        .btn { padding: 6px 12px; border: none; border-radius: 6px; cursor: pointer; font-size: 13px; font-weight: bold; color: #fff; transition: 0.3s; }
        .btn-success { background: #10B981; }
        .btn-success:hover { background: #059669; }
        .btn-danger { background: #EF4444; }
        .btn-danger:hover { background: #DC2626; }
        .btn-view { background: #4F46E5; text-decoration: none; display: inline-block; margin-bottom: 5px; }
        .btn-view:hover { background: #4338CA; }

        .action-buttons { display: flex; gap: 8px; flex-wrap: wrap; }
    </style>
</head>
<body>

    <div class="sidebar">
        <div class="sidebar-header">
            <i class="fas fa-bolt" style="color: #F59E0B;"></i> SuperAdmin
        </div>
        <ul class="sidebar-menu">
            <li><a href="index.php"><i class="fas fa-chart-line"></i> Dashboard</a></li>
            <li><a href="manage_users.php" class="active"><i class="fas fa-users"></i> Users & KYC</a></li>
            <li><a href="transactions.php"><i class="fas fa-exchange-alt"></i> Transactions</a></li>
            <li><a href="commissions.php"><i class="fas fa-percent"></i> Commissions</a></li>
            <li><a href="settings.php"><i class="fas fa-cog"></i> API Settings</a></li>
        </ul>
        <div class="logout-btn">
            <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout Securely</a>
        </div>
    </div>

    <div class="main-content">
        <div class="topbar">
            <h2>User Management & KYC</h2>
            <div class="admin-profile">
                <span><?php echo htmlspecialchars($admin_name); ?></span>
                <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($admin_name); ?>&background=111827&color=fff" alt="Admin">
            </div>
        </div>

        <div class="content-container">
            <div class="table-section">
                <table>
                    <thead>
                        <tr>
                            <th>User ID</th>
                            <th>Name & Phone</th>
                            <th>Wallet Bal.</th>
                            <th>KYC Status</th>
                            <th>Document Info</th>
                            <th>Actions (KYC)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($users) > 0): ?>
                            <?php foreach ($users as $u): 
                                // Status Badge Logic
                                $badgeClass = 'badge-pending';
                                $statusText = 'Pending';
                                if($u['kyc_status'] === 'approved') { $badgeClass = 'badge-approved'; $statusText = 'Approved'; }
                                elseif($u['kyc_status'] === 'rejected') { $badgeClass = 'badge-rejected'; $statusText = 'Rejected'; }
                                elseif($u['kyc_status'] === 'under_review') { $badgeClass = 'badge-review'; $statusText = 'Under Review'; }
                            ?>
                            <tr id="user-row-<?php echo $u['id']; ?>">
                                <td style="font-weight: bold; color: #4B5563;">#<?php echo $u['id']; ?></td>
                                <td>
                                    <strong><?php echo htmlspecialchars($u['name']); ?></strong><br>
                                    <span style="color: #6B7280; font-size: 13px;"><i class="fas fa-phone-alt" style="font-size:11px;"></i> <?php echo htmlspecialchars($u['phone']); ?></span>
                                </td>
                                <td style="font-weight: bold; color: var(--primary);">₹<?php echo number_format($u['balance'] ?? 0, 2); ?></td>
                                <td><span class="badge <?php echo $badgeClass; ?>" id="status-badge-<?php echo $u['id']; ?>"><?php echo $statusText; ?></span></td>
                                <td>
                                    <?php if(!empty($u['doc_type'])): ?>
                                        <span style="font-size: 13px; font-weight: bold;"><?php echo $u['doc_type']; ?></span><br>
                                        <span style="font-size: 12px; color: #6B7280;"><?php echo $u['doc_number']; ?></span><br>
                                        <?php if(!empty($u['doc_image'])): ?>
                                            <a href="../uploads/kyc/<?php echo $u['doc_image']; ?>" target="_blank" class="btn btn-view"><i class="fas fa-eye"></i> View Doc</a>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <span style="color: #9CA3AF; font-size: 13px;">No Document</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="action-buttons">
                                        <?php if($u['kyc_status'] === 'under_review'): ?>
                                            <button onclick="updateKYC(<?php echo $u['id']; ?>, 'approve')" class="btn btn-success"><i class="fas fa-check"></i> Approve</button>
                                            <button onclick="updateKYC(<?php echo $u['id']; ?>, 'reject')" class="btn btn-danger"><i class="fas fa-times"></i> Reject</button>
                                        <?php elseif($u['kyc_status'] === 'approved'): ?>
                                            <span style="color: #10B981; font-weight: bold; font-size: 13px;"><i class="fas fa-check-circle"></i> Verified</span>
                                        <?php else: ?>
                                            <span style="color: #9CA3AF; font-size: 13px;">Action Pending from User</span>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" style="text-align: center; color: #6B7280; padding: 30px;">No users found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
    function updateKYC(userId, actionType) {
        if(!confirm(`Are you sure you want to ${actionType} this KYC?`)) return;

        // फॉर्म डेटा तैयार करें
        const formData = new FormData();
        formData.append('user_id', userId);
        formData.append('action', actionType);

        // जो API हमने पहले बनाई थी उसे कॉल करें
        fetch('../api/admin_kyc_action.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if(data.status === 'success') {
                alert(data.message);
                // बिना पेज रिफ्रेश किए UI अपडेट करें (Pro-Level UX)
                const badge = document.getElementById(`status-badge-${userId}`);
                const row = document.getElementById(`user-row-${userId}`);
                const actionCell = row.querySelector('.action-buttons');

                if(actionType === 'approve') {
                    badge.className = 'badge badge-approved';
                    badge.innerText = 'Approved';
                    actionCell.innerHTML = '<span style="color: #10B981; font-weight: bold; font-size: 13px;"><i class="fas fa-check-circle"></i> Verified</span>';
                } else {
                    badge.className = 'badge badge-rejected';
                    badge.innerText = 'Rejected';
                    actionCell.innerHTML = '<span style="color: #9CA3AF; font-size: 13px;">Action Pending from User</span>';
                }
            } else {
                alert("Error: " + data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert("A server error occurred.");
        });
    }
    </script>
</body>
</html>
<?php
session_start();

// Security Guard
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

require_once '../config/database.php';
$database = new Database();
$db = $database->getConnection();

$admin_name = $_SESSION['user_name'] ?? 'Super Admin';

// --- Filters Handling ---
$status_filter = $_GET['status'] ?? '';
$search_query = $_GET['search'] ?? '';

$sql = "SELECT t.*, u.name as user_name, u.phone FROM transactions t 
        JOIN users u ON t.user_id = u.id WHERE 1=1";

if (!empty($status_filter)) {
    $sql .= " AND t.status = " . $db->quote($status_filter);
}
if (!empty($search_query)) {
    $sql .= " AND (t.txn_id LIKE " . $db->quote("%$search_query%") . " OR u.phone LIKE " . $db->quote("%$search_query%") . ")";
}

$sql .= " ORDER BY t.created_at DESC LIMIT 50"; // Top 50 results
$stmt = $db->query($sql);
$transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transaction Monitor - SuperPay Admin</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --sidebar-bg: #111827; --primary: #4F46E5; --bg-color: #F3F4F6; --text-dark: #1F2937; --white: #FFFFFF; }
        body { margin: 0; font-family: 'Segoe UI', sans-serif; background: var(--bg-color); display: flex; height: 100vh; overflow: hidden; }
        
        .sidebar { width: 260px; background: var(--sidebar-bg); color: var(--white); display: flex; flex-direction: column; }
        .sidebar-menu li a { display: flex; align-items: center; gap: 15px; padding: 15px 25px; color: #9CA3AF; text-decoration: none; transition: 0.3s; }
        .sidebar-menu li a:hover, .sidebar-menu li a.active { background: #1F2937; color: var(--white); border-left: 4px solid var(--primary); }

        .main-content { flex: 1; overflow-y: auto; display: flex; flex-direction: column; }
        .topbar { background: var(--white); padding: 20px 30px; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 1px 3px rgba(0,0,0,0.05); }
        
        .content-container { padding: 30px; }
        .filter-bar { background: var(--white); padding: 20px; border-radius: 10px; margin-bottom: 25px; display: flex; gap: 15px; align-items: center; box-shadow: 0 2px 5px rgba(0,0,0,0.02); }
        .input-box { padding: 10px; border: 1px solid #D1D5DB; border-radius: 6px; }
        
        .txn-table-card { background: var(--white); border-radius: 12px; padding: 20px; border: 1px solid #E5E7EB; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 15px; text-align: left; border-bottom: 1px solid #F3F4F6; font-size: 14px; }
        th { background: #F9FAFB; color: #6B7280; font-size: 12px; text-transform: uppercase; }

        .badge { padding: 5px 12px; border-radius: 20px; font-size: 11px; font-weight: bold; text-transform: uppercase; }
        .badge-success { background: #D1FAE5; color: #065F46; }
        .badge-pending { background: #FEF3C7; color: #92400E; }
        .badge-failed { background: #FEE2E2; color: #991B1B; }
        
        .btn-filter { background: var(--primary); color: white; border: none; padding: 10px 20px; border-radius: 6px; cursor: pointer; }
    </style>
</head>
<body>

    <div class="sidebar">
        <div class="sidebar-header" style="padding:20px; font-size:22px; font-weight:bold;"><i class="fas fa-bolt" style="color: #F59E0B;"></i> SuperAdmin</div>
        <ul class="sidebar-menu" style="list-style:none; padding:0;">
            <li><a href="index.php"><i class="fas fa-chart-line"></i> Dashboard</a></li>
            <li><a href="manage_users.php"><i class="fas fa-users"></i> Users & KYC</a></li>
            <li><a href="transactions.php" class="active"><i class="fas fa-exchange-alt"></i> Transactions</a></li>
            <li><a href="commissions.php"><i class="fas fa-percent"></i> Commissions</a></li>
            <li><a href="settings.php"><i class="fas fa-cog"></i> API Settings</a></li>
        </ul>
    </div>

    <div class="main-content">
        <div class="topbar">
            <h2>Global Transaction Monitor</h2>
            <div class="admin-profile"><span><?php echo htmlspecialchars($admin_name); ?></span></div>
        </div>

        <div class="content-container">
            <form class="filter-bar" method="GET">
                <input type="text" name="search" placeholder="Search Txn ID or Phone" class="input-box" value="<?php echo htmlspecialchars($search_query); ?>" style="flex:1;">
                <select name="status" class="input-box">
                    <option value="">All Status</option>
                    <option value="success" <?php echo $status_filter == 'success' ? 'selected' : ''; ?>>Success</option>
                    <option value="pending" <?php echo $status_filter == 'pending' ? 'selected' : ''; ?>>Pending</option>
                    <option value="failed" <?php echo $status_filter == 'failed' ? 'selected' : ''; ?>>Failed</option>
                </select>
                <button type="submit" class="btn-filter"><i class="fas fa-search"></i> Filter</button>
                <a href="transactions.php" class="btn-filter" style="background:#6B7280; text-decoration:none;">Reset</a>
            </form>

            <div class="txn-table-card">
                <table>
                    <thead>
                        <tr>
                            <th>Txn ID</th>
                            <th>User Details</th>
                            <th>Service</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($transactions as $t): 
                            $badge = "badge-" . $t['status'];
                        ?>
                        <tr>
                            <td style="font-family:monospace; color:#4B5563;"><?php echo $t['txn_id']; ?></td>
                            <td>
                                <strong><?php echo htmlspecialchars($t['user_name']); ?></strong><br>
                                <small><?php echo htmlspecialchars($t['phone']); ?></small>
                            </td>
                            <td style="text-transform: capitalize;"><?php echo str_replace('_', ' ', $t['service_type']); ?></td>
                            <td style="font-weight:bold;">₹<?php echo number_format($t['amount'], 2); ?></td>
                            <td><span class="badge <?php echo $badge; ?>"><?php echo $t['status']; ?></span></td>
                            <td><?php echo date('d M Y, h:i A', strtotime($t['created_at'])); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>
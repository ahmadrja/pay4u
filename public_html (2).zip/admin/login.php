<?php
session_start();
// Agar admin pehle se login hai, toh wapas dashboard par bhej dein
if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - SuperPay Platform</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --primary: #4F46E5; --bg-color: #F3F4F6; --text-dark: #1F2937; --white: #FFFFFF; }
        body { margin: 0; font-family: 'Segoe UI', sans-serif; background: var(--bg-color); display: flex; justify-content: center; align-items: center; height: 100vh; }
        .login-container { background: var(--white); padding: 40px; border-radius: 12px; box-shadow: 0 10px 25px rgba(0,0,0,0.05); width: 100%; max-width: 400px; text-align: center; }
        .login-header { margin-bottom: 30px; }
        .login-header i { font-size: 40px; color: var(--primary); margin-bottom: 10px; }
        .login-header h2 { margin: 0; color: var(--text-dark); font-size: 24px; }
        .login-header p { color: #6B7280; font-size: 14px; margin-top: 5px; }
        
        .form-group { margin-bottom: 20px; text-align: left; }
        .form-group label { display: block; font-size: 14px; color: var(--text-dark); font-weight: 600; margin-bottom: 8px; }
        .form-group input { width: 100%; padding: 12px 15px; border: 1px solid #D1D5DB; border-radius: 8px; font-size: 14px; box-sizing: border-box; transition: 0.3s; }
        .form-group input:focus { outline: none; border-color: var(--primary); box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.1); }
        
        .login-btn { width: 100%; background: var(--primary); color: var(--white); padding: 12px; border: none; border-radius: 8px; font-size: 16px; font-weight: bold; cursor: pointer; transition: 0.3s; }
        .login-btn:hover { background: #4338CA; }
        
        .error-msg { background: #FEE2E2; color: #991B1B; padding: 10px; border-radius: 6px; font-size: 14px; margin-bottom: 20px; display: none; }
        /* Agar URL mein ?error=1 ho toh error message dikhayein */
        <?php if(isset($_GET['error'])): ?>
        .error-msg { display: block; }
        <?php endif; ?>
    </style>
</head>
<body>

    <div class="login-container">
        <div class="login-header">
            <i class="fas fa-shield-alt"></i>
            <h2>SuperAdmin Portal</h2>
            <p>Enter your credentials to manage SuperPay</p>
        </div>

        <div class="error-msg">
            <i class="fas fa-exclamation-circle"></i> Invalid Username or Password.
        </div>

        <form action="../api/admin_auth.php" method="POST">
            <div class="form-group">
                <label>Admin Username / Email</label>
                <input type="text" name="username" required placeholder="Enter admin username">
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" required placeholder="Enter secure password">
            </div>
            <button type="submit" class="login-btn">Secure Login <i class="fas fa-arrow-right" style="margin-left: 5px;"></i></button>
        </form>
    </div>

</body>
</html>
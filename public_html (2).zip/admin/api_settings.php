<?php
session_start();
// Security Check (Production में इसे अनकमेंट करें)
// if(!isset($_SESSION['admin_token'])) { header("Location: login.php"); exit; }

// डमी डेटा (रियल प्रोजेक्ट में यह MySQL से आएगा)
// मैंने इसमें api_url और api_key भी जोड़ दिए हैं ताकि पॉपअप में डेटा दिख सके
$api_list = [
    ["id" => 1, "service" => "Mobile Recharge", "provider" => "Mrobotics API", "status" => "active", "margin" => "2.5", "api_url" => "https://api.mrobotics.in/v2/", "api_key" => "mrob_892374982374"],
    ["id" => 2, "service" => "Mobile Recharge", "provider" => "Cyberplat API", "status" => "inactive", "margin" => "2.0", "api_url" => "https://in.cyberplat.com/api/", "api_key" => "cyb_9988223344"],
    ["id" => 3, "service" => "DTH Recharge", "provider" => "Lapu System", "status" => "active", "margin" => "3.0", "api_url" => "https://lapu.service.com/api/", "api_key" => "lapu_1122334455"],
    ["id" => 4, "service" => "Flight Booking", "provider" => "TravelPort API", "status" => "active", "margin" => "5.0", "api_url" => "https://api.travelport.com/", "api_key" => "tvl_5566778899"]
];

// PHP Array को JavaScript के लिए JSON में कन्वर्ट करना
$api_json = json_encode($api_list);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>API Management - SuperAdmin</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        /* बेसिक एडमिन CSS */
        body { font-family: 'Segoe UI', sans-serif; background: #F3F4F6; margin: 0; padding: 20px; }
        .admin-container { max-width: 1000px; margin: auto; background: white; padding: 30px; border-radius: 12px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); }
        h2 { color: #1F2937; margin-top: 0; display: flex; align-items: center; gap: 10px; }
        
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { padding: 15px; text-align: left; border-bottom: 1px solid #E5E7EB; font-size: 14px;}
        th { background: #F9FAFB; color: #6B7280; font-weight: 600; text-transform: uppercase; font-size: 12px; }
        
        /* टॉगल स्विच (ON/OFF) */
        .switch { position: relative; display: inline-block; width: 44px; height: 24px; }
        .switch input { opacity: 0; width: 0; height: 0; }
        .slider { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: #D1D5DB; transition: .4s; border-radius: 24px; }
        .slider:before { position: absolute; content: ""; height: 18px; width: 18px; left: 3px; bottom: 3px; background-color: white; transition: .4s; border-radius: 50%; box-shadow: 0 2px 4px rgba(0,0,0,0.2);}
        input:checked + .slider { background-color: #10B981; }
        input:checked + .slider:before { transform: translateX(20px); }

        .btn-edit { background: #EEF2FF; color: #4F46E5; border: none; padding: 8px 15px; border-radius: 6px; cursor: pointer; font-weight: 600; transition: 0.2s;}
        .btn-edit:hover { background: #4F46E5; color: white; }

        /* Modal (Popup) CSS */
        .modal-overlay { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; justify-content: center; align-items: center; }
        .modal-box { background: white; width: 100%; max-width: 450px; padding: 25px; border-radius: 12px; box-shadow: 0 10px 25px rgba(0,0,0,0.1); }
        .modal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; border-bottom: 1px solid #E5E7EB; padding-bottom: 15px;}
        .modal-header h3 { margin: 0; color: #1F2937; }
        .close-btn { cursor: pointer; color: #9CA3AF; font-size: 20px; transition: 0.2s;}
        .close-btn:hover { color: #EF4444; }
        
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; font-size: 13px; font-weight: 600; color: #4B5563; margin-bottom: 5px; }
        .form-group input { width: 100%; padding: 10px; border: 1px solid #D1D5DB; border-radius: 6px; outline: none; box-sizing: border-box; }
        .form-group input:focus { border-color: #4F46E5; box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.1); }
        
        .btn-save { width: 100%; background: #4F46E5; color: white; border: none; padding: 12px; border-radius: 6px; font-weight: 600; cursor: pointer; margin-top: 10px; transition: 0.2s;}
        .btn-save:hover { background: #4338CA; }

        /* Toast Notification CSS */
        #toast { visibility: hidden; min-width: 250px; background-color: #333; color: #fff; text-align: center; border-radius: 8px; padding: 16px; position: fixed; z-index: 1001; left: 50%; bottom: 30px; transform: translateX(-50%); font-size: 14px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); transition: opacity 0.3s, bottom 0.3s; opacity: 0;}
        #toast.show { visibility: visible; bottom: 50px; opacity: 1; }
        #toast.success { background-color: #10B981; }
        #toast.error { background-color: #EF4444; }
    </style>
</head>
<body>

    <div class="admin-container">
        <h2><i class="fas fa-server"></i> Master API Control Panel</h2>
        <p style="color: #6B7280; font-size: 14px;">सभी सर्विस प्रोवाइडर्स और उनके API स्टेटस को यहाँ से मैनेज करें।</p>

        <table>
            <thead>
                <tr>
                    <th>Service Type</th>
                    <th>Provider Name</th>
                    <th>Admin Margin</th>
                    <th>Status (ON/OFF)</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($api_list as $api): ?>
                <tr>
                    <td><strong><?php echo $api['service']; ?></strong></td>
                    <td><?php echo $api['provider']; ?></td>
                    <td><span style="color: #10B981; font-weight: bold;"><?php echo $api['margin']; ?>%</span></td>
                    <td>
                        <label class="switch">
                            <input type="checkbox" <?php echo ($api['status'] == 'active') ? 'checked' : ''; ?> 
                                   onchange="toggleApiStatus(<?php echo $api['id']; ?>, this.checked)">
                            <span class="slider"></span>
                        </label>
                    </td>
                    <td>
                        <button class="btn-edit" onclick="openApiSettings(<?php echo $api['id']; ?>)">
                            <i class="fas fa-cog"></i> Configure
                        </button>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div class="modal-overlay" id="apiModal">
        <div class="modal-box">
            <div class="modal-header">
                <h3 id="modalTitle">Configure API</h3>
                <i class="fas fa-times close-btn" onclick="closeModal()"></i>
            </div>
            
            <input type="hidden" id="editApiId">
            
            <div class="form-group">
                <label>API Endpoint URL</label>
                <input type="url" id="apiUrl" placeholder="https://api.provider.com/v1/">
            </div>
            <div class="form-group">
                <label>Secret API Key</label>
                <input type="password" id="apiKey" placeholder="Enter API Key">
            </div>
            <div class="form-group">
                <label>Admin Margin (%)</label>
                <input type="number" id="apiMargin" step="0.1" placeholder="e.g. 2.5">
            </div>
            
            <button class="btn-save" onclick="saveApiData()">
                <i class="fas fa-save"></i> Save Configuration
            </button>
        </div>
    </div>

    <div id="toast">Notification Message</div>

    <script>
        // PHP डेटा को JS Object में लाना
        const apiDataList = <?php echo $api_json; ?>;

        // 1. Toggle API Status (Live AJAX)
        function toggleApiStatus(apiId, isChecked) {
            let status = isChecked ? 'active' : 'inactive';
            
            fetch('update_api_status.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id: apiId, new_status: status })
            })
            .then(res => res.json())
            .then(data => {
                if(data.success) {
                    showToast(data.message, 'success');
                } else {
                    showToast(data.message, 'error');
                    setTimeout(() => location.reload(), 1500); // Revert switch if failed
                }
            })
            .catch(err => {
                showToast("Server Error! Make sure update_api_status.php exists.", "error");
            });
        }

        // 2. Open Configuration Modal
        function openApiSettings(apiId) {
            const api = apiDataList.find(a => a.id === apiId);
            if(api) {
                document.getElementById('modalTitle').innerText = `Configure: ${api.provider}`;
                document.getElementById('editApiId').value = api.id;
                document.getElementById('apiUrl').value = api.api_url;
                document.getElementById('apiKey').value = api.api_key;
                document.getElementById('apiMargin').value = api.margin;
                
                document.getElementById('apiModal').style.display = 'flex';
            }
        }

        // 3. Close Modal
        function closeModal() {
            document.getElementById('apiModal').style.display = 'none';
        }

        // 4. Save API Data from Modal
        function saveApiData() {
            let id = document.getElementById('editApiId').value;
            let url = document.getElementById('apiUrl').value;
            let key = document.getElementById('apiKey').value;
            let margin = document.getElementById('apiMargin').value;

            // यहाँ आप एक नई फ़ाइल (save_api_config.php) को fetch request भेजेंगे
            // Demo के लिए हम सिर्फ Toast दिखा रहे हैं
            closeModal();
            showToast(`Configuration for ID ${id} saved successfully!`, 'success');
        }

        // 5. Custom Toast Notification System
        function showToast(message, type) {
            const toast = document.getElementById("toast");
            toast.innerText = message;
            toast.className = `show ${type}`; // Add 'success' or 'error' class
            
            setTimeout(function(){ 
                toast.className = toast.className.replace(`show ${type}`, ""); 
            }, 3000);
        }
    </script>
</body>
</html>
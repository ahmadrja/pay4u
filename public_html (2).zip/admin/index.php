<?php
session_start();

// Strict Security Check: Only Admin can access
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

require_once '../config/database.php';
$database = new Database();
$db = $database->getConnection();

$admin_name = $_SESSION['user_name'] ?? 'Super Admin';

// --- Live KPI Data Fetching ---
$kpi = [
    'total_revenue' => 0.00,
    'active_users' => 0,
    'today_txns' => 0,
    'pending_kyc' => 0
];

try {
    $kpi['active_users'] = $db->query("SELECT COUNT(id) FROM users WHERE role = 'user'")->fetchColumn() ?: 0;
    $kpi['pending_kyc'] = $db->query("SELECT COUNT(id) FROM users WHERE kyc_status = 'pending' OR kyc_status = 'under_review'")->fetchColumn() ?: 0;
    
    $row = $db->query("SELECT COUNT(id) as count, SUM(amount) as total FROM transactions WHERE DATE(created_at) = CURDATE() AND status = 'success'")->fetch(PDO::FETCH_ASSOC);
    $kpi['today_txns'] = $row['count'] ?? 0;
    $kpi['total_revenue'] = $row['total'] ?? 0.00;
    
    // Top 5 Recent Transactions
    $recent_txns = $db->query("SELECT t.txn_id, u.name, t.amount, t.service_type, t.status, t.created_at FROM transactions t JOIN users u ON t.user_id = u.id ORDER BY t.created_at DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    error_log("Dashboard Error: " . $e->getMessage());
    $recent_txns = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SuperApp - Admin Control Panel</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --sidebar-bg: #111827;
            --main-bg: #F3F4F6;
            --card-bg: #FFFFFF;
            --primary: #4F46E5;
            --text-dark: #1F2937;
            --text-light: #9CA3AF;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', sans-serif; }
        
        body { display: flex; height: 100vh; background-color: var(--main-bg); overflow: hidden; }
        
        /* Sidebar Styling */
        .sidebar { width: 250px; background: var(--sidebar-bg); color: white; display: flex; flex-direction: column; }
        .sidebar-brand { padding: 20px; font-size: 24px; font-weight: bold; border-bottom: 1px solid #374151; }
        .sidebar-menu { list-style: none; padding: 20px 0; }
        .sidebar-menu li a { display: block; padding: 15px 20px; color: var(--text-light); text-decoration: none; transition: 0.3s; }
        .sidebar-menu li a:hover, .sidebar-menu li a.active { background: #1F2937; color: white; border-left: 4px solid var(--primary); }
        .sidebar-menu i { width: 25px; }

        /* Main Content */
        .main-content { flex: 1; overflow-y: auto; padding: 30px; }
        .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; }
        .header h2 { color: var(--text-dark); }
        
        /* Fixed Logout Button UI */
        .logout-btn { background: #EF4444; color: white; text-decoration: none; padding: 10px 20px; border-radius: 5px; cursor: pointer; font-weight: bold; display: inline-flex; align-items: center; gap: 8px; transition: 0.3s; }
        .logout-btn:hover { background: #DC2626; }

        /* KPI Cards Grid */
        .kpi-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin-bottom: 30px; }
        .kpi-card { background: var(--card-bg); padding: 25px; border-radius: 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); display: flex; justify-content: space-between; align-items: center; }
        .kpi-card div h3 { font-size: 14px; color: var(--text-light); margin-bottom: 10px; }
        .kpi-card div h1 { font-size: 28px; color: var(--text-dark); }
        .kpi-icon { background: #EEF2FF; color: var(--primary); width: 50px; height: 50px; display: flex; justify-content: center; align-items: center; border-radius: 50%; font-size: 24px; }

        /* Data Table */
        .data-section { background: var(--card-bg); padding: 25px; border-radius: 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); }
        .data-section h3 { margin-bottom: 20px; color: var(--text-dark); }
        table { width: 100%; border-collapse: collapse; }
        th, td { text-align: left; padding: 15px; border-bottom: 1px solid #E5E7EB; }
        th { background: #F9FAFB; color: var(--text-light); font-weight: 600; }
        
        .badge { padding: 5px 10px; border-radius: 15px; font-size: 12px; font-weight: bold; }
        .status-success { background: #D1FAE5; color: #065F46; }
        .status-pending { background: #FEF3C7; color: #92400E; }
        .status-failed { background: #FEE2E2; color: #991B1B; }
    </style>
</head>
<body>

    <aside class="sidebar">
        <div class="sidebar-brand"><i class="fas fa-bolt"></i> SuperAdmin</div>
        <ul class="sidebar-menu">
            <li><a href="index.php" class="active"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
            <li><a href="manage_users.php"><i class="fas fa-users"></i> User Management</a></li>
            <li><a href="transactions.php"><i class="fas fa-wallet"></i> Wallet Transactions</a></li>
            <li><a href="commissions.php"><i class="fas fa-percent"></i> Commission Rules</a></li>
            <li><a href="settings.php"><i class="fas fa-cog"></i> API Settings</a></li>
        </ul>
    </aside>

    <main class="main-content">
        <header class="header">
            <h2>Dashboard Overview</h2>
            <a href="../logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Logout Securely</a>
        </header>

        <div class="kpi-grid">
            <div class="kpi-card">
                <div>
                    <h3>TODAY'S TURNOVER</h3>
                    <h1>₹ <?php echo number_format($kpi['total_revenue'], 2); ?></h1>
                </div>
                <div class="kpi-icon"><i class="fas fa-rupee-sign"></i></div>
            </div>
            <div class="kpi-card">
                <div>
                    <h3>ACTIVE USERS</h3>
                    <h1><?php echo number_format($kpi['active_users']); ?></h1>
                </div>
                <div class="kpi-icon"><i class="fas fa-users"></i></div>
            </div>
            <div class="kpi-card">
                <div>
                    <h3>TODAY'S TXNS</h3>
                    <h1><?php echo number_format($kpi['today_txns']); ?></h1>
                </div>
                <div class="kpi-icon"><i class="fas fa-exchange-alt"></i></div>
            </div>
            <div class="kpi-card">
                <div>
                    <h3>PENDING KYC / ACTIONS</h3>
                    <h1 style="<?php echo $kpi['pending_kyc'] > 0 ? 'color: #EF4444;' : ''; ?>">
                        <?php echo number_format($kpi['pending_kyc']); ?>
                    </h1>
                </div>
                <div class="kpi-icon" style="background: #FEE2E2; color: #EF4444;"><i class="fas fa-exclamation-triangle"></i></div>
            </div>
        </div>

        <div class="data-section">
            <h3>Recent Platform Transactions</h3>
            <table>
                <thead>
                    <tr>
                        <th>TXN ID</th>
                        <th>User</th>
                        <th>Service</th>
                        <th>Amount</th>
                        <th>Status</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($recent_txns) > 0): ?>
                        <?php foreach ($recent_txns as $txn): 
                            $badgeClass = 'status-pending';
                            if($txn['status'] === 'success') $badgeClass = 'status-success';
                            if($txn['status'] === 'failed') $badgeClass = 'status-failed';
                        ?>
                        <tr>
                            <td style="font-family: monospace; color: #4B5563;"><?php echo $txn['txn_id']; ?></td>
                            <td style="font-weight: bold;"><?php echo htmlspecialchars($txn['name']); ?></td>
                            <td style="text-transform: capitalize;"><?php echo str_replace('_', ' ', $txn['service_type']); ?></td>
                            <td style="font-weight: bold;">₹ <?php echo number_format($txn['amount'], 2); ?></td>
                            <td><span class="badge <?php echo $badgeClass; ?>"><?php echo strtoupper($txn['status']); ?></span></td>
                            <td><?php echo date('d M Y, h:i A', strtotime($txn['created_at'])); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" style="text-align: center; color: #6B7280;">No transactions found yet.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>

</body>
</html>
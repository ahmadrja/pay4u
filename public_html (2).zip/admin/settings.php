<?php
session_start();

// Security Guard
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

require_once '../config/database.php';
$database = new Database();
$db = $database->getConnection();

$admin_name = $_SESSION['user_name'] ?? 'Super Admin';
$message = "";

// --- Settings Update Logic ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_all_settings'])) {
    try {
        $db->beginTransaction();
        foreach ($_POST['settings'] as $key => $value) {
            $stmt = $db->prepare("UPDATE app_settings SET setting_value = ? WHERE setting_key = ?");
            $stmt->execute([$value, $key]);
        }
        $db->commit();
        $message = "Settings updated successfully!";
    } catch (Exception $e) {
        $db->rollBack();
        $message = "Error: " . $e->getMessage();
    }
}

// Fetch All Current Settings
$stmt = $db->query("SELECT * FROM app_settings");
$settings = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>App Master Control - SuperPay Admin</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --sidebar-bg: #111827; --primary: #4F46E5; --bg-color: #F3F4F6; --text-dark: #1F2937; --white: #FFFFFF; }
        body { margin: 0; font-family: 'Segoe UI', sans-serif; background: var(--bg-color); display: flex; height: 100vh; overflow: hidden; }
        .sidebar { width: 260px; background: var(--sidebar-bg); color: var(--white); display: flex; flex-direction: column; }
        .sidebar-menu li a { display: flex; align-items: center; gap: 15px; padding: 15px 25px; color: #9CA3AF; text-decoration: none; transition: 0.3s; }
        .sidebar-menu li a:hover, .sidebar-menu li a.active { background: #1F2937; color: var(--white); border-left: 4px solid var(--primary); }
        .main-content { flex: 1; overflow-y: auto; display: flex; flex-direction: column; }
        .topbar { background: var(--white); padding: 20px 30px; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 1px 3px rgba(0,0,0,0.05); }
        .content-container { padding: 30px; }
        .settings-card { background: var(--white); border-radius: 12px; padding: 30px; border: 1px solid #E5E7EB; max-width: 800px; }
        .form-group { margin-bottom: 20px; border-bottom: 1px solid #F3F4F6; padding-bottom: 15px; }
        .form-group label { display: block; font-weight: 600; color: var(--text-dark); margin-bottom: 5px; font-size: 14px; }
        .form-group small { color: #6B7280; display: block; margin-bottom: 10px; }
        .input-field { width: 100%; padding: 10px; border: 1px solid #D1D5DB; border-radius: 6px; box-sizing: border-box; }
        .select-field { width: 100%; padding: 10px; border: 1px solid #D1D5DB; border-radius: 6px; }
        .btn-save { background: var(--primary); color: white; border: none; padding: 12px 25px; border-radius: 6px; cursor: pointer; font-weight: bold; font-size: 16px; }
        .alert { background: #D1FAE5; color: #065F46; padding: 15px; border-radius: 8px; margin-bottom: 20px; font-weight: bold; }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="sidebar-header" style="padding:20px; font-size:22px; font-weight:bold;"><i class="fas fa-bolt" style="color: #F59E0B;"></i> SuperAdmin</div>
        <ul class="sidebar-menu" style="list-style:none; padding:0;">
            <li><a href="index.php"><i class="fas fa-chart-line"></i> Dashboard</a></li>
            <li><a href="manage_users.php"><i class="fas fa-users"></i> Users & KYC</a></li>
            <li><a href="transactions.php"><i class="fas fa-exchange-alt"></i> Transactions</a></li>
            <li><a href="commissions.php"><i class="fas fa-percent"></i> Commissions</a></li>
            <li><a href="settings.php" class="active"><i class="fas fa-cog"></i> API Settings</a></li>
        </ul>
    </div>
    <div class="main-content">
        <div class="topbar">
            <h2>App Global Configuration</h2>
            <div class="admin-profile"><span><?php echo htmlspecialchars($admin_name); ?></span></div>
        </div>
        <div class="content-container">
            <?php if($message): ?> <div class="alert"><?php echo $message; ?></div> <?php endif; ?>
            <div class="settings-card">
                <form method="POST">
                    <?php foreach ($settings as $s): ?>
                    <div class="form-group">
                        <label><?php echo ucwords(str_replace('_', ' ', $s['setting_key'])); ?></label>
                        <small><?php echo htmlspecialchars($s['description']); ?></small>
                        <?php if($s['setting_key'] == 'force_update_required' || $s['setting_key'] == 'maintenance_mode'): ?>
                            <select name="settings[<?php echo $s['setting_key']; ?>]" class="select-field">
                                <option value="true" <?php echo $s['setting_value'] == 'true' ? 'selected' : ''; ?>>Enabled (True)</option>
                                <option value="false" <?php echo $s['setting_value'] == 'false' ? 'selected' : ''; ?>>Disabled (False)</option>
                            </select>
                        <?php elseif($s['setting_key'] == 'maintenance_message'): ?>
                            <textarea name="settings[<?php echo $s['setting_key']; ?>]" class="input-field" rows="3"><?php echo htmlspecialchars($s['setting_value']); ?></textarea>
                        <?php else: ?>
                            <input type="text" name="settings[<?php echo $s['setting_key']; ?>]" class="input-field" value="<?php echo htmlspecialchars($s['setting_value']); ?>">
                        <?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                    <button type="submit" name="update_all_settings" class="btn-save"><i class="fas fa-save"></i> Save All Settings</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>